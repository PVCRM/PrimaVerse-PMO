
"use client"

import { useMemo, useState } from "react";
import { usePermissions } from "@/hooks/use-permissions";
import { allRoles } from "@/data/master-data";
import type { Permission, PermissionLevel, UserRole } from "@/lib/types";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

const modules: Array<{ key: keyof Permission, name: string }> = [
    { key: 'dashboard', name: 'Dashboard' },
    { key: 'clients', name: 'Clients' },
    { key: 'projects', name: 'Projects' },
    { key: 'tasks', name: 'Tasks' },
    { key: 'team', name: 'Team' },
    { key: 'reports', name: 'Reports' }
];

const permissionLevels: PermissionLevel[] = ['Hide', 'View Only', 'CRUD', 'CRUD + Billing', 'Mark Complete'];

export function PermissionsPage() {
    const { permissions, loading, updatePermission, savePermissions } = usePermissions();
    const [isSaving, setIsSaving] = useState(false);

    const orderedRoles = useMemo(() => {
        return ['Project Manager', 'Team Lead', 'Employee', 'Director/VP/CXO', ...allRoles.filter(r => !['Project Manager', 'Team Lead', 'Employee', 'Director/VP/CXO'].includes(r))] as UserRole[];
    }, []);

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await savePermissions();
            toast({ title: 'Success', description: 'Permissions saved successfully.' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to save permissions.' });
        } finally {
            setIsSaving(false);
        }
    };
    
    if (loading) {
        return (
            <div className="space-y-4">
                <div className="h-16 w-1/3 bg-muted animate-pulse rounded-md" />
                <div className="h-64 w-full bg-muted animate-pulse rounded-md" />
            </div>
        )
    }

    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader>
                <CardTitle>Role Access Control</CardTitle>
                <CardDescription>
                    Grant, restrict, or customize access to features for every role. Changes are saved for the entire organization.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="border rounded-lg">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-1/4 font-bold">Role</TableHead>
                                {modules.map(mod => <TableHead key={mod.key} className="font-bold">{mod.name}</TableHead>)}
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {orderedRoles.map(role => (
                                <TableRow key={role}>
                                    <TableCell className="font-semibold">{role}</TableCell>
                                    {modules.map(mod => (
                                        <TableCell key={`${role}-${mod.key}`}>
                                            <Select
                                                value={permissions[role]?.[mod.key] || 'Hide'}
                                                onValueChange={(value) => updatePermission(role, mod.key, value as PermissionLevel)}
                                            >
                                                <SelectTrigger className="w-40">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {permissionLevels.map(level => (
                                                        <SelectItem key={level} value={level}>{level}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                 <div className="flex justify-end mt-6">
                    <Button onClick={handleSave} disabled={isSaving}>
                        {isSaving && <div className="ai-spinner mr-2"/>}
                        Save Permissions
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}
