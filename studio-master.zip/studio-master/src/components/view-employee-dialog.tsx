
'use client'

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { UserProfile, UserRole } from '@/lib/types';
import { Edit, Trash2, Mail, Phone, Fingerprint, Briefcase, UserCheck, AlertCircle, Check, X } from 'lucide-react';
import { roleHierarchy } from '@/data/master-data';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { ApproveUserDialog } from './approve-user-dialog';

interface ViewEmployeeDialogProps {
  employee: UserProfile | null;
  onOpenChange: (open: boolean) => void;
  onEdit: (employee: UserProfile) => void;
  onDeactivate: (employee: UserProfile) => void;
  onDelete: (employee: UserProfile) => void;
  userProfile: UserProfile | null; // The currently logged-in user
}

export function ViewEmployeeDialog({ employee, onOpenChange, onEdit, onDeactivate, onDelete, userProfile }: ViewEmployeeDialogProps) {
  const { approveUser, rejectUser } = useAuth();
  const { toast } = useToast();
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState<UserProfile | null>(employee);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setCurrentEmployee(employee);
  }, [employee]);
  
  if (!currentEmployee || !userProfile) return null;

  const handleApprove = async (role: UserRole) => {
    if(!currentEmployee) return;
    setIsSubmitting(true);
    try {
        await approveUser(currentEmployee.uid, role);
        toast({ title: "Success", description: `${currentEmployee.name} has been approved and activated.`});
        setCurrentEmployee(prev => prev ? { ...prev, status: 'active', role: role } : null);
        setIsApproveDialogOpen(false);
    } catch (e: any) {
        toast({ variant: 'destructive', title: 'Error', description: e.message || 'Failed to approve user.' });
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const handleReject = async () => {
    if(!currentEmployee) return;
    setIsSubmitting(true);
    try {
        await rejectUser(currentEmployee.uid);
        toast({ title: "User Rejected", description: `${currentEmployee.name}'s account has been rejected and deactivated.`});
        setCurrentEmployee(prev => prev ? { ...prev, status: 'deactivated' } : null);
    } catch (e: any) {
        toast({ variant: 'destructive', title: 'Error', description: e.message || 'Failed to reject user.' });
    } finally {
        setIsSubmitting(false);
    }
  };

  const getInitials = (name: string) => {
    return name ? name.split(' ').map(n => n[0]).join('').toUpperCase() : '';
  }
  
  const canManage = (
    userProfile.role === 'Super Admin' ||
    (userProfile.role === 'Director/VP/CXO' && roleHierarchy[userProfile.role] > roleHierarchy[currentEmployee.role])
  );
  const canApprove = ['Super Admin', 'Director/VP/CXO'].includes(userProfile.role);
  const isPending = currentEmployee.status === 'pending_approval';

  const isSelf = userProfile.uid === currentEmployee.uid;
  const isTargetSuperAdmin = currentEmployee.role === 'Super Admin';
  
  const canEdit = canManage && !isPending;
  const canDeactivate = canManage && !isSelf && !isTargetSuperAdmin && !isPending;
  const canDelete = canManage && !isSelf && !isTargetSuperAdmin && !isPending;


  return (
    <>
      <Dialog open={!!employee} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader>
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 border-2 border-primary">
                <AvatarImage src={`https://placehold.co/64x64/A093E2/FFFFFF.png?text=${getInitials(currentEmployee.name)}`} alt={currentEmployee.name} data-ai-hint="person avatar"/>
                <AvatarFallback>{getInitials(currentEmployee.name)}</AvatarFallback>
              </Avatar>
              <div>
                <DialogTitle className="text-2xl">{currentEmployee.name}</DialogTitle>
                <DialogDescription asChild>
                  <div className="flex items-center gap-2">
                    <span>{currentEmployee.email}</span>
                    <Badge 
                        variant={currentEmployee.status === 'active' ? 'default' : 'secondary'}
                        className={currentEmployee.status === 'active' ? 'bg-green-100 text-green-800' : ''}
                    >
                        {currentEmployee.status.replace('_', ' ')}
                    </Badge>
                  </div>
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          
          <DialogBody>
            <div className="space-y-6">
                <div className="space-y-4">
                <h3 className="text-lg font-semibold">Contact & ID</h3>
                <div className="p-4 rounded-lg bg-muted/50 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-3">
                        <Fingerprint className="h-4 w-4 text-muted-foreground" />
                        <span>Employee ID: <span className="font-medium">{currentEmployee.employeeId}</span></span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span>{currentEmployee.email}</span>
                    </div>
                    <div className="flex items-center gap-3 col-span-full">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>Mobile: +{currentEmployee.mobileCountryCode || 'N/A'} {currentEmployee.mobileNumber || 'N/A'}</span>
                    </div>
                </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                <h3 className="text-lg font-semibold">Role Information</h3>
                <div className="p-4 rounded-lg bg-muted/50 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-3">
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                        <span>Department: <span className="font-medium">{Array.isArray(currentEmployee.department) ? currentEmployee.department.join(', ') : currentEmployee.department}</span></span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                        <span>Designation: <span className="font-medium">{currentEmployee.designation}</span></span>
                    </div>
                    <div className="flex items-center gap-3 col-span-full">
                        <UserCheck className="h-4 w-4 text-muted-foreground" />
                        <span>System Role: <span className="font-medium">{currentEmployee.role}</span></span>
                    </div>
                </div>
                </div>
            </div>
          </DialogBody>

          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
            <div className="flex-grow flex justify-end gap-2">
              {isPending ? (
                <>
                  {canApprove && (
                    <>
                      <Button onClick={handleReject} variant="destructive" disabled={isSubmitting}>
                        {isSubmitting && <div className="ai-spinner mr-2"/>}
                        <X className="mr-2 h-4 w-4" /> Reject
                      </Button>
                      <Button onClick={() => setIsApproveDialogOpen(true)} disabled={isSubmitting}>
                        {isSubmitting && <div className="ai-spinner mr-2"/>}
                        <Check className="mr-2 h-4 w-4" /> Approve
                      </Button>
                    </>
                  )}
                </>
              ) : (
                <>
                  {canEdit && ( <Button onClick={() => onEdit(currentEmployee)}><Edit className="mr-2 h-4 w-4" />Edit Profile</Button> )}
                  {canDeactivate && ( <Button onClick={() => onDeactivate(currentEmployee)} variant="secondary"><AlertCircle className="mr-2 h-4 w-4" />Deactivate</Button> )}
                  {canDelete && ( <Button onClick={() => onDelete(currentEmployee)} variant="destructive"><Trash2 className="mr-2 h-4 w-4" />Delete</Button> )}
                </>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ApproveUserDialog
        open={isApproveDialogOpen}
        onOpenChange={setIsApproveDialogOpen}
        onApprove={handleApprove}
        employee={currentEmployee}
      />
    </>
  );
}
