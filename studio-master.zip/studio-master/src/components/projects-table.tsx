
"use client"

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/role-switcher";
import { Project, UserProfile } from "@/lib/types";
import { format } from "date-fns";
import { Button } from "./ui/button";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { PlusCircle } from "lucide-react";

interface ProjectsTableProps {
  projects: Project[];
  userProfile: UserProfile;
  onRowClick: (project: Project) => void;
}

export function ProjectsTable({ projects, userProfile, onRowClick }: ProjectsTableProps) {
  const { permissions } = usePermissions();
  
  const canManageProjects = ['Team Lead', 'Project Manager', 'Director/VP/CXO', 'Super Admin'].includes(userProfile.role);

  const activeProjects = projects.filter(p => p.status === 'Active');
  const pastProjects = projects.filter(p => p.status === 'Inactive');

  return (
    <Card className="rounded-xl border shadow-none">
      <CardHeader>
        <div>
          <CardTitle>Projects</CardTitle>
          <CardDescription>A list of all projects you have access to.</CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="active">
            <TabsList>
                <TabsTrigger value="active">Active Projects</TabsTrigger>
                <TabsTrigger value="completed">Completed Projects</TabsTrigger>
            </TabsList>
            <TabsContent value="active">
                <PaginatedTable 
                    projects={activeProjects} 
                    onRowClick={onRowClick}
                    emptyStateTitle="No Active Projects"
                    emptyStateDescription={canManageProjects ? "Get started by creating a new project." : "You are not assigned to any active projects."}
                />
            </TabsContent>
            <TabsContent value="completed">
                 <PaginatedTable 
                    projects={pastProjects} 
                    onRowClick={onRowClick}
                    emptyStateTitle="No Completed Projects"
                    emptyStateDescription="Completed projects will appear here."
                    isCompletedTab={true}
                />
            </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function PaginatedTable({ projects, onRowClick, emptyStateTitle, emptyStateDescription, isCompletedTab = false }: any) {
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 6;
    const totalPages = Math.ceil(projects.length / rowsPerPage);
    const paginatedProjects = projects.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

    if (projects.length === 0) {
        return (
            <div className="pt-4">
                <EmptyState 
                    title={emptyStateTitle}
                    description={emptyStateDescription}
                />
            </div>
        );
    }
    
    return (
        <>
            <div className="rounded-lg mt-4">
                <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="font-bold">Project Name</TableHead>
                        <TableHead className="font-bold">Client</TableHead>
                        <TableHead className="font-bold">Status</TableHead>
                        <TableHead className="font-bold">{isCompletedTab ? "Completion Date" : "Start Date"}</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {paginatedProjects.map((project: Project) => (
                        <TableRow key={project.id} onClick={() => onRowClick(project)} className="cursor-pointer">
                            <TableCell className="font-medium">{project.name}</TableCell>
                            <TableCell>{project.clientName}</TableCell>
                            <TableCell>
                                <Badge variant={isCompletedTab ? 'default' : 'secondary'} className={cn(isCompletedTab && "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300")}>
                                    {isCompletedTab ? 'Completed' : project.status}
                                </Badge>
                            </TableCell>
                            <TableCell>{format(new Date(isCompletedTab && project.endDate ? project.endDate : project.startDate), "PPP")}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
                </Table>
            </div>
             <div className="flex items-center justify-end space-x-2 py-4">
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</Button>
                <span className="text-sm text-muted-foreground">Page {currentPage} of {totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</Button>
            </div>
        </>
    );
}
