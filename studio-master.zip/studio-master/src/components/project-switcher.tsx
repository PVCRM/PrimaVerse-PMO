
// This component is no longer used and will be removed in a future update.
// The AI Assistant feature has been replaced by the Reports Center.
export function AiAssistant() {
  return null;
}
