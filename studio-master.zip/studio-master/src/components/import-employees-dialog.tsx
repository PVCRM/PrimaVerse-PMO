
"use client"

import { useState } from 'react';
import Papa from 'papaparse';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { FileUp, FileDown, CheckCircle, XCircle } from 'lucide-react';
import type { EmployeeFormOnSaveValues } from './add-employee-dialog';

interface ImportEmployeesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (data: EmployeeFormOnSaveValues[]) => Promise<{ successes: number; failures: { employee: any; error: string }[] }>;
  onDownloadTemplate: () => void;
}

interface ImportResult {
    successes: number;
    failures: { employee: any; error: string }[];
}

const REQUIRED_HEADERS = [
    'FirstName', 'LastName', 'EmployeeID', 'Email', 'Department', 
    'Designation', 'Role', 'MobileCountryCode', 'MobileNumber', 'Password'
];

export function ImportEmployeesDialog({ open, onOpenChange, onImport, onDownloadTemplate }: ImportEmployeesDialogProps) {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<ImportResult | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setFile(event.target.files[0]);
      setResults(null);
    }
  };

  const handleClose = () => {
    setFile(null);
    setResults(null);
    setIsProcessing(false);
    onOpenChange(false);
  };

  const handleProcessImport = () => {
    if (!file) {
      toast({ variant: 'destructive', title: 'No file selected', description: 'Please select a CSV file to import.' });
      return;
    }

    setIsProcessing(true);
    setResults(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (result) => {
        const headers = result.meta.fields || [];
        const missingHeaders = REQUIRED_HEADERS.filter(h => !headers.includes(h));

        if (missingHeaders.length > 0) {
          toast({
            variant: 'destructive',
            title: 'Invalid CSV Format',
            description: `The following required columns are missing: ${missingHeaders.join(', ')}`,
          });
          setIsProcessing(false);
          return;
        }

        const data = (result.data as any[]).map(row => ({
          firstName: row.FirstName,
          lastName: row.LastName,
          employeeId: row.EmployeeID,
          email: row.Email,
          department: row.Department,
          designation: row.Designation,
          role: row.Role,
          mobileCountryCode: row.MobileCountryCode,
          mobileNumber: row.MobileNumber,
          password: row.Password,
        }));
        
        const importResults = await onImport(data);
        setResults(importResults);
        setIsProcessing(false);
      },
      error: (error) => {
        toast({ variant: 'destructive', title: 'CSV Parsing Error', description: error.message });
        setIsProcessing(false);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <div className="p-6 space-y-4">
            <DialogHeader>
            <DialogTitle>Bulk Import Employees</DialogTitle>
            <DialogDescription>
                Upload a CSV file with new employee data. Please ensure it matches the template format.
            </DialogDescription>
            </DialogHeader>

            <Alert>
                <FileDown className="h-4 w-4" />
                <AlertTitle>Download Template</AlertTitle>
                <AlertDescription>
                    Start by downloading the CSV template to ensure your data is in the correct format.
                    <Button variant="link" className="p-0 h-auto ml-1" onClick={onDownloadTemplate}>
                        Download Template
                    </Button>
                </AlertDescription>
            </Alert>
            
            <div>
                <label htmlFor="csv-upload" className="text-sm font-medium">Upload CSV File</label>
                <Input id="csv-upload" type="file" accept=".csv" onChange={handleFileChange} className="mt-1" />
            </div>

            {results && (
                <div>
                <h4 className="font-medium mb-2">Import Results</h4>
                <div className="space-y-2">
                    <Alert variant="default" className="border-green-500">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <AlertTitle>Success</AlertTitle>
                    <AlertDescription>{results.successes} employees were imported successfully.</AlertDescription>
                    </Alert>
                    {results.failures.length > 0 && (
                        <Alert variant="destructive">
                            <XCircle className="h-4 w-4" />
                            <AlertTitle>Failures</AlertTitle>
                            <AlertDescription>
                                {results.failures.length} rows failed to import.
                                <ul className="list-disc pl-5 mt-2 text-xs">
                                    {results.failures.map((fail, index) => (
                                        <li key={index}>
                                            {fail.employee.firstName} {fail.employee.lastName} ({fail.employee.email}): {fail.error}
                                        </li>
                                    ))}
                                </ul>
                            </AlertDescription>
                        </Alert>
                    )}
                </div>
                </div>
            )}
        </div>
        
        <DialogFooter>
            <div className="flex items-center justify-between w-full">
                <Button variant="ghost" onClick={handleClose}>
                    {results ? 'Close' : 'Cancel'}
                </Button>
                <Button onClick={handleProcessImport} disabled={!file || isProcessing}>
                    {isProcessing ? <div className="ai-spinner mr-2"/> : <FileUp className="mr-2 h-4 w-4" />}
                    {isProcessing ? 'Processing...' : 'Import Data'}
                </Button>
            </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
