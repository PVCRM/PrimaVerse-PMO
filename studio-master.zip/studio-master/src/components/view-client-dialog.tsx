

'use client'

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { Client, ClientCoordinator, UserProfile, Project } from '@/lib/types';
import { format } from 'date-fns';
import { Building2, Calendar, Mail, Phone, Edit, UsersRound, FolderKanban, Trash2, User, PowerOff, RotateCcw } from 'lucide-react';
import Image from 'next/image';

interface ViewClientDialogProps {
  client: Client | null;
  onOpenChange: (open: boolean) => void;
  onEdit: (client: Client) => void;
  onDelete: (client: Client) => void;
  onComplete: (client: Client) => void;
  onReactivate: (client: Client) => void;
  userProfile: UserProfile | null;
  projects: Project[];
  team: UserProfile[];
}

export function ViewClientDialog({ client, onOpenChange, onEdit, onDelete, onComplete, onReactivate, userProfile, projects, team }: ViewClientDialogProps) {
  if (!client) return null;

  const handleEdit = () => onEdit(client);
  const handleDelete = () => onDelete(client);
  const handleComplete = () => onComplete(client);
  const handleReactivate = () => onReactivate(client);

  const assignedDuLead = team.find(member => member.uid === client.duLeadId);
  const projectManager = team.find(member => member.uid === client.projectManagerId);
  const teamLeads = team.filter(member => (client.teamLeadIds || []).includes(member.uid));
  
  const salesPerson = team.find(member => member.uid === client.salesPersonId);
  
  const canEditClient = userProfile?.role === 'Project Manager' || userProfile?.role === 'Director/VP/CXO' || userProfile?.role === 'Super Admin';
  const canDeleteClient = userProfile?.role === 'Director/VP/CXO' || userProfile?.role === 'Super Admin';
  
  const activeProjects = projects.filter(p => p.status === 'Active');

  return (
    <Dialog open={!!client} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12 border">
               <AvatarImage src={client.logo} alt={client.name} data-ai-hint="company logo"/>
               <AvatarFallback>{client.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <DialogTitle className="text-2xl">{client.name}</DialogTitle>
              <DialogDescription>Client Code: {client.code}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <DialogBody>
          <div className="space-y-6">
            {/* General Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-3">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <div>
                    <p className="text-muted-foreground">Department</p>
                    <p className="font-medium">{client.department}</p>
                </div>
                </div>
                <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                    <p className="text-muted-foreground">Start Date</p>
                    <p className="font-medium">{format(new Date(client.startDate), 'PPP')}</p>
                </div>
                </div>
                <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                    <p className="text-muted-foreground">Sales Person</p>
                    <p className="font-medium">{salesPerson?.name || 'N/A'}</p>
                </div>
                </div>
            </div>

            <Separator />
            
            {/* Coordinators */}
            <div>
                <h3 className="text-lg font-semibold mb-4">Client Coordinator(s)</h3>
                <div className="space-y-4">
                {client.coordinators.map(coordinator => (
                    <CoordinatorDetails key={coordinator.id} coordinator={coordinator} />
                ))}
                </div>
            </div>

            <Separator />

            {/* Assigned Team */}
            <div>
                <h3 className="text-lg font-semibold mb-4">Assigned Team</h3>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {assignedDuLead && (
                         <div className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <UsersRound className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                                <p className="font-semibold">{assignedDuLead.name}</p>
                                <p className="text-sm text-muted-foreground">DU Lead</p>
                            </div>
                        </div>
                    )}
                     {projectManager && (
                         <div className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <UsersRound className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                                <p className="font-semibold">{projectManager.name}</p>
                                <p className="text-sm text-muted-foreground">Project Manager</p>
                            </div>
                        </div>
                    )}
                     {teamLeads.map(lead => (
                         <div key={lead.uid} className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <UsersRound className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                                <p className="font-semibold">{lead.name}</p>
                                <p className="text-sm text-muted-foreground">Team Lead</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            
            {activeProjects.length > 0 && (
              <>
                <Separator />
                {/* Projects */}
                <div>
                    <h3 className="text-lg font-semibold mb-4">Active Projects</h3>
                    <div className="space-y-2">
                        {activeProjects.map(project => (
                        <div key={project.id} className="p-3 rounded-lg bg-muted/50 flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                            <FolderKanban className="h-4 w-4 text-muted-foreground" />
                            <div>
                                <p className="font-medium text-sm">{project.name}</p>
                                <p className="text-xs text-muted-foreground">Due: {project.endDate ? format(new Date(project.endDate), "PPP") : 'N/A'}</p>
                            </div>
                            </div>
                            <Badge variant="secondary">{project.status}</Badge>
                        </div>
                        ))}
                    </div>
                </div>
              </>
            )}


            <Separator />

            {/* Notes and Tags */}
            <div className="space-y-4">
                <div>
                <h3 className="text-lg font-semibold mb-2">Additional Notes</h3>
                <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">{client.notes || 'No notes provided.'}</p>
                </div>
                <div>
                <h3 className="text-lg font-semibold mb-2">Tags</h3>
                <div className="flex flex-wrap gap-2">
                    {(client.tags || []).map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                </div>
                </div>
            </div>
          </div>
        </DialogBody>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          <div className="flex-grow flex justify-end gap-2">
              {canDeleteClient && (
                  <Button variant="destructive" onClick={handleDelete}>
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Client
                  </Button>
              )}
              {canEditClient && (
                  <>
                    {client.status === 'Active' ? (
                        <Button variant="secondary" onClick={handleComplete}>
                            <PowerOff className="mr-2 h-4 w-4" />
                            Mark as Completed
                        </Button>
                    ) : (
                        <Button variant="secondary" onClick={handleReactivate}>
                            <RotateCcw className="mr-2 h-4 w-4" />
                            Reactivate Client
                        </Button>
                    )}
                    <Button onClick={handleEdit}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Client
                    </Button>
                  </>
              )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CoordinatorDetails({ coordinator }: { coordinator: ClientCoordinator }) {
  return (
    <div className="p-4 rounded-lg bg-muted/50">
      <div className="flex justify-between items-start">
        <div>
          <p className="font-semibold text-base">{coordinator.firstName} {coordinator.lastName}</p>
          <p className="text-sm text-muted-foreground">{coordinator.streetAddress}, {coordinator.city}, {coordinator.state} {coordinator.zipcode}, {coordinator.country}</p>
        </div>
      </div>
      <Separator className="my-3 bg-muted" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-muted-foreground" />
          <a href={`mailto:${coordinator.email}`} className="hover:underline">{coordinator.email}</a>
        </div>
        <div className="flex items-center gap-2">
          <Phone className="h-4 w-4 text-muted-foreground" />
          <span>Mobile: +{coordinator.mobilePhoneCountryCode} {coordinator.mobilePhoneNumber}</span>
        </div>
        <div className="flex items-center gap-2 col-span-full">
           <Phone className="h-4 w-4 text-muted-foreground" />
          <span>Office: +{coordinator.officePhoneCountryCode} {coordinator.officePhoneNumber} {coordinator.officePhoneExt ? `x${coordinator.officePhoneExt}` : ''}</span>
        </div>
      </div>
    </div>
  )
}
