

"use client"

import { useState, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CalendarIcon, Info } from "lucide-react";
import { format, startOfDay } from "date-fns";
import Image from "next/image";
import { collection, query, where, getDocs } from "firebase/firestore";

import { cn } from "@/lib/utils";
import type { Task, Project, Client, UserProfile, ProjectType, TaskType, Priority, UserRole } from "@/lib/types";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMasterData } from "@/context/master-data-context";
import { roleHierarchy } from "@/data/master-data";
import { db } from "@/lib/firebase";
import { useClientMembers } from '@/hooks/use-client-members';

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogBody } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { MultiSelect } from "@/components/ui/multi-select";
import { Alert, AlertDescription } from "./ui/alert";


const taskFormSchema = z.object({
  clientId: z.string().min(1, "Please select a client."),
  projectId: z.string().min(1, "Please select a project."),
  taskTypeId: z.string().min(1, "Please select a task type."),
  title: z.string().min(1, "Task title is required."),
  description: z.string().optional(),
  startDate: z.date({ required_error: "Start date is required." }),
  dueDate: z.date({ required_error: "Due date is required." }),
  priority: z.enum(['P1', 'P2', 'P3', 'P4', 'P5']),
  estimatedHours: z.coerce.number().min(0, "Hours cannot be negative."),
  reviewerId: z.string().min(1, "Please assign a reviewer."),
  assigneeIds: z.array(z.string()).min(1, "Please assign at least one team member."),
  status: z.enum(["todo", "in-progress", "overdue", "completed", "pending_review"]), // For edit mode
}).refine((data) => {
    if (data.startDate && data.dueDate) {
        return startOfDay(data.dueDate) >= startOfDay(data.startDate);
    }
    return true;
}, {
    message: "Due date cannot be before start date.",
    path: ["dueDate"],
});

type TaskFormValues = z.infer<typeof taskFormSchema>;

interface AddTaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (taskData: Omit<Task, 'id' | 'assigneeId'>[], taskId?: string) => Promise<void>;
  taskToEdit?: Task | null;
  clients: Client[];
  projects: Project[];
  team: UserProfile[];
  userProfile: UserProfile | null;
}

export function AddTaskDialog({
  open, onOpenChange, onSave, taskToEdit,
  clients, projects, team, userProfile
}: AddTaskDialogProps) {
  const { toast } = useToast();
  const { masterData } = useMasterData();
  const [isSaving, setIsSaving] = useState(false);
  const [isStartDatePickerOpen, setStartDatePickerOpen] = useState(false);
  const [isDueDatePickerOpen, setDueDatePickerOpen] = useState(false);
  const isEditMode = !!taskToEdit;
  const [remainingHours, setRemainingHours] = useState<number | null>(null);

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      clientId: "",
      projectId: "",
      taskTypeId: "",
      title: "",
      description: "",
      startDate: startOfDay(new Date()),
      dueDate: undefined,
      priority: 'P3',
      estimatedHours: 0,
      reviewerId: "",
      assigneeIds: [],
      status: 'todo',
    },
  });

  const selectedClientId = form.watch('clientId');
  const selectedProjectId = form.watch('projectId');
  const { members: clientMembers } = useClientMembers(selectedClientId);
  
  const selectedClient = useMemo(() => clients.find(c => c.id === selectedClientId), [selectedClientId, clients]);
  const selectedProject = useMemo(() => projects.find(p => p.id === selectedProjectId), [selectedProjectId, projects]);

  const canSelectPastDates = userProfile && roleHierarchy[userProfile.role] >= 3;
  const activeTeam = useMemo(() => team.filter(t => t.status === 'active'), [team]);

  // --- Filtered Options for Dropdowns ---
  const clientOptions = useMemo(() => {
    if (!userProfile) return [];
    if (roleHierarchy[userProfile.role] >= roleHierarchy['Director/VP/CXO']) return clients; // Director & Super Admin see all
    
    // PMs and TLs see clients they are assigned to
    return clients.filter(c => 
        c.projectManagerId === userProfile.uid || 
        (c.teamLeadIds || []).includes(userProfile.uid) ||
        c.duLeadId === userProfile.uid
    );
  }, [clients, userProfile]);

  const projectOptions = useMemo(() => {
    if (!selectedClient) return [];
    if (roleHierarchy[userProfile!.role] >= roleHierarchy['Director/VP/CXO']) {
        return projects.filter(p => p.clientId === selectedClient.id);
    }
    // Employees see only projects they are on for that client
    if (userProfile!.role === 'Employee') {
        return projects.filter(p => p.clientId === selectedClient.id && (p.teamIds || []).includes(userProfile!.uid));
    }
    // PMs/TLs see projects they manage for that client
    return projects.filter(p => p.clientId === selectedClient.id && (p.projectManagerId === userProfile!.uid || (p.teamLeadIds || []).includes(userProfile!.uid)));

  }, [selectedClient, projects, userProfile]);
  
  const taskTypeOptions = useMemo(() => {
    if (!selectedProject) return [];
    const projectType = masterData.projectTypes.find(pt => pt.id === selectedProject.projectTypeId);
    if (!projectType) return [];
    return masterData.taskTypes.filter(tt => tt.projectTypeId === projectType.id);
  }, [selectedProject, masterData.taskTypes, masterData.projectTypes]);
  
  const getEligibleReviewers = (assigneeIds: string[]) => {
    if (!clientMembers || assigneeIds.length === 0) return [];
    
    const assignees = clientMembers.filter(m => assigneeIds.includes(m.uid));
    if (assignees.length === 0) return [];
    
    const highestAssigneeLevel = Math.max(...assignees.map(a => roleHierarchy[a.role]));
    
    return clientMembers.filter(member => {
        const memberLevel = roleHierarchy[member.role];
        // Reviewer must be at least one level higher
        if (memberLevel <= highestAssigneeLevel) return false;
        // Reviewer cannot be one of the assignees
        if (assigneeIds.includes(member.uid)) return false;
        return true;
    });
  };
  
  const assigneeOptions = clientMembers;
  const reviewerOptions = getEligibleReviewers(form.watch('assigneeIds') || []);


  // --- Form Resets and Effects ---
  useEffect(() => {
    if (open) {
      if (isEditMode && taskToEdit) {
        form.reset({
          ...taskToEdit,
          assigneeIds: [taskToEdit.assigneeId],
          startDate: new Date(taskToEdit.startDate),
          dueDate: new Date(taskToEdit.dueDate),
        });
      } else {
        form.reset({
            clientId: "",
            projectId: "",
            taskTypeId: "",
            title: "",
            description: "",
            startDate: new Date(),
            dueDate: undefined,
            priority: 'P3',
            estimatedHours: 0,
            reviewerId: "",
            assigneeIds: [],
            status: 'todo',
        });
      }
    }
  }, [taskToEdit, isEditMode, open, form]);

  useEffect(() => {
    if (form.formState.isDirty && !isEditMode) {
      form.setValue('projectId', '');
      toast({ title: 'Selections Cleared', description: 'Project and assignee selections were cleared as the client was changed.' });
    }
  }, [selectedClientId, form, isEditMode, toast]);
  
  useEffect(() => {
    if (form.formState.isDirty && !isEditMode) {
      form.setValue('taskTypeId', '');
      form.setValue('assigneeIds', []);
      form.setValue('reviewerId', '');
      setRemainingHours(null);
      toast({ title: 'Selections Cleared', description: 'Assignee selections were cleared as the project was changed.' });
    }

    const fetchProjectTaskHours = async () => {
        if (!selectedProjectId) return;
        const project = projects.find(p => p.id === selectedProjectId);
        if (!project) return;
        
        const tasksCollectionRef = collection(db, 'tasks');
        const q = query(tasksCollectionRef, where('projectId', '==', selectedProjectId));
        const tasksSnapshot = await getDocs(q);

        let currentTaskHours = 0;
        tasksSnapshot.docs.forEach(doc => {
            if (isEditMode && doc.id === taskToEdit?.id) return;
            const taskData = doc.data();
            currentTaskHours += (taskData.estimatedHours || 0);
        });

        const remaining = project.estimatedHours - currentTaskHours;
        setRemainingHours(remaining);
    };

    fetchProjectTaskHours();
  }, [selectedProjectId, form, projects, isEditMode, taskToEdit, toast]);
  

  const handleClose = () => {
    onOpenChange(false);
    form.reset();
  }
  
  const handleClear = () => {
    const originalValues = form.getValues();
    form.reset({ clientId: originalValues.clientId, projectId: originalValues.projectId, startDate: new Date() });
  }

  const processSave = async (data: TaskFormValues) => {
    setIsSaving(true);
    try {
      if (!selectedProject || !selectedClient) {
        toast({ variant: 'destructive', title: 'Error', description: 'A client and project must be selected.' });
        setIsSaving(false);
        return;
      }

      const totalNewHours = data.estimatedHours * data.assigneeIds.length;
      if (remainingHours !== null && totalNewHours > remainingHours) {
        toast({ variant: 'destructive', title: 'Billing Hours Exceeded', description: `Total new task hours (${totalNewHours}) exceed remaining project hours (${remainingHours}).`, duration: 7000 });
        setIsSaving(false);
        return;
      }
      
      const selectedTaskType = masterData.taskTypes.find(tt => tt.id === data.taskTypeId);
      const taskTitle = data.title;
      
      const tasksToCreate: Omit<Task, 'id' | 'assigneeId'>[] = data.assigneeIds.map(assigneeId => ({
        ...data,
        title: taskTitle,
        description: data.description,
        clientId: selectedClient.id,
        projectName: selectedProject.name,
        taskTypeName: selectedTaskType?.name,
        completedAt: data.status === 'completed' ? new Date() : undefined,
        assigneeId: assigneeId, 
      }));

      await onSave(tasksToCreate, taskToEdit?.id);

      toast({ title: isEditMode ? 'Task Updated' : 'Task(s) Created', description: `Task "${taskTitle}" has been saved.` });
      
      handleClose();

    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message || 'Could not save the task.' });
    } finally {
      setIsSaving(false);
    }
  }

  async function onSubmit(data: TaskFormValues) {
    await processSave(data);
  }

  const isHoursLocked = useMemo(() => {
    if (!userProfile) return true;
    const userRole = userProfile.role;
    // PM and above can edit hours anytime.
    if (roleHierarchy[userRole] >= 2) return false;
    // Team Leads can only edit on creation, not on existing tasks.
    if (userRole === 'Team Lead') {
      return isEditMode;
    }
    // Employees cannot edit hours at all.
    return true;
  }, [userProfile, isEditMode]);


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <DialogHeader>
              <DialogTitle>{isEditMode ? "Edit Task" : "Create New Task"}</DialogTitle>
              <DialogDescription>
                Fill in the details below to {isEditMode ? "update the" : "create a new"} task.
              </DialogDescription>
            </DialogHeader>
            <DialogBody>
              <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="clientId" render={({ field }) => (
                      <FormItem><FormLabel>Client</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select a client" /></SelectTrigger></FormControl><SelectContent>
                        {clientOptions.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                      </SelectContent></Select><FormMessage /></FormItem>
                    )}/>
                      <FormField control={form.control} name="projectId" render={({ field }) => (
                      <FormItem><FormLabel>Project</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={!selectedClient}><FormControl><SelectTrigger><SelectValue placeholder="Select a project" /></SelectTrigger></FormControl><SelectContent>
                        {projectOptions.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                      </SelectContent></Select><FormMessage /></FormItem>
                    )}/>
                  </div>

                  {selectedClient && selectedProject && (
                    <Card className="bg-muted/50">
                      <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10 border">
                                <AvatarImage src={selectedClient.logo} alt={selectedClient.name} data-ai-hint="company logo"/>
                                <AvatarFallback>{selectedClient.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-semibold text-sm">{selectedClient.name}</p>
                                <p className="text-xs text-muted-foreground">{selectedClient.code}</p>
                            </div>
                          </div>
                          <FormItem><FormLabel>Department</FormLabel><Input value={Array.isArray(selectedClient.department) ? selectedClient.department.join(', ') : selectedClient.department} readOnly disabled/></FormItem>
                          <FormItem><FormLabel>Project Type</FormLabel><Input value={masterData.projectTypes.find(p => p.id === selectedProject.projectTypeId)?.name || 'N/A'} readOnly disabled/></FormItem>
                      </CardContent>
                    </Card>
                  )}

                  {selectedProject && (
                    <>
                      <FormField control={form.control} name="taskTypeId" render={({ field }) => (
                        <FormItem><FormLabel>Task Type / Details</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select a task type" /></SelectTrigger></FormControl><SelectContent>
                          {taskTypeOptions.map(type => <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>)}
                        </SelectContent></Select><FormMessage /></FormItem>
                      )}/>
                      
                      <FormField control={form.control} name="title" render={({ field }) => (
                        <FormItem><FormLabel>Task Title</FormLabel><FormControl><Input placeholder="Overrides selected task type name" {...field} /></FormControl><FormMessage /></FormItem>
                      )}/>
                      
                      <FormField control={form.control} name="description" render={({ field }) => (
                        <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea placeholder="Add more details about the task..." {...field} /></FormControl><FormMessage /></FormItem>
                      )}/>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={form.control} name="startDate" render={({ field }) => (
                          <FormItem><FormLabel>Start Date</FormLabel>
                            <Popover open={isStartDatePickerOpen} onOpenChange={setStartDatePickerOpen}>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant="outline" className={cn("w-full justify-start text-left font-normal",!field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}<CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={(date) => {
                                    field.onChange(date);
                                    setStartDatePickerOpen(false);
                                  }}
                                  disabled={isEditMode ? undefined : { before: new Date(new Date().setHours(0,0,0,0)) }}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}/>
                        <FormField control={form.control} name="dueDate" render={({ field }) => (
                          <FormItem><FormLabel>End Date</FormLabel>
                            <Popover open={isDueDatePickerOpen} onOpenChange={setDueDatePickerOpen}>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button variant="outline" className={cn("w-full justify-start text-left font-normal",!field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}<CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={(date) => {
                                    field.onChange(date);
                                    setDueDatePickerOpen(false);
                                  }}
                                  disabled={{before: form.getValues("startDate") || new Date()}}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}/>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={form.control} name="priority" render={({ field }) => (
                          <FormItem><FormLabel>Priority</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue/></SelectTrigger></FormControl><SelectContent>
                            <SelectItem value="P1">P1</SelectItem><SelectItem value="P2">P2</SelectItem><SelectItem value="P3">P3</SelectItem><SelectItem value="P4">P4</SelectItem><SelectItem value="P5">P5</SelectItem>
                          </SelectContent></Select><FormMessage /></FormItem>
                        )}/>
                          <FormField control={form.control} name="estimatedHours" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Allotted Billing Hours (per resource)</FormLabel>
                            <FormControl><Input type="number" placeholder="8" {...field} disabled={isHoursLocked} /></FormControl>
                            {remainingHours !== null ? (
                                <p className="text-xs text-muted-foreground">Remaining project hours: {remainingHours}</p>
                            ) : (
                                selectedProjectId && <p className="text-xs text-muted-foreground">Calculating remaining hours...</p>
                            )}
                            {isHoursLocked && !isEditMode && <FormMessage>Billing hours cannot be set by your role.</FormMessage>}
                          </FormItem>
                        )}/>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <FormField control={form.control} name="assigneeIds" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Assigned to</FormLabel>
                                <FormControl>
                                    <MultiSelect
                                        options={assigneeOptions.map(o => ({ value: o.uid, label: o.name }))}
                                        selected={field.value}
                                        onChange={field.onChange}
                                        className="w-full"
                                        placeholder="Select team member(s)..."
                                        disabled={isEditMode || assigneeOptions.length === 0}
                                    />
                                </FormControl>
                                {isEditMode && <Alert variant="default" className="mt-2 text-sm"><Info className="h-4 w-4"/><AlertDescription>Assignees cannot be changed after task creation.</AlertDescription></Alert>}
                                <FormMessage />
                            </FormItem>
                        )}/>
                          <FormField control={form.control} name="reviewerId" render={({ field }) => (
                          <FormItem><FormLabel>Reviewer</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={reviewerOptions.length === 0}><FormControl><SelectTrigger><SelectValue placeholder="Select a reviewer" /></SelectTrigger></FormControl><SelectContent>
                            {reviewerOptions.map(m => <SelectItem key={m.uid} value={m.uid}>{m.name}</SelectItem>)}
                          </SelectContent></Select><FormMessage /></FormItem>
                        )}/>
                      </div>
                    </>
                  )}
              </div>
            </DialogBody>
            <DialogFooter>
                <Button type="button" variant="ghost" onClick={handleClose}>Close</Button>
                {!isEditMode && 
                    <Button type="button" variant="outline" onClick={handleClear}>Clear</Button>
                }
                <Button type="submit" disabled={isSaving}>
                    {isSaving && <div className="ai-spinner mr-2"/>}
                    {isEditMode ? 'Update Task' : 'Save Task(s)'}
                </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

