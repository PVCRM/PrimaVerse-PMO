
"use client"

import { useState, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Eye, EyeOff } from "lucide-react";

import type { UserProfile, UserRole, Department, Designation } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useMasterData } from "@/context/master-data-context";
import { majorPhoneCountryCodes } from "@/data/mock-data";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogBody,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Combobox } from "@/components/ui/combobox";


const employeeFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  employeeId: z.string().min(1, "Employee ID is required"),
  department: z.string().min(1, "Department is required"),
  email: z.string().email(),
  mobileCountryCode: z.string().min(1, "Country code is required"),
  mobileNumber: z.string().min(1, "Mobile number is required"),
  designation: z.string().min(1, "Designation is required"), // This will hold the ID
  role: z.string().min(1, "Role is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// This type is for what the onSave function expects (with designation as name)
export type EmployeeFormOnSaveValues = Omit<z.infer<typeof employeeFormSchema>, 'designation'> & { designation: string };
// This type is for the form state (with designation as id)
export type EmployeeFormValues = z.infer<typeof employeeFormSchema>;


interface AddEmployeeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (formData: EmployeeFormOnSaveValues) => Promise<void>;
}

export function AddEmployeeDialog({
  open,
  onOpenChange,
  onSave,
}: AddEmployeeDialogProps) {
  const { toast } = useToast();
  const { masterData } = useMasterData();
  const { departments, designations, roles } = masterData;
  const [isSaving, setIsSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<EmployeeFormValues>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      employeeId: "",
      department: "",
      email: "",
      mobileCountryCode: "91",
      mobileNumber: "",
      designation: "",
      role: "",
      password: ""
    },
  });

  const departmentValue = form.watch('department');
  
  const selectedDepartment = useMemo(() => {
    return departments.find(d => d.name === departmentValue);
  }, [departmentValue, departments]);

  const designationOptions = useMemo(() => {
    if (!selectedDepartment) return [];
    return designations.filter(d => d.departmentId === selectedDepartment.id);
  }, [selectedDepartment, designations]);


  useEffect(() => {
    form.setValue('designation', '');
  }, [departmentValue, form]);

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  async function onSubmit(data: EmployeeFormValues) {
    setIsSaving(true);
    try {
      const selectedDesignation = designations.find(d => d.id === data.designation);
      if (!selectedDesignation) {
        toast({ variant: 'destructive', title: 'Error', description: 'A valid designation must be selected.' });
        setIsSaving(false);
        return;
      }
      
      const dataForSave: EmployeeFormOnSaveValues = {
        ...data,
        designation: selectedDesignation.name,
      };

      await onSave(dataForSave);
      toast({
        title: "Employee Added",
        description: `An account for ${data.firstName} ${data.lastName} has been created and is pending admin approval.`,
      });
      handleClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.message || "Could not add the employee. The email might already be in use.",
      });
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Employee</DialogTitle>
          <DialogDescription>
            Fill out the form below to onboard a new employee. Their account will require admin approval.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <DialogBody>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="firstName" render={({ field }) => (
                        <FormItem><FormLabel>First Name</FormLabel><FormControl><Input placeholder="John" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="lastName" render={({ field }) => (
                        <FormItem><FormLabel>Last Name</FormLabel><FormControl><Input placeholder="Doe" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="employeeId" render={({ field }) => (
                        <FormItem><FormLabel>Employee ID</FormLabel><FormControl><Input placeholder="EMP001" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="department" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Department</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl><SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger></FormControl>
                                <SelectContent>
                                    {departments.map(dep => <SelectItem key={dep.id} value={dep.name}>{dep.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}/>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem><FormLabel>Email ID</FormLabel><FormControl><Input type="email" placeholder="name@example.com" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormItem>
                        <FormLabel>Mobile Phone</FormLabel>
                        <div className="flex gap-2">
                             <FormField control={form.control} name="mobileCountryCode" render={({ field }) => (
                                <FormItem className="w-24 shrink-0">
                                    <FormControl>
                                        <Combobox options={majorPhoneCountryCodes} value={field.value} onChange={field.onChange} placeholder="+91" />
                                    </FormControl>
                                </FormItem>
                            )}/>
                            <FormField control={form.control} name="mobileNumber" render={({ field }) => (
                                <FormItem className="flex-grow"><FormControl><Input type="tel" placeholder="9876543210" {...field} /></FormControl></FormItem>
                            )}/>
                        </div>
                        <FormMessage>{form.formState.errors.mobileCountryCode?.message || form.formState.errors.mobileNumber?.message}</FormMessage>
                    </FormItem>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <FormField control={form.control} name="designation" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Designation</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value} disabled={!departmentValue}>
                                <FormControl><SelectTrigger><SelectValue placeholder={departmentValue ? "Select designation" : "Select department first"} /></SelectTrigger></FormControl>
                                <SelectContent>
                                    {designationOptions.map(des => <SelectItem key={des.id} value={des.id}>{des.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}/>
                    <FormField control={form.control} name="role" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Role</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl><SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger></FormControl>
                                <SelectContent>
                                    {roles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}/>
                </div>

                 <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Set Initial Password</FormLabel>
                        <div className="relative">
                            <FormControl>
                                <Input 
                                    type={showPassword ? "text" : "password"} 
                                    placeholder="••••••••" 
                                    {...field} 
                                    className="pr-10"
                                />
                            </FormControl>
                             <button 
                                type="button" 
                                onClick={() => setShowPassword(!showPassword)} 
                                className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground hover:text-foreground"
                                aria-label={showPassword ? "Hide password" : "Show password"}
                            >
                                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>
                        </div>
                        <FormMessage />
                        </FormItem>
                    )}
                />
              </div>
            </DialogBody>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={handleClose}>Cancel</Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <div className="ai-spinner mr-2" />}
                Add Employee
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
