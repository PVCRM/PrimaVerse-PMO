
"use client"

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogBody,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { Task } from "@/lib/types";

interface ReviewTaskDialogProps {
  task: Task | null;
  onOpenChange: (open: boolean) => void;
  onSave: (taskId: string, mistakeCount: number, repeatedMistakeCount: number, comments: string) => Promise<void>;
  actionType: 'approve' | 'reject';
}

export function ReviewTaskDialog({ task, onOpenChange, onSave, actionType }: ReviewTaskDialogProps) {
  const [mistakeCount, setMistakeCount] = useState(0);
  const [repeatedMistakeCount, setRepeatedMistakeCount] = useState(0);
  const [comments, setComments] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (task) {
      // Don't pre-fill old values, start fresh for each review
      setMistakeCount(0);
      setRepeatedMistakeCount(0);
      setComments("");
    }
  }, [task]);
  
  const handleWordCount = (text: string) => {
    const words = text.trim().split(/\s+/).filter(Boolean);
    if (words.length > 20) {
        setComments(words.slice(0, 20).join(" "));
        toast({
            variant: "destructive",
            title: "Word Limit Exceeded",
            description: "Comments cannot exceed 20 words.",
        });
    } else {
        setComments(text);
    }
  }


  const handleSave = async () => {
    if (!task) return;
    
    if (actionType === 'reject' && (mistakeCount <= 0 && repeatedMistakeCount <= 0)) {
        toast({ variant: 'destructive', title: 'Invalid Input', description: 'Please enter at least one mistake when rejecting a task.' });
        return;
    }

    setIsSaving(true);
    try {
      await onSave(task.id, mistakeCount, repeatedMistakeCount, comments);
      onOpenChange(false);
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error", description: `Failed to ${actionType} task. ${error.message}` });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={!!task} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Review Task: {task?.title}</DialogTitle>
          <DialogDescription>
            Provide feedback for this task. Your comments will be saved for future analysis.
          </DialogDescription>
        </DialogHeader>
        <DialogBody className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
                <Label htmlFor="mistake-count">Number of Mistakes</Label>
                <Input
                id="mistake-count"
                type="number"
                value={mistakeCount}
                onChange={(e) => setMistakeCount(parseInt(e.target.value, 10) || 0)}
                min="0"
                />
            </div>
             <div className="space-y-2">
                <Label htmlFor="repeated-mistake-count">Repeated Mistakes</Label>
                <Input
                id="repeated-mistake-count"
                type="number"
                value={repeatedMistakeCount}
                onChange={(e) => setRepeatedMistakeCount(parseInt(e.target.value, 10) || 0)}
                min="0"
                />
            </div>
          </div>
           <div className="space-y-2">
            <Label htmlFor="comments">Comments (max 20 words)</Label>
            <Textarea
              id="comments"
              value={comments}
              onChange={(e) => handleWordCount(e.target.value)}
              placeholder="e.g., Linework incorrect, dimensions missing..."
              className="min-h-[80px]"
            />
          </div>
        </DialogBody>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving && <div className="ai-spinner mr-2" />}
            {actionType === 'approve' ? 'Approve & Save Feedback' : 'Reject & Save Feedback'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
