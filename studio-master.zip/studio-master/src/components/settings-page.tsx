

"use client"

import { useEffect, useState, useMemo, useRef } from "react"
import { useTheme } from 'next-themes'
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { useMasterData } from "@/context/master-data-context"
import { type UserRole, type RoleElevationRequest, type ProfileChangeRequest } from "@/lib/types"
import { allRoles } from "@/data/master-data"
import { Eye, EyeOff, Monitor, Sun, Moon, HardDriveDownload, HardDriveUpload, Trash2, ShieldAlert } from "lucide-react";
import { collection, getDocs, Timestamp, writeBatch, doc } from "firebase/firestore";
import { db } from "@/lib/firebase";

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Separator } from "@/components/ui/separator"
import QRCode from "qrcode.react"
import { cn } from "@/lib/utils"
import { Checkbox } from "./ui/checkbox"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "./ui/alert-dialog"

interface SettingsPageProps {
  onDataChange?: () => void;
}

export function SettingsPage({ onDataChange }: SettingsPageProps) {
  const { theme, setTheme } = useTheme()
  const { 
    userProfile, 
    requestRoleElevation, 
    getRoleRequestStatus,
    requestProfileChange,
    getProfileChangeRequestStatus
  } = useAuth()
  const { toast } = useToast()
  const { masterData, loading: loadingMasterData } = useMasterData()

  // Role Elevation State
  const [selectedRole, setSelectedRole] = useState<UserRole | "">("");
  const [roleRequest, setRoleRequest] = useState<RoleElevationRequest | null>(null);
  const [isLoadingRoleRequest, setIsLoadingRoleRequest] = useState(true);
  const [isSubmittingRole, setIsSubmittingRole] = useState(false);

  // Profile Change State
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const [selectedDesignation, setSelectedDesignation] = useState<string>("");
  const [profileRequest, setProfileRequest] = useState<ProfileChangeRequest | null>(null);
  const [isLoadingProfileRequest, setIsLoadingProfileRequest] = useState(true);
  const [isSubmittingProfileChange, setIsSubmittingProfileChange] = useState(false);
  
  // 2FA Dialog State
  const [is2faDialogOpen, setIs2faDialogOpen] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Data Management State
  const [dataToDelete, setDataToDelete] = useState<string[]>([]);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [isRestoreConfirmOpen, setIsRestoreConfirmOpen] = useState(false);
  const [restoreConfirmText, setRestoreConfirmText] = useState("");
  const restoreFileInputRef = useRef<HTMLInputElement>(null);

  const isSuperAdmin = userProfile?.role === 'Super Admin';

  useEffect(() => {
    // Only fetch request statuses if the user is NOT a super admin.
    if (!isSuperAdmin) {
        const fetchRequestStatus = async () => {
        if (!getRoleRequestStatus || !getProfileChangeRequestStatus) return
        setIsLoadingRoleRequest(true);
        setIsLoadingProfileRequest(true);
        try {
            const [roleStatus, profileStatus] = await Promise.all([
            getRoleRequestStatus(),
            getProfileChangeRequestStatus()
            ]);
            setRoleRequest(roleStatus);
            setProfileRequest(profileStatus);
        } catch (error) {
            console.error("Failed to get request status", error);
            toast({ variant: "destructive", title: "Error", description: "Could not fetch request statuses." });
        } finally {
            setIsLoadingRoleRequest(false);
            setIsLoadingProfileRequest(false);
        }
        };
        fetchRequestStatus();
    } else {
        // If user is Super Admin, no need to check for requests.
        setIsLoadingRoleRequest(false);
        setIsLoadingProfileRequest(false);
    }
  }, [getRoleRequestStatus, getProfileChangeRequestStatus, toast, isSuperAdmin]);

  const handleRequestElevation = async () => {
    if (!selectedRole) {
      toast({ variant: "destructive", title: "Error", description: "Please select a role to request." });
      return;
    }
    setIsSubmittingRole(true);
    try {
      await requestRoleElevation(selectedRole);
      toast({ title: "Success", description: "Your role elevation request has been submitted." });
      const status = await getRoleRequestStatus();
      setRoleRequest(status);
    } catch (error: any) {
      toast({ variant: "destructive", title: "Request Failed", description: error.message || "An unexpected error occurred." });
    } finally {
      setIsSubmittingRole(false);
    }
  };

  const handleRequestProfileChange = async () => {
    if (!selectedDepartment || !selectedDesignation) {
        toast({ variant: "destructive", title: "Error", description: "Please select both a department and a designation." });
        return;
    }
    setIsSubmittingProfileChange(true);
    try {
        await requestProfileChange(selectedDepartment, selectedDesignation);
        toast({ title: "Success", description: "Your profile change request has been submitted." });
        const status = await getProfileChangeRequestStatus();
        setProfileRequest(status);
    } catch (error: any) {
        toast({ variant: "destructive", title: "Request Failed", description: error.message || "An unexpected error occurred." });
    } finally {
        setIsSubmittingProfileChange(false);
    }
  };

    const handleDataDeletion = async () => {
        if (dataToDelete.length === 0) {
            toast({ variant: 'destructive', title: 'No Selection', description: 'Please select at least one data type to delete.' });
            return;
        }

        setIsDeleting(true);
        toast({ title: 'Deletion in Progress', description: `Deleting ${dataToDelete.join(', ')}... This may take a while.` });

        try {
            for (const collectionName of dataToDelete) {
                const collectionRef = collection(db, collectionName);
                const snapshot = await getDocs(collectionRef);
                
                if (snapshot.empty) continue;

                const batch = writeBatch(db);
                snapshot.docs.forEach(doc => {
                    // Safety check: do not delete the currently logged-in Super Admin
                    if (collectionName === 'users' && doc.id === userProfile?.uid) {
                        return; 
                    }
                    batch.delete(doc.ref);
                });
                await batch.commit();
            }
            toast({ title: 'Deletion Complete', description: 'Selected data has been successfully deleted.' });
            if (onDataChange) {
                onDataChange();
            }
        } catch (error: any) {
            console.error("Deletion failed:", error);
            toast({ variant: 'destructive', title: 'Deletion Failed', description: error.message || 'Could not delete selected data.' });
        } finally {
            setIsDeleting(false);
            setDataToDelete([]);
        }
    };
  
  const handleCreateBackup = async () => {
    setIsBackingUp(true);
    toast({ title: "Starting Backup", description: "Fetching all data from the database. This may take a moment..." });

    const collectionsToBackup = [
        'users', 'clients', 'projects', 'tasks', 'timesheet', 
        'departments', 'designations', 'projectTypes', 'taskTypes',
        'roleRequests', 'profileChangeRequests', 'app-config'
    ];
    const backupData: Record<string, any[]> = {};

    try {
        for (const collectionName of collectionsToBackup) {
            const querySnapshot = await getDocs(collection(db, collectionName));
            backupData[collectionName] = querySnapshot.docs.map(doc => {
                const data = doc.data();
                // Convert Firestore Timestamps to ISO strings for JSON compatibility
                Object.keys(data).forEach(key => {
                    if (data[key] instanceof Timestamp) {
                        data[key] = data[key].toDate().toISOString();
                    } else if (data[key] && typeof data[key] === 'object' && 'toDate' in data[key]) {
                        // Handle cases where it might be a Timestamp-like object
                        data[key] = (data[key] as Timestamp).toDate().toISOString();
                    }
                });
                return { id: doc.id, ...data };
            });
        }
        
        const jsonString = JSON.stringify(backupData, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `perspective-pmo-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast({ title: "Backup Complete", description: "Your data has been downloaded successfully." });

    } catch (error) {
        console.error("Backup failed:", error);
        toast({ variant: 'destructive', title: 'Backup Failed', description: 'Could not create a data backup. See console for details.' });
    } finally {
        setIsBackingUp(false);
    }
  };

  const handleRestoreFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/json') {
      setRestoreFile(file);
      setIsRestoreConfirmOpen(true);
    } else {
      toast({ variant: 'destructive', title: 'Invalid File', description: 'Please select a valid .json backup file.' });
    }
    // Reset file input to allow selecting the same file again
    if(event.target) event.target.value = '';
  };
  
  const handleConfirmRestore = async () => {
    if (!restoreFile) return;

    setIsRestoreConfirmOpen(false);
    setIsRestoring(true);
    toast({ title: "Restore Started", description: `Restoring data from ${restoreFile.name}. The app may be unresponsive.` });

    try {
        const fileContent = await restoreFile.text();
        const backupData = JSON.parse(fileContent);

        // This is a simplified restore. A robust solution would handle deletions and dependencies.
        // It uses setDoc with merge:true to upsert documents.
        for (const collectionName in backupData) {
            if (Object.prototype.hasOwnProperty.call(backupData, collectionName)) {
                const collectionData = backupData[collectionName];
                if (Array.isArray(collectionData)) {
                    const batch = writeBatch(db);
                    collectionData.forEach((item: any) => {
                        const { id, ...data } = item;
                        // Convert ISO strings back to Timestamps
                        Object.keys(data).forEach(key => {
                            const value = data[key];
                            if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) {
                                data[key] = Timestamp.fromDate(new Date(value));
                            }
                        });
                        const docRef = doc(db, collectionName, id);
                        batch.set(docRef, data); // Using set() will overwrite or create
                    });
                    await batch.commit();
                }
            }
        }
        
        toast({ title: "Restore Complete", description: "Data has been successfully restored. Please refresh the application." });
         if (onDataChange) {
            onDataChange();
        }
    } catch (error: any) {
        console.error("Restore failed:", error);
        toast({ variant: 'destructive', title: 'Restore Failed', description: error.message || "Could not restore data. Check the console for details." });
    } finally {
        setIsRestoring(false);
        setRestoreFile(null);
        setRestoreConfirmText("");
    }
  };
  
  if (!userProfile) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="ai-spinner"></div>
      </div>
    )
  }

  const currentUserRoleIndex = allRoles.indexOf(userProfile.role);
  const availableRoles = allRoles.filter((_, index) => index > currentUserRoleIndex);
  
  const designationOptions = useMemo(() => {
      if (!selectedDepartment || loadingMasterData) return [];
      const department = masterData.departments.find(d => d.name === selectedDepartment);
      if (!department) return [];
      return masterData.designations.filter(d => d.departmentId === department.id);
  }, [selectedDepartment, masterData.departments, masterData.designations, loadingMasterData]);


  const renderRoleRequestContent = () => {
    if (isLoadingRoleRequest) {
      return <Skeleton className="h-20 w-full" />;
    }
    if (roleRequest && roleRequest.status === 'pending') {
      return <p className="text-sm text-muted-foreground">Your request to be promoted to <span className="font-semibold text-foreground">{roleRequest.requestedRole}</span> is currently pending review.</p>;
    }
    if (availableRoles.length === 0) {
      return <p className="text-sm text-muted-foreground">You are already at the highest role level.</p>
    }
    return (
       <div className="flex items-end gap-4">
          <div className="flex-grow">
              <Label htmlFor="role-select" className="mb-2 block text-xs">Request Promotion</Label>
              <Select onValueChange={(value) => setSelectedRole(value as UserRole)} value={selectedRole}>
                <SelectTrigger id="role-select">
                  <SelectValue placeholder="Select a new role" />
                </SelectTrigger>
                <SelectContent>
                  {availableRoles.map(role => (
                    <SelectItem key={role} value={role}>{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
          </div>
          <Button onClick={handleRequestElevation} disabled={isSubmittingRole || !selectedRole}>
            {isSubmittingRole && <div className="ai-spinner mr-2" />}
            Submit Request
          </Button>
       </div>
    );
  }

  const renderProfileChangeRequestContent = () => {
    if (isLoadingProfileRequest || loadingMasterData) {
        return <Skeleton className="h-24 w-full" />;
    }
    if (profileRequest && profileRequest.status === 'pending') {
        return (
            <p className="text-sm text-muted-foreground">
                Your request to change department to <span className="font-semibold text-foreground">{profileRequest.requestedDepartment}</span> and designation to <span className="font-semibold text-foreground">{profileRequest.requestedDesignation}</span> is currently pending review.
            </p>
        );
    }
    return (
        <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex-grow">
                    <Label htmlFor="dept-select" className="mb-2 block text-xs">Request Department Change</Label>
                    <Select onValueChange={(value) => setSelectedDepartment(value)} value={selectedDepartment}>
                        <SelectTrigger id="dept-select"><SelectValue placeholder="Select a new department" /></SelectTrigger>
                        <SelectContent>
                            {masterData.departments.map(dept => (
                                <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="flex-grow">
                    <Label htmlFor="desig-select" className="mb-2 block text-xs">Request Designation Change</Label>
                    <Select onValueChange={(v) => setSelectedDesignation(v)} value={selectedDesignation} disabled={!selectedDepartment}>
                        <SelectTrigger id="desig-select"><SelectValue placeholder="Select department first" /></SelectTrigger>
                        <SelectContent>
                            {designationOptions.map(desig => (
                                <SelectItem key={desig.id} value={desig.name}>{desig.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
            <Button onClick={handleRequestProfileChange} disabled={isSubmittingProfileChange || !selectedDepartment || !selectedDesignation}>
                {isSubmittingProfileChange && <div className="ai-spinner mr-2" />}
                Submit Request
            </Button>
        </div>
    );
  };

  const dataManagementItems = [
    { id: 'clients', label: 'All Clients' },
    { id: 'projects', label: 'All Projects' },
    { id: 'tasks', label: 'All Tasks' },
    { id: 'timesheet', label: 'All Timesheet Entries' },
    { id: 'users', label: 'All Users (except Super Admin)' },
  ];

  return (
    <>
      <div className="space-y-6 animate-fade-in-up">
        
        <Card className="rounded-xl border shadow-none">
          <CardHeader>
            <CardTitle className="text-base">Profile Information</CardTitle>
            <CardDescription>Your current role and department within the organization.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div><span className="font-semibold text-muted-foreground">Role:</span> {userProfile.role}</div>
              <div><span className="font-semibold text-muted-foreground">Department:</span> {Array.isArray(userProfile.department) ? userProfile.department.join(', ') : userProfile.department || 'N/A'}</div>
              <div><span className="font-semibold text-muted-foreground">Designation:</span> {userProfile.designation || 'N/A'}</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Appearance</CardTitle>
            <CardDescription>
              Customize the look and feel of the application.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Label className="text-sm font-medium">Theme</Label>
            <div className="flex gap-2">
                <Button 
                  variant={theme === 'light' ? 'default' : 'outline'}
                  onClick={() => setTheme('light')} 
                  className="flex-1 flex items-center gap-2"
                >
                  <Sun className="h-4 w-4"/> Light
                </Button>
                <Button 
                  variant={theme === 'dark' ? 'default' : 'outline'}
                  onClick={() => setTheme('dark')} 
                  className="flex-1 flex items-center gap-2"
                >
                  <Moon className="h-4 w-4"/> Dark
                </Button>
            </div>
          </CardContent>
        </Card>
        
        {!isSuperAdmin && (
          <>
            <Card className="rounded-xl border shadow-none">
              <CardHeader>
                <CardTitle className="text-base">Role Elevation</CardTitle>
                <CardDescription>Request a promotion to a higher role level.</CardDescription>
              </CardHeader>
              <CardContent>
                {renderRoleRequestContent()}
              </CardContent>
            </Card>

            <Card className="rounded-xl border shadow-none">
              <CardHeader>
                <CardTitle className="text-base">Department &amp; Designation Change</CardTitle>
                <CardDescription>Request a change to your department or designation.</CardDescription>
              </CardHeader>
              <CardContent>
                {renderProfileChangeRequestContent()}
              </CardContent>
            </Card>
          </>
        )}

        {isSuperAdmin && (
          <Card className="rounded-xl border shadow-none">
            <CardHeader>
              <CardTitle className="text-base">Data Management</CardTitle>
              <CardDescription>Perform global data operations. Use with extreme caution.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                  <div className="space-y-4 p-4 border rounded-lg border-destructive/50">
                      <h4 className="font-semibold flex items-center gap-2 text-destructive"><ShieldAlert className="h-5 w-5"/>Bulk Data Deletion</h4>
                      <p className="text-xs text-muted-foreground">This is an irreversible action. Once data is deleted, it cannot be recovered. Please create a backup before proceeding.</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          {dataManagementItems.map(item => (
                              <div key={item.id} className="flex items-center space-x-2">
                                  <Checkbox 
                                      id={`delete-${item.id}`} 
                                      onCheckedChange={(checked) => {
                                          setDataToDelete(prev => checked ? [...prev, item.id] : prev.filter(i => i !== item.id))
                                      }}
                                  />
                                  <Label htmlFor={`delete-${item.id}`}>{item.label}</Label>
                              </div>
                          ))}
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" disabled={dataToDelete.length === 0 || isDeleting}>
                              {isDeleting ? <div className="ai-spinner mr-2" /> : <Trash2 className="mr-2 h-4 w-4" />}
                              {isDeleting ? 'Deleting...' : 'Delete Selected Data'}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action is permanent and cannot be undone. You are about to delete all data for: <span className="font-semibold text-foreground">{dataToDelete.join(', ')}</span>.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDataDeletion}>Confirm & Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                          <h4 className="font-semibold">Backup</h4>
                          <p className="text-xs text-muted-foreground">Create a full backup of the Firestore database.</p>
                          <Button variant="outline" onClick={handleCreateBackup} disabled={isBackingUp}>
                              {isBackingUp ? <div className="ai-spinner mr-2" /> : <HardDriveDownload className="mr-2 h-4 w-4"/>}
                              {isBackingUp ? 'Backing Up...' : 'Create Backup'}
                          </Button>
                      </div>
                      <div className="space-y-2">
                          <h4 className="font-semibold">Restore</h4>
                          <p className="text-xs text-muted-foreground">Restore data from a previously created backup file.</p>
                          <input type="file" ref={restoreFileInputRef} onChange={handleRestoreFileSelect} className="hidden" accept=".json" />
                          <Button variant="outline" onClick={() => restoreFileInputRef.current?.click()} disabled={isRestoring}>
                              {isRestoring ? <div className="ai-spinner mr-2" /> : <HardDriveUpload className="mr-2 h-4 w-4" />}
                              Restore from Backup
                          </Button>
                      </div>
                  </div>
            </CardContent>
          </Card>
        )}

        <Card className="rounded-xl border shadow-none">
          <CardHeader>
            <CardTitle className="text-base">Account Security</CardTitle>
            <CardDescription>Manage your account settings.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">Change Email</Label>
              <div className="flex items-start gap-4">
                <Input id="email" type="email" placeholder="New Email Address" className="flex-grow" defaultValue={userProfile.email || ''} />
                <Button type="submit" >Update</Button>
              </div>
            </div>
          
            <Separator />
          
            <div className="space-y-2">
              <Label className="text-sm font-medium">Change Password</Label>
              <div className="space-y-2">
                <div className="relative">
                  <Input type={showCurrentPassword ? "text" : "password"} placeholder="Current Password" className="pr-10" />
                  <button type="button" onClick={() => setShowCurrentPassword(!showCurrentPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground hover:text-foreground">
                      {showCurrentPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
                <div className="relative">
                  <Input type={showNewPassword ? "text" : "password"} placeholder="New Password" className="pr-10"/>
                  <button type="button" onClick={() => setShowNewPassword(!showNewPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground hover:text-foreground">
                      {showNewPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
                <Button type="submit">Update Password</Button>
              </div>
            </div>
          
            <Separator />
          
            <div className="flex items-center justify-between" id="2fa-container">
              <div>
                <Label className="font-medium text-sm">Two-Factor Authentication (2FA)</Label>
                <p className="text-xs text-muted-foreground">Status: <span className="font-medium text-green-500">Enabled</span>. 2FA is mandatory.</p>
              </div>
              <Dialog open={is2faDialogOpen} onOpenChange={setIs2faDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">View Setup</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Setup Two-Factor Authentication</DialogTitle>
                    <DialogDescription>Scan the QR code with your authenticator app (e.g., Google Authenticator).</DialogDescription>
                  </DialogHeader>
                  <div className="flex flex-col items-center justify-center p-4 gap-4">
                    <QRCode
                      value={`otpauth://totp/PerspectivePMO:${userProfile.email}?secret=JBSWY3DPEHPK3PXP&issuer=PerspectivePMO`}
                      size={200}
                      bgColor="#ffffff"
                      fgColor="#000000"
                      level="L"
                      includeMargin={false}
                      />
                    <p className="text-sm text-muted-foreground">After scanning, enter the code to verify.</p>
                    <div className="flex w-full max-w-sm items-center space-x-2">
                      <Input type="text" placeholder="6-digit code" />
                      <Button type="submit" onClick={() => {
                        setIs2faDialogOpen(false);
                        toast({
                          title: "2FA Enabled",
                          description: "Two-factor authentication has been successfully configured.",
                        });
                      }}>Verify</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={isRestoreConfirmOpen} onOpenChange={setIsRestoreConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will <span className="font-bold text-destructive">OVERWRITE ALL EXISTING DATA</span> with the contents of the file <span className="font-semibold text-foreground">{restoreFile?.name}</span>. This cannot be undone. To confirm, type "OVERWRITE" below.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-2">
            <Input 
              value={restoreConfirmText}
              onChange={(e) => setRestoreConfirmText(e.target.value)}
              placeholder='Type "OVERWRITE" to confirm'
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRestoreConfirmText('')}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmRestore} disabled={restoreConfirmText !== "OVERWRITE" || isRestoring}>
              {isRestoring && <div className="ai-spinner mr-2" />}
              Confirm & Restore
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
