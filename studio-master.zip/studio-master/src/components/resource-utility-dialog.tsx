
"use client"

import { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { Task, UserProfile } from "@/lib/types";

interface ResourceUtilityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tasks: Task[];
  team: UserProfile[];
  userProfile: UserProfile | null;
}

export function ResourceUtilityDialog({ open, onOpenChange, tasks, team, userProfile }: ResourceUtilityDialogProps) {

  const teamMembers = useMemo(() => {
    if (!userProfile) return [];
    return team.filter(t => t.reviewerId === userProfile.uid);
  }, [team, userProfile]);

  const workloadData = useMemo(() => {
    return teamMembers.map(member => {
      const memberTasks = tasks.filter(t => t.assigneeId === member.uid && t.status !== 'completed');
      const totalHours = memberTasks.reduce((sum, task) => sum + task.estimatedHours, 0);
      return {
        ...member,
        activeTasks: memberTasks.length,
        totalHours,
      };
    }).sort((a,b) => b.totalHours - a.totalHours);
  }, [teamMembers, tasks]);

  const getInitials = (name: string) => {
    return name ? name.split(' ').map(n => n[0]).join('').toUpperCase() : '';
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Resource Utility Mapping</DialogTitle>
          <DialogDescription>
            A forward-looking overview of your team's current workload based on active, assigned tasks.
          </DialogDescription>
        </DialogHeader>
        <DialogBody>
            <div className="border rounded-lg">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Team Member</TableHead>
                            <TableHead>Designation</TableHead>
                            <TableHead className="text-center">Active Tasks</TableHead>
                            <TableHead className="text-right">Total Estimated Hours</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {workloadData.map(member => (
                            <TableRow key={member.uid}>
                                <TableCell>
                                    <div className="flex items-center gap-3">
                                        <Avatar className="h-9 w-9">
                                            <AvatarImage src={`https://placehold.co/40x40/A093E2/FFFFFF.png?text=${getInitials(member.name)}`} alt={member.name} data-ai-hint="person avatar"/>
                                            <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                                        </Avatar>
                                        <span className="font-medium">{member.name}</span>
                                    </div>
                                </TableCell>
                                <TableCell>{member.designation}</TableCell>
                                <TableCell className="text-center font-medium">{member.activeTasks}</TableCell>
                                <TableCell className="text-right font-bold">{member.totalHours.toFixed(2)} hrs</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                 {workloadData.length === 0 && (
                    <div className="text-center p-8 text-muted-foreground">
                        You do not have any team members reporting to you.
                    </div>
                 )}
            </div>
        </DialogBody>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
