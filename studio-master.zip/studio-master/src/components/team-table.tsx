
"use client"

import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/role-switcher";
import { UserProfile } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { PlusCircle, Upload, Download } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useMasterData } from "@/context/master-data-context";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { roleHierarchy } from "@/data/master-data";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import Link from 'next/link';

interface TeamTableProps {
  team: UserProfile[];
  userProfile: UserProfile;
  onRowClick: (employee: UserProfile) => void;
}

export function TeamTable({ 
    team, 
    userProfile, 
    onRowClick
}: TeamTableProps) {
  const { userProfile: currentUser } = useAuth();
  const { masterData, loading: loadingMasterData } = useMasterData();
  const [departmentFilter, setDepartmentFilter] = useState('all');

  const canManageTeam = currentUser && roleHierarchy[currentUser.role] >= 3;
  
  const filteredTeam = useMemo(() => {
    if (departmentFilter === 'all' || !canManageTeam) return team;
    const department = masterData.departments.find(d => d.id === departmentFilter);
    if (!department) return team;

    return team.filter(member => {
        const memberDepts = Array.isArray(member.department) ? member.department : [member.department];
        return memberDepts.includes(department.name);
    });
  }, [team, departmentFilter, canManageTeam, masterData.departments]);

  if (team.length === 0 && !loadingMasterData) {
    return (
      <EmptyState
        title="No Team Members"
        description={canManageTeam ? "Add new employees to the system." : "No team members are assigned to your projects."}
      />
    )
  }

  const formatDepartments = (departments: string | string[]) => {
    if (Array.isArray(departments)) {
      return departments.join(', ');
    }
    return departments;
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Team Members</CardTitle>
              <CardDescription>An overview of all users in the system.</CardDescription>
            </div>
           {canManageTeam && (
            <div className="flex items-center gap-4">
                <div className="w-64">
                    <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                        <SelectTrigger>
                            <SelectValue placeholder="Filter by department..." />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Departments</SelectItem>
                            {masterData.departments.map(dep => (
                                <SelectItem key={dep.id} value={dep.id}>{dep.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
           )}
        </CardHeader>
        <CardContent>
          <div className="rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-bold">Name</TableHead>
                  <TableHead className="font-bold">Department</TableHead>
                  <TableHead className="font-bold">Designation</TableHead>
                  <TableHead className="font-bold">Role</TableHead>
                  <TableHead className="font-bold text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTeam.map(member => (
                  <TableRow key={member.uid}>
                    <TableCell className="font-medium">
                        <Button variant="link" asChild className="p-0 h-auto font-normal text-foreground">
                            <Link href={`/employee-tasks/${member.uid}`}>{member.name}</Link>
                        </Button>
                    </TableCell>
                    <TableCell onClick={() => onRowClick(member)} className="cursor-pointer">{formatDepartments(member.department)}</TableCell>
                    <TableCell onClick={() => onRowClick(member)} className="cursor-pointer">{member.designation}</TableCell>
                    <TableCell onClick={() => onRowClick(member)} className="cursor-pointer">{member.role}</TableCell>
                    <TableCell className="text-center cursor-pointer" onClick={() => onRowClick(member)}>
                      <Badge
                        variant={member.status === 'active' ? 'default' : 'secondary'}
                        className={member.status === 'active' ? 'bg-green-100 text-green-800' : ''}
                      >
                        {member.status.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </>
  )
}
