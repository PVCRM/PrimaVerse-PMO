"use client"

import React from 'react';

function GradientBackground() {
  return (
    <div className="absolute inset-0 -z-50 pointer-events-none overflow-hidden">
      <div className="relative h-full w-full opacity-10 dark:opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_hsl(var(--primary)/0.25),_transparent_80%)] animated-gradient-1" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_hsl(var(--accent)/0.25),_transparent_80%)] animated-gradient-2" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_hsl(var(--chart-2)/0.25),_transparent_80%)] animated-gradient-3" />
      </div>
    </div>
  );
}

// Memoize the component to prevent re-renders when the parent component updates.
// Since this component has no props and relies only on CSS, it should only render once.
export const AnimatedGradientBackground = React.memo(GradientBackground);
