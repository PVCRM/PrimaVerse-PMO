
"use client"

import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import type { Client, UserProfile } from "@/lib/types";
import { EmptyState } from "./role-switcher";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePermissions } from "@/hooks/use-permissions";
import { Badge } from "./ui/badge";
import { cn } from "@/lib/utils";
import { Upload, PlusCircle } from "lucide-react";
import { ImportClientsDialog } from "./import-clients-dialog";
import { useClients } from "@/hooks/use-clients";
import { useTeam } from "@/hooks/use-team";
import { useToast } from "@/hooks/use-toast";

interface ClientsTableProps {
  clients: Client[];
  userProfile: UserProfile;
  onRowClick: (client: Client) => void;
}

export function ClientsTable({ clients, userProfile, onRowClick }: ClientsTableProps) {
    const { permissions } = usePermissions();
    const canManageClients = permissions[userProfile.role]?.clients === 'CRUD' || permissions[userProfile.role]?.clients === 'CRUD + Billing';
    const [isImportOpen, setIsImportOpen] = useState(false);
    const { bulkAddClients, refetch } = useClients(true);
    const { team } = useTeam();
    const { toast } = useToast();
    
    const activeClients = clients.filter(c => c.status === 'Active');
    const pastClients = clients.filter(c => c.status === 'Inactive');

    const handleImport = async (data: any[]) => {
      const results = await bulkAddClients(data, team);
      if (results.successes > 0) {
        toast({
          title: "Import Successful",
          description: `${results.successes} clients were imported.`
        });
        refetch();
      }
      return results;
    };

    return (
      <>
        <Card className="rounded-xl border shadow-none">
            <CardHeader>
                <CardTitle>Clients</CardTitle>
                <CardDescription>An overview of all client accounts.</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="active">
                    <TabsList>
                        <TabsTrigger value="active">Active Clients</TabsTrigger>
                        <TabsTrigger value="completed">Completed Clients</TabsTrigger>
                    </TabsList>
                    <TabsContent value="active">
                        <PaginatedTable
                            clients={activeClients}
                            onRowClick={onRowClick}
                            emptyStateTitle="No Active Clients"
                            emptyStateDescription="Active clients will appear here."
                        />
                    </TabsContent>
                    <TabsContent value="completed">
                         <PaginatedTable
                            clients={pastClients}
                            onRowClick={onRowClick}
                            emptyStateTitle="No Completed Clients"
                            emptyStateDescription="Completed clients will appear here."
                            isCompletedTab={true}
                        />
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
        <ImportClientsDialog
          open={isImportOpen}
          onOpenChange={setIsImportOpen}
          onImport={handleImport}
        />
      </>
    );
}

function PaginatedTable({ clients, onRowClick, emptyStateTitle, emptyStateDescription, isCompletedTab = false }: any) {
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 6;
    const totalPages = Math.ceil(clients.length / rowsPerPage);
    const paginatedClients = clients.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

    if (clients.length === 0) {
        return (
            <div className="pt-4">
                <EmptyState 
                    title={emptyStateTitle} 
                    description={emptyStateDescription}
                />
            </div>
        )
    }

    return (
        <>
            <div className="rounded-lg mt-4">
                <Table>
                    <TableHeader>
                    <TableRow>
                        <TableHead className="w-[300px] font-bold">Client</TableHead>
                        <TableHead className="font-bold">Primary Contact</TableHead>
                        <TableHead className="font-bold">Projects</TableHead>
                        <TableHead className="text-right font-bold">Employees</TableHead>
                        <TableHead className="text-right font-bold">Status</TableHead>
                    </TableRow>
                    </TableHeader>
                    <TableBody>
                    {paginatedClients.map((client: Client) => {
                        const primaryCoordinator = client.coordinators && client.coordinators[0];
                        return (
                        <TableRow key={client.id} onClick={() => onRowClick(client)} className="cursor-pointer">
                            <TableCell>
                            <div className="flex items-center gap-4">
                                <Avatar className="h-10 w-10 border">
                                    <AvatarImage src={client.logo} alt={client.name} data-ai-hint="company logo"/>
                                    <AvatarFallback>{client.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                <div className="font-medium">{client.name}</div>
                                <div className="text-sm text-muted-foreground">{client.code}</div>
                                </div>
                            </div>
                            </TableCell>
                            <TableCell>{primaryCoordinator ? `${primaryCoordinator.firstName} ${primaryCoordinator.lastName}` : 'N/A'}</TableCell>
                            <TableCell className="font-medium">{client.projectCount || 0}</TableCell>
                            <TableCell className="text-right font-medium">{client.employeeCount || 0}</TableCell>
                            <TableCell className="text-right">
                                <Badge variant={isCompletedTab ? 'default' : 'secondary'} className={cn(isCompletedTab && "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300")}>{client.status}</Badge>
                            </TableCell>
                        </TableRow>
                        );
                    })}
                    </TableBody>
                </Table>
            </div>
            <div className="flex items-center justify-end space-x-2 py-4">
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</Button>
                <span className="text-sm text-muted-foreground">Page {currentPage} of {totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</Button>
            </div>
        </>
    );
}
