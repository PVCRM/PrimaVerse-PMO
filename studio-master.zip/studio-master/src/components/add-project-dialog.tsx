

"use client"

import { useState, useEffect, useMemo } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CalendarIcon, PlusCircle, Trash2 } from "lucide-react";
import { format } from "date-fns";
import Image from "next/image";

import { cn } from "@/lib/utils";
import type { Project, Client, UserProfile, Department, ProjectType } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useMasterData } from "@/context/master-data-context";
import { roleHierarchy } from "@/data/master-data";
import { useAuth } from "@/hooks/use-auth";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogBody,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

const projectFormSchema = z.object({
  name: z.string().min(1, "Project name is required."),
  clientId: z.string().min(1, "Please select a client."),
  projectTypeId: z.string().min(1, "Please select a project type."),
  projectManagerId: z.string().min(1, "Please assign a project manager."),
  teamLeadIds: z.array(z.object({ id: z.string() })).optional(),
  startDate: z.date({ required_error: "Start date is required." }),
  estimatedHours: z.coerce.number().min(1, "Please enter the estimated hours."),
  status: z.enum(['Active', 'Inactive']),
});


type ProjectFormValues = z.infer<typeof projectFormSchema>;

interface AddProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (projectData: Omit<Project, 'id'>, projectId?: string) => Promise<void>;
  projectToEdit?: Project | null;
  clients: Client[];
  team: UserProfile[];
  onDataChange: () => void;
  userProfile: UserProfile | null;
}

export function AddProjectDialog({
  open,
  onOpenChange,
  onSave,
  projectToEdit,
  clients,
  team,
  onDataChange,
  userProfile,
}: AddProjectDialogProps) {
  const { toast } = useToast();
  const { masterData } = useMasterData();
  const [isSaving, setIsSaving] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isStartDatePickerOpen, setStartDatePickerOpen] = useState(false);
  const isEditMode = !!projectToEdit;

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: "",
      clientId: "",
      projectTypeId: "",
      projectManagerId: "",
      teamLeadIds: [],
      startDate: undefined,
      estimatedHours: 0,
      status: 'Active',
    },
  });
  
  const { fields: leadFields, append: appendLead, remove: removeLead } = useFieldArray({
    control: form.control,
    name: "teamLeadIds",
  });
  
  const selectedClientId = form.watch('clientId');
  const selectedTeamLeadIds = form.watch('teamLeadIds')?.map(item => item.id) || [];
  
  const activeTeam = useMemo(() => team.filter(t => t.status === 'active'), [team]);

  const clientOptions = useMemo(() => {
    if (!userProfile) return [];
    if (roleHierarchy[userProfile.role] >= roleHierarchy['Director/VP/CXO']) {
      return clients;
    }
    return clients.filter(client => 
        client.projectManagerId === userProfile.uid || 
        (client.teamLeadIds || []).includes(userProfile.uid) ||
        client.duLeadId === userProfile.uid
    );
  }, [clients, userProfile]);

  useEffect(() => {
    if (open) {
      if (isEditMode && projectToEdit) {
        form.reset({
          name: projectToEdit.name,
          clientId: projectToEdit.clientId,
          projectTypeId: projectToEdit.projectTypeId,
          projectManagerId: projectToEdit.projectManagerId,
          teamLeadIds: (projectToEdit.teamLeadIds || []).map(id => ({ id })),
          startDate: new Date(projectToEdit.startDate),
          estimatedHours: projectToEdit.estimatedHours || 0,
          status: projectToEdit.status,
        });
        const client = clients.find(c => c.id === projectToEdit.clientId);
        setSelectedClient(client || null);
      } else {
        form.reset({
          name: "",
          clientId: "",
          projectTypeId: "",
          projectManagerId: "",
          teamLeadIds: [],
          startDate: undefined,
          estimatedHours: 0,
          status: 'Active',
        });
        setSelectedClient(null);
      }
    }
  }, [projectToEdit, isEditMode, open, form, clients]);
  
  useEffect(() => {
    const client = clients.find(c => c.id === selectedClientId);
    setSelectedClient(client || null);
    
    if (form.formState.isDirty && !isEditMode) {
        form.setValue('projectTypeId', '');
        form.setValue('projectManagerId', '');
        form.setValue('teamLeadIds', []);
    }
  }, [selectedClientId, clients, form, isEditMode]);

  
  const projectManagerOptions = useMemo(() => {
    if (!selectedClient) return [];
    const clientTeamIds = new Set([
        selectedClient.duLeadId,
        selectedClient.projectManagerId,
        ...selectedClient.teamLeadIds,
        ...selectedClient.teamMemberIds
    ]);
    return activeTeam.filter(member => 
        clientTeamIds.has(member.uid) &&
        member.role === 'Project Manager' && 
        (Array.isArray(member.department) ? member.department.includes(selectedClient.department) : member.department === selectedClient.department)
    );
  }, [selectedClient, activeTeam]);
  
  const teamLeadOptions = useMemo(() => {
    if (!selectedClient) return [];
     const clientTeamIds = new Set([
        selectedClient.duLeadId,
        selectedClient.projectManagerId,
        ...selectedClient.teamLeadIds,
        ...selectedClient.teamMemberIds
    ]);
    return activeTeam.filter(member => 
        clientTeamIds.has(member.uid) &&
        member.role === 'Team Lead' && 
        (Array.isArray(member.department) ? member.department.includes(selectedClient.department) : member.department === selectedClient.department)
    );
  }, [selectedClient, activeTeam]);
  
  const projectTypeOptions = useMemo(() => {
    if (!selectedClient) return [];
    const department = masterData.departments.find(d => d.name === selectedClient.department);
    if (!department) return [];
    return masterData.projectTypes.filter(pt => pt.departmentId === department.id);
  }, [selectedClient, masterData.departments, masterData.projectTypes]);


  const handleClose = () => {
    onOpenChange(false);
  };
  
  const handleClear = () => {
      form.reset();
      setSelectedClient(null);
  }

  async function onSubmit(data: ProjectFormValues) {
    setIsSaving(true);
    if (!selectedClient) {
      toast({ variant: "destructive", title: "Error", description: "A client must be selected." });
      setIsSaving(false);
      return;
    }

    try {
      const teamLeadIds = data.teamLeadIds?.map(item => item.id) || [];
      const existingTeamMembers = projectToEdit?.teamMemberIds || [];

      const teamIds = [
        data.projectManagerId,
        ...teamLeadIds,
        ...existingTeamMembers,
      ].filter((id, index, self) => id && self.indexOf(id) === index);

      const projectData: Omit<Project, 'id'> = {
        name: data.name,
        clientId: data.clientId,
        projectTypeId: data.projectTypeId,
        projectManagerId: data.projectManagerId,
        startDate: data.startDate,
        estimatedHours: data.estimatedHours,
        status: data.status,
        clientName: selectedClient.name,
        department: selectedClient.department,
        teamLeadIds: teamLeadIds,
        teamMemberIds: existingTeamMembers,
        teamIds: teamIds,
      };
      
      await onSave(projectData, projectToEdit?.id);
      onDataChange(); // Refresh data in parent component
      
      toast({
        title: isEditMode ? "Project Updated" : "Project Created",
        description: `Project "${data.name}" has been saved.`,
      });
      handleClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Could not save the project.",
      });
    } finally {
      setIsSaving(false);
    }
  }

  const canEditBillingHours = userProfile && roleHierarchy[userProfile.role] >= 2;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <DialogHeader>
              <DialogTitle>{isEditMode ? "Edit Project" : "Create New Project"}</DialogTitle>
              <DialogDescription>
                Fill in the details below to {isEditMode ? "update the" : "create a new"} project.
              </DialogDescription>
            </DialogHeader>
            <DialogBody>
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="clientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value} disabled={isEditMode}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Select a client" /></SelectTrigger></FormControl>
                        <SelectContent>
                          {clientOptions.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {selectedClient && (
                  <Card className="bg-muted/50">
                    <CardContent className="p-4 grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border">
                          <AvatarImage src={selectedClient.logo} alt={selectedClient.name} data-ai-hint="company logo"/>
                          <AvatarFallback>{selectedClient.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold text-sm">{selectedClient.name}</p>
                          <p className="text-xs text-muted-foreground">{selectedClient.code}</p>
                        </div>
                      </div>
                       <FormItem>
                        <FormLabel>Department</FormLabel>
                        <Input value={selectedClient.department} readOnly disabled/>
                      </FormItem>
                       <FormItem className="md:col-span-2">
                        <FormLabel>Project Name</FormLabel>
                         <FormField control={form.control} name="name" render={({ field }) => (
                            <FormControl><Input placeholder="e.g., Q4 Marketing Campaign" {...field} /></FormControl>
                         )}/>
                         <FormMessage className="!mt-2">{form.formState.errors.name?.message}</FormMessage>
                      </FormItem>
                    </CardContent>
                  </Card>
                )}

                {selectedClient && (
                  <>
                    <FormField
                        control={form.control}
                        name="projectTypeId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type of Project</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value} disabled={!selectedClient}>
                              <FormControl><SelectTrigger><SelectValue placeholder="Select a project type" /></SelectTrigger></FormControl>
                              <SelectContent>
                                {projectTypeOptions.map(type => <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                    <FormField
                      control={form.control}
                      name="projectManagerId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Project Manager</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value} disabled={!selectedClient}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Assign a manager" /></SelectTrigger></FormControl>
                            <SelectContent>
                              {projectManagerOptions.map(pm => <SelectItem key={pm.uid} value={pm.uid}>{pm.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <h3 className="text-sm font-medium">Team Leads</h3>
                            <Button type="button" variant="outline" size="sm" onClick={() => appendLead({ id: '' })} disabled={!selectedClient || teamLeadOptions.length === 0}>
                                <PlusCircle className="mr-2 h-4 w-4" /> Add Lead
                            </Button>
                        </div>
                        <FormField control={form.control} name="teamLeadIds" render={() => (<FormMessage className="!mt-2" />)} />
                        <div className="space-y-2">
                        {leadFields.map((item, index) => (
                            <div key={item.id} className="flex items-center gap-2">
                                <FormField
                                    control={form.control}
                                    name={`teamLeadIds.${index}.id`}
                                    render={({ field }) => {
                                        const availableOptions = teamLeadOptions.filter(
                                            (opt) => !selectedTeamLeadIds.includes(opt.uid) || opt.uid === field.value
                                        );
                                        return (
                                            <FormItem className="flex-grow">
                                                <Select onValueChange={field.onChange} value={field.value}>
                                                    <FormControl><SelectTrigger><SelectValue placeholder="Select a team lead..." /></SelectTrigger></FormControl>
                                                    <SelectContent>
                                                        {availableOptions.map(pm => <SelectItem key={pm.uid} value={pm.uid}>{pm.name}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        );
                                    }}
                                />
                                <Button type="button" variant="ghost" size="icon" className="shrink-0" onClick={() => removeLead(index)}>
                                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                                </Button>
                            </div>
                        ))}
                        {teamLeadOptions.length === 0 && selectedClient && <p className="text-xs text-muted-foreground">No available team leads in this client's assigned team.</p>}
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField control={form.control} name="startDate" render={({ field }) => (
                        <FormItem><FormLabel>Start Date</FormLabel>
                          <Popover open={isStartDatePickerOpen} onOpenChange={setStartDatePickerOpen}>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button variant="outline" className={cn("w-full justify-start text-left font-normal",!field.value && "text-muted-foreground")}>
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}<CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={(date) => {
                                  field.onChange(date);
                                  setStartDatePickerOpen(false);
                                }}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}/>
                      <FormField control={form.control} name="estimatedHours" render={({ field }) => (
                          <FormItem><FormLabel>Estimated Allotted Billing Hours</FormLabel><FormControl><Input type="number" placeholder="100" {...field} disabled={!canEditBillingHours} /></FormControl><FormMessage /></FormItem>
                      )}/>
                    </div>

                    <FormField control={form.control} name="status" render={({ field }) => (
                        <FormItem><FormLabel>Status</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Set status" /></SelectTrigger></FormControl><SelectContent>
                        {['Active', 'Inactive'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent></Select><FormMessage /></FormItem>
                    )}/>
                  </>
                )}
              </div>
            </DialogBody>
            <DialogFooter>
                <Button type="button" variant="ghost" onClick={handleClose}>Cancel</Button>
                <Button type="button" variant="outline" onClick={handleClear}>Clear</Button>
                <Button type="submit" disabled={isSaving || !selectedClient}>
                    {isSaving && <div className="ai-spinner mr-2" />}
                    {isEditMode ? "Update Project" : "Save Project"}
                </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

