
"use client"

import { useState, useEffect, useMemo } from "react"
import { getProjectHealth, ProjectHealthOutput } from "@/ai/flows/smart-recommendations"
import type { Project, Task } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { Timestamp } from "firebase/firestore"

interface ProjectHealthCardProps {
  projects: Project[]
  tasks: Task[]
  title?: string
  description?: string
}

export function ProjectHealthCard({ 
  projects, 
  tasks, 
  title = "Project Health", 
  description = "AI-powered summary of overall project status." 
}: ProjectHealthCardProps) {
  const [healthInfo, setHealthInfo] = useState<ProjectHealthOutput | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const projectCount = projects.length;
  const taskCount = tasks.length;

  useEffect(() => {
    let isMounted = true;

    const fetchHealthInfo = async () => {
      if (!isMounted) return;
      setIsLoading(true)
      setError(null)
      try {
        const toISO = (date: Date | Timestamp | undefined | null) => {
            if (!date) return undefined;
            if (date instanceof Timestamp) return date.toDate().toISOString();
            if (date instanceof Date) return date.toISOString();
            return undefined;
        }

        const serializableTasks = tasks.map(task => ({
          ...task,
          startDate: toISO(task.startDate),
          dueDate: toISO(task.dueDate),
          startedAt: toISO(task.startedAt),
          completedAt: toISO(task.completedAt),
          activeSince: undefined, // Exclude complex objects
          reviewLog: task.reviewLog?.map(log => ({
            ...log,
            reviewedAt: toISO(log.reviewedAt as any),
          })) || [],
        }));
        
        const serializableProjects = projects.map(project => ({
            ...project,
            startDate: toISO(project.startDate),
            endDate: toISO(project.endDate),
        }));

        const result = await getProjectHealth({ projects: serializableProjects, tasks: serializableTasks })
        if (isMounted) setHealthInfo(result)
      } catch (err) {
        console.error("Failed to get project health.", err)
        if (isMounted) setError("AI analysis is temporarily unavailable. Please try again later.")
      } finally {
        if (isMounted) setIsLoading(false)
      }
    }

    if (projectCount > 0 || taskCount > 0) {
        const timer = setTimeout(fetchHealthInfo, 1000);
        return () => {
          isMounted = false;
          clearTimeout(timer);
        }
    } else {
        setIsLoading(false);
        setHealthInfo({ healthScore: 100, summary: "No project or task data available."});
    }
  }, [projectCount, taskCount]) // Depend on counts, not the objects themselves

  const getScoreColor = (score: number) => {
    if (score > 80) return "text-green-500"
    if (score > 50) return "text-amber-500"
    return "text-red-500"
  }

  return (
    <Card className="rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1 h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">{title}</CardTitle>
        <CardDescription className="text-xs pt-1">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="flex items-center space-x-2 pt-4">
            <div className="ai-spinner"></div>
            <p className="text-sm text-muted-foreground">Analyzing...</p>
          </div>
        )}
        {error && !isLoading && (
          <p className="text-sm text-destructive pt-4">{error}</p>
        )}
        {!isLoading && !error && healthInfo && (
          <>
            <div className="flex items-baseline gap-2">
               <p className={cn("text-3xl font-bold", getScoreColor(healthInfo.healthScore))}>{healthInfo.healthScore}</p>
               <p className="text-xs text-muted-foreground">/ 100</p>
            </div>
            <p className="text-xs text-muted-foreground mt-2">{healthInfo.summary}</p>
          </>
        )}
      </CardContent>
    </Card>
  )
}
