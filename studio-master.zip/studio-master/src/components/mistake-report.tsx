
"use client"

import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, TooltipProps } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import type { Client, Project, Task } from '@/lib/types';
import { NameType, ValueType } from 'recharts/types/component/DefaultTooltipContent';

interface MistakeReportProps {
    clients: Client[];
    projects: Project[];
    tasks: Task[];
}

const CustomTooltip = ({ active, payload, label }: TooltipProps<ValueType, NameType>) => {
    if (active && payload && payload.length) {
        return (
        <div className="rounded-lg border bg-popover p-2 text-sm shadow-sm" style={{filter: 'drop-shadow(0 0 0.75rem hsl(var(--primary) / 0.5))'}}>
            <div className="grid grid-cols-1 gap-1.5">
            <p className="font-medium">{label}</p>
            <p className="text-muted-foreground">
                Mistakes: <span className="font-bold text-foreground">{payload[0].value}</span>
            </p>
            </div>
        </div>
        );
    }

    return null;
};

export function MistakeReport({ clients, projects, tasks }: MistakeReportProps) {
    const clientMistakes = clients.map(client => {
        const clientProjects = projects.filter(p => p.clientId === client.id);
        const projectIds = clientProjects.map(p => p.id);
        const clientTasks = tasks.filter(t => projectIds.includes(t.projectId));
        const totalMistakes = clientTasks.reduce((sum, task) => sum + (task.mistakeCount || 0), 0);
        return { name: client.name, mistakes: totalMistakes };
    }).filter(c => c.mistakes > 0).sort((a, b) => b.mistakes - a.mistakes).slice(0, 5);

    const projectMistakes = projects.map(project => {
        const projectTasks = tasks.filter(t => t.projectId === project.id);
        const totalMistakes = projectTasks.reduce((sum, task) => sum + (task.mistakeCount || 0), 0);
        return { name: project.name, mistakes: totalMistakes };
    }).filter(p => p.mistakes > 0).sort((a, b) => b.mistakes - a.mistakes).slice(0, 5);

    const taskTypeMistakes = tasks.reduce((acc, task) => {
        if (task.mistakeCount && task.mistakeCount > 0) {
            const taskTypeName = task.taskTypeName || 'General';
            if (!acc[taskTypeName]) {
                acc[taskTypeName] = 0;
            }
            acc[taskTypeName] += task.mistakeCount;
        }
        return acc;
    }, {} as Record<string, number>);

    const taskTypeData = Object.entries(taskTypeMistakes).map(([name, mistakes]) => ({ name, mistakes })).sort((a, b) => b.mistakes - a.mistakes).slice(0, 5);

    const renderChart = (data: any[], title: string, dataKey: string) => (
        <Card className="shadow-none rounded-xl p-2 h-full">
            <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">Mistake Report</CardTitle>
                <CardDescription className="text-xs pt-1">{title}</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                        <XAxis type="number" fontSize={12} />
                        <YAxis dataKey="name" type="category" width={80} fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip
                           cursor={{ fill: 'hsl(var(--accent) / 0.2)' }}
                           content={<CustomTooltip />}
                        />
                        <Bar dataKey={dataKey} fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {renderChart(clientMistakes, 'Client Wise', 'mistakes')}
            {renderChart(projectMistakes, 'Project Wise', 'mistakes')}
            {renderChart(taskTypeData, 'Task Wise', 'mistakes')}
        </div>
    );
}

    