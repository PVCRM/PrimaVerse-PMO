
"use client"

import { useState, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import type { UserProfile, UserRole, Department, Designation } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useMasterData } from "@/context/master-data-context";
import { majorPhoneCountryCodes } from "@/data/mock-data";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogBody,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Combobox } from "@/components/ui/combobox";
import { MultiSelect } from "./ui/multi-select";


const editEmployeeFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  employeeId: z.string().min(1, "Employee ID is required"),
  department: z.array(z.string()).min(1, "At least one department is required"),
  mobileCountryCode: z.string().min(1, "Country code is required"),
  mobileNumber: z.string().min(1, "Mobile number is required"),
  designation: z.string().min(1, "Designation is required"), // This will hold the ID
  role: z.string().min(1, "A role is required."),
});

// This type is for the form state (with designation as id)
export type EditEmployeeFormValues = z.infer<typeof editEmployeeFormSchema>;
// This type is for what the onSave function expects (with designation as name)
export type EditEmployeeOnSaveValues = Omit<EditEmployeeFormValues, 'designation' | 'role'> & { designation: string, role: UserRole };


interface EditEmployeeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (formData: EditEmployeeOnSaveValues) => Promise<void>;
  employeeToEdit: UserProfile | null;
  currentUserProfile: UserProfile | null;
}

export function EditEmployeeDialog({
  open,
  onOpenChange,
  onSave,
  employeeToEdit,
  currentUserProfile,
}: EditEmployeeDialogProps) {
  const { toast } = useToast();
  const { masterData } = useMasterData();
  const { departments, designations, roles } = masterData;
  const [isSaving, setIsSaving] = useState(false);

  const isEditingSelf = employeeToEdit?.uid === currentUserProfile?.uid;
  
  const form = useForm<EditEmployeeFormValues>({
    resolver: zodResolver(editEmployeeFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      employeeId: "",
      department: [],
      mobileCountryCode: "91",
      mobileNumber: "",
      designation: "",
      role: "",
    },
  });
  
  const departmentValue = form.watch('department');
  
  const designationOptions = useMemo(() => {
    if (!departmentValue || departmentValue.length === 0) return [];
    
    const selectedDeptIds = departments.filter(d => departmentValue.includes(d.name)).map(d => d.id);
    return designations.filter(d => selectedDeptIds.includes(d.departmentId));
  }, [departmentValue, departments, designations]);

  useEffect(() => {
    if (employeeToEdit && departments.length > 0 && designations.length > 0) {
      const nameParts = employeeToEdit.name.split(' ');
      const fName = employeeToEdit.firstName || nameParts[0] || '';
      const lName = employeeToEdit.lastName || nameParts.slice(1).join(' ') || '';
      
      const currentDepartments = Array.isArray(employeeToEdit.department) ? employeeToEdit.department : [employeeToEdit.department];
      
      const currentDeptIds = departments.filter(d => currentDepartments.includes(d.name)).map(d => d.id);

      const currentDesignation = designations.find(d => 
        d.name === employeeToEdit.designation && currentDeptIds.includes(d.departmentId)
      );

      form.reset({
        firstName: fName,
        lastName: lName,
        employeeId: employeeToEdit.employeeId,
        department: currentDepartments,
        mobileCountryCode: employeeToEdit.mobileCountryCode || '91',
        mobileNumber: employeeToEdit.mobileNumber || '',
        designation: currentDesignation?.id || '',
        role: employeeToEdit.role,
      });
    }
  }, [employeeToEdit, departments, designations, form]);
  
  useEffect(() => {
      const selectedDesignationId = form.getValues('designation');
      if (selectedDesignationId && !designationOptions.some(d => d.id === selectedDesignationId)) {
          form.setValue('designation', '');
      }
  }, [departmentValue, designationOptions, form]);

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  async function onSubmit(data: EditEmployeeFormValues) {
    setIsSaving(true);
    try {
      const selectedDesignation = designations.find(d => d.id === data.designation);
      if (!selectedDesignation) {
        toast({ variant: 'destructive', title: 'Error', description: 'A valid designation must be selected.' });
        setIsSaving(false);
        return;
      }
      
      const dataForSave: EditEmployeeOnSaveValues = {
        ...data,
        designation: selectedDesignation.name,
        role: data.role as UserRole,
      };

      await onSave(dataForSave);
      handleClose(); // Close on success
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Could not update the employee.",
      });
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Employee Profile</DialogTitle>
          <DialogDescription>
            Update the details for {employeeToEdit?.name}.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <DialogBody>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="firstName" render={({ field }) => (
                        <FormItem><FormLabel>First Name</FormLabel><FormControl><Input placeholder="John" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name="lastName" render={({ field }) => (
                        <FormItem><FormLabel>Last Name</FormLabel><FormControl><Input placeholder="Doe" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name="employeeId" render={({ field }) => (
                        <FormItem><FormLabel>Employee ID</FormLabel><FormControl><Input placeholder="EMP001" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                     <FormItem>
                        <FormLabel>Email ID</FormLabel>
                        <Input value={employeeToEdit?.email || ''} disabled />
                    </FormItem>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                        control={form.control}
                        name="department"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Department(s)</FormLabel>
                            <FormControl>
                            <MultiSelect
                                options={departments.map(d => ({ value: d.name, label: d.name }))}
                                selected={field.value}
                                onChange={field.onChange}
                                placeholder="Select department(s)..."
                            />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                     <FormField control={form.control} name="designation" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Designation</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value} disabled={!departmentValue || departmentValue.length === 0}>
                                <FormControl><SelectTrigger><SelectValue placeholder={departmentValue ? "Select designation" : "Select department first"} /></SelectTrigger></FormControl>
                                <SelectContent>
                                    {designationOptions.map(des => <SelectItem key={des.id} value={des.id}>{des.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}/>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormItem>
                        <FormLabel>Mobile Phone</FormLabel>
                        <div className="flex gap-2">
                             <FormField control={form.control} name="mobileCountryCode" render={({ field }) => (
                                <FormItem className="w-24 shrink-0">
                                    <FormControl>
                                        <Combobox options={majorPhoneCountryCodes} value={field.value} onChange={field.onChange} placeholder="+91" />
                                    </FormControl>
                                </FormItem>
                            )}/>
                            <FormField control={form.control} name="mobileNumber" render={({ field }) => (
                                <FormItem className="flex-grow"><FormControl><Input type="tel" placeholder="9876543210" {...field} /></FormControl></FormItem>
                            )}/>
                        </div>
                        <FormMessage>{form.formState.errors.mobileCountryCode?.message || form.formState.errors.mobileNumber?.message}</FormMessage>
                    </FormItem>
                     <FormField
                        control={form.control}
                        name="role"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Role</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value} disabled={isEditingSelf}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select a role" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {roles.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                                {isEditingSelf && <FormDescription>You cannot change your own role.</FormDescription>}
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </div>
              </div>
            </DialogBody>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={handleClose}>Cancel</Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <div className="ai-spinner mr-2" />}
                Update Employee
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
