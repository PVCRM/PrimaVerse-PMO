
"use client"

import { useState, useRef, useEffect, useMemo } from "react"
import { useForm, useFieldArray } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Country, State, City } from "country-state-city"
import { CalendarIcon, PlusCircle, Trash2, Upload, WandSparkles, X, ChevronsUpDown } from "lucide-react"
import { format } from "date-fns"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Combobox, ComboboxOption } from "@/components/ui/combobox"
import { Badge } from "@/components/ui/badge"
import { MultiSelect } from "@/components/ui/multi-select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";


import { useToast } from "@/hooks/use-toast"
import { useMasterData } from "@/context/master-data-context"
import { majorPhoneCountryCodes } from "@/data/mock-data"
import { roleHierarchy } from "@/data/master-data"
import { generateTagsFromNotes } from "@/ai/flows/generate-tags-flow"
import type { Client, UserProfile, Department, UserRole } from "@/lib/types"

const MAX_FILE_SIZE = 500 * 1024; // 500KB
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png"];

const coordinatorSchema = z.object({
  id: z.string().optional(),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email(),
  officePhoneCountryCode: z.string().min(1),
  officePhoneNumber: z.string().min(1),
  officePhoneExt: z.string().optional(),
  mobilePhoneCountryCode: z.string().min(1),
  mobilePhoneNumber: z.string().min(1),
  streetAddress: z.string().min(1),
  country: z.string().min(1),
  state: z.string().min(1),
  city: z.string().min(1),
  zipcode: z.string().min(1),
});

const clientFormSchema = z.object({
  clientName: z.string().min(1, "Client name is required."),
  clientCode: z.string().min(1, "Client code is required."),
  clientLogo: z.any().optional()
    .refine((file) => !file || file?.size <= MAX_FILE_SIZE, `Max file size is 500KB.`)
    .refine(
      (file) => !file || ACCEPTED_IMAGE_TYPES.includes(file?.type),
      ".jpg and .png files are accepted."
    )
    .refine(async (file) => {
      if (!file || typeof window === 'undefined') return true;
      try {
        const image = new window.Image();
        const objectUrl = URL.createObjectURL(file);
        const promise = new Promise<boolean>((resolve) => {
          image.onload = () => {
            URL.revokeObjectURL(objectUrl);
            resolve(image.width === image.height);
          };
          image.onerror = () => {
            URL.revokeObjectURL(objectUrl);
            resolve(false);
          };
          image.src = objectUrl;
        });
        return await promise;
      } catch (error) {
        return false;
      }
    }, "Image must have a 1:1 aspect ratio."),
  department: z.string().min(1, "Department is required."),
  startDate: z.date(),
  coordinators: z.array(coordinatorSchema).min(1, "At least one coordinator is required."),
  duLeadId: z.string().min(1, "Please assign a DU Lead."),
  projectManagerId: z.string().min(1, "Please assign a Project Manager."),
  teamLeadIds: z.array(z.string()).min(1, "Assign at least one team lead."),
  teamMemberIds: z.array(z.string()).min(1, "Assign at least one team member."),
  salesPersonId: z.string().min(1, "Please assign a sales person."),
  notes: z.string().optional(),
});

type ClientFormValues = z.infer<typeof clientFormSchema>;

const countries = Country.getAllCountries().map(c => ({ value: c.isoCode, label: `${c.name}` }));

interface AddClientDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onSave: (clientData: Omit<Client, 'id'>, clientId?: string) => Promise<void>;
    clientToEdit?: Client | null;
    team: UserProfile[];
}

const emptyFormValues = {
      clientName: "",
      clientCode: "",
      clientLogo: null,
      department: "",
      startDate: new Date(),
      coordinators: [{ firstName: '', lastName: '', email: '', officePhoneCountryCode: '1', officePhoneNumber: '', officePhoneExt: '', mobilePhoneCountryCode: '1', mobilePhoneNumber: '', streetAddress: '', country: '', state: '', city: '', zipcode: '' }],
      duLeadId: "",
      projectManagerId: "",
      teamLeadIds: [],
      teamMemberIds: [],
      salesPersonId: "",
      notes: "",
    };

export function AddClientDialog({ open, onOpenChange, onSave, clientToEdit, team }: AddClientDialogProps) {
  const { toast } = useToast();
  const { masterData } = useMasterData();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [generatedTags, setGeneratedTags] = useState<string[]>([]);
  const [isGeneratingTags, setIsGeneratingTags] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDatePickerOpen, setDatePickerOpen] = useState(false);
  const [openCoordinators, setOpenCoordinators] = useState<string[]>([]);


  const isEditMode = !!clientToEdit;

  const form = useForm<ClientFormValues>({
    resolver: zodResolver(clientFormSchema),
    defaultValues: emptyFormValues,
  });

  const departmentValue = form.watch('department');
  const duLeadIdValue = form.watch('duLeadId');
  const projectManagerIdValue = form.watch('projectManagerId');
  const teamLeadIdsValue = form.watch('teamLeadIds');
  const prevDepartmentRef = useRef<string>();

  const activeTeam = useMemo(() => team.filter(t => t.status === 'active'), [team]);

  useEffect(() => {
    if (prevDepartmentRef.current && prevDepartmentRef.current !== departmentValue) {
      form.setValue('duLeadId', '');
      form.setValue('projectManagerId', '');
      form.setValue('teamLeadIds', []);
      form.setValue('teamMemberIds', []);
      form.setValue('salesPersonId', '');
    }
    prevDepartmentRef.current = departmentValue;
  }, [departmentValue, form]);

  const teamInDept = useMemo(() => {
    if (!departmentValue || !activeTeam || !masterData.departments.length) return [];
    
    const selectedDept = masterData.departments.find(d => d.id === departmentValue);
    if (!selectedDept) return [];
    
    return activeTeam.filter(member => {
        const memberDepts = Array.isArray(member.department) ? member.department : [member.department];
        return memberDepts.includes(selectedDept.name);
    });
  }, [departmentValue, activeTeam, masterData.departments]);

  const duLeadOptions = useMemo(() => teamInDept
    .filter(member => roleHierarchy[member.role] >= 3)
    .map(member => ({ value: member.uid, label: `${member.name} (${member.designation})` })), [teamInDept]);

  const projectManagerOptions = useMemo(() => teamInDept
    .filter(member => roleHierarchy[member.role] >= 2 && member.uid !== duLeadIdValue)
    .map(member => ({ value: member.uid, label: `${member.name} (${member.designation})` })), [teamInDept, duLeadIdValue]);

  const teamLeadOptions = useMemo(() => teamInDept
    .filter(member => roleHierarchy[member.role] >= 1 && member.uid !== duLeadIdValue && member.uid !== projectManagerIdValue)
    .map(member => ({ value: member.uid, label: `${member.name} (${member.designation})` })), [teamInDept, duLeadIdValue, projectManagerIdValue]);
  
  const teamMemberOptions = useMemo(() => teamInDept
    .filter(member => roleHierarchy[member.role] === 0)
    .map(member => ({ value: member.uid, label: member.name })), [teamInDept]);

  const salesTeamOptions = useMemo(() => {
    if (!activeTeam) return [];
    return activeTeam
      .filter(member => Array.isArray(member.department) ? member.department.includes('Sales') : member.department === 'Sales')
      .map(member => ({ value: member.uid, label: member.name }));
  }, [activeTeam]);

  useEffect(() => {
    if (open) {
      if (isEditMode && clientToEdit) {
        const selectedDepartment = masterData.departments.find(d => d.name === clientToEdit.department);
        const coordsWithId = clientToEdit.coordinators.map((c, i) => ({ ...c, id: c.id || `coord-${Date.now()}-${i}` }));
        
        const defaultValues = {
          clientName: clientToEdit.name,
          clientCode: clientToEdit.code,
          clientLogo: null, 
          department: selectedDepartment?.id || '',
          startDate: new Date(clientToEdit.startDate),
          coordinators: coordsWithId,
          duLeadId: clientToEdit.duLeadId,
          projectManagerId: clientToEdit.projectManagerId,
          teamLeadIds: clientToEdit.teamLeadIds || [],
          teamMemberIds: clientToEdit.teamMemberIds,
          salesPersonId: clientToEdit.salesPersonId,
          notes: clientToEdit.notes,
        };
        form.reset(defaultValues);
        setLogoPreview(clientToEdit.logo);
        setGeneratedTags(clientToEdit.tags);
        setOpenCoordinators([]);
      } else {
        form.reset(emptyFormValues); 
        setLogoPreview(null);
        setGeneratedTags([]);
        setOpenCoordinators(['coord-0']);
      }
    }
  }, [clientToEdit, isEditMode, open, form, masterData.departments]);


  const { fields: coordinatorFields, append: appendCoordinator, remove: removeCoordinator } = useFieldArray({
    control: form.control,
    name: "coordinators",
  });
  
  const handleClose = () => {
    onOpenChange(false);
  }

  async function onSubmit(data: ClientFormValues) {
    setIsSaving(true);
    const logoUrl = logoPreview || 'https://placehold.co/40x40.png';
    const selectedDeptName = masterData.departments.find(d => d.id === data.department)?.name;
    if (!selectedDeptName) {
        toast({ variant: 'destructive', title: 'Save Error', description: 'Invalid department selected.' });
        setIsSaving(false);
        return;
    }


    const newClientData: Omit<Client, 'id'> = {
        name: data.clientName,
        code: data.clientCode,
        logo: logoUrl,
        department: selectedDeptName,
        startDate: data.startDate,
        coordinators: data.coordinators.map((c, i) => ({ ...c, id: c.id || `coord-${Date.now()}-${i}` })),
        duLeadId: data.duLeadId,
        projectManagerId: data.projectManagerId,
        teamLeadIds: data.teamLeadIds || [],
        teamMemberIds: data.teamMemberIds || [],
        salesPersonId: data.salesPersonId,
        notes: data.notes || '',
        tags: generatedTags,
        status: clientToEdit?.status || 'Active',
    }
    
    try {
      await onSave(newClientData, clientToEdit?.id);
      toast({
        title: isEditMode ? "Client Updated" : "Client Saved",
        description: `Client ${data.clientName} has been saved successfully.`,
      });
      handleClose();
    } catch (error) {
       console.error("Failed to save client:", error);
       toast({ variant: 'destructive', title: 'Save Error', description: 'Could not save the client.' });
    } finally {
        setIsSaving(false);
    }
  }

  const handleClear = () => {
    form.reset(emptyFormValues);
    setLogoPreview(null);
    setGeneratedTags([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }
  
  const handleGenerateTags = async () => {
    const notes = form.getValues("notes");
    if (!notes || notes.trim().length < 10) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please enter at least 10 characters of notes to generate tags.' });
      return;
    }
    setIsGeneratingTags(true);
    try {
      const result = await generateTagsFromNotes({ notes });
      setGeneratedTags(result.tags);
    } catch (error) {
      console.error("Failed to generate tags:", error);
      toast({ variant: 'destructive', title: 'AI Error', description: 'Could not generate tags.' });
    } finally {
      setIsGeneratingTags(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit Client Information' : 'PrimaVerse - Client Information'}</DialogTitle>
          <DialogDescription>
            {isEditMode ? 'Update the details for this client.' : 'Fill out the form below to add a new client to the system.'}
          </DialogDescription>
        </DialogHeader>
        <DialogBody>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <div className="space-y-8">
                  <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField control={form.control} name="clientName" render={({ field }) => (
                              <FormItem><FormLabel>Client Name</FormLabel><FormControl><Input placeholder="Acme Inc." {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={form.control} name="clientCode" render={({ field }) => (
                              <FormItem><FormLabel>Client Code</FormLabel><FormControl><Input placeholder="ACME" {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={form.control} name="clientLogo" render={({ field: { onChange, value, ...rest } }) => (
                              <FormItem>
                                  <FormLabel>Client Logo</FormLabel>
                                  <FormControl>
                                      <div className="flex items-center gap-4">
                                          {logoPreview && (
                                              <div className="relative shrink-0">
                                                  <Avatar className="h-10 w-10">
                                                      <AvatarImage src={logoPreview} alt="Logo preview" data-ai-hint="company logo"/>
                                                      <AvatarFallback>C</AvatarFallback>
                                                  </Avatar>
                                                  <Button
                                                      type="button"
                                                      variant="destructive"
                                                      size="icon"
                                                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full"
                                                      onClick={() => {
                                                          form.setValue('clientLogo', null, { shouldValidate: true });
                                                          setLogoPreview(null);
                                                          if (fileInputRef.current) {
                                                              fileInputRef.current.value = "";
                                                          }
                                                      }}
                                                  >
                                                      <X className="h-3 w-3" />
                                                  </Button>
                                              </div>
                                          )}
                                          <Button type="button" variant="outline" asChild className="w-full">
                                              <label htmlFor="logo-upload" className="cursor-pointer inline-flex items-center justify-center">
                                                  <Upload className="mr-2 h-4 w-4" /> {logoPreview ? 'Change File' : 'Choose File'}
                                                  <input ref={fileInputRef} id="logo-upload" type="file" className="sr-only" accept=".png,.jpg,.jpeg"
                                                      onChange={(e) => {
                                                          const file = e.target.files?.[0];
                                                          onChange(file || null);
                                                          if (file) {
                                                              const reader = new FileReader();
                                                              reader.onloadend = () => {
                                                                  setLogoPreview(reader.result as string);
                                                              };
                                                              reader.readAsDataURL(file);
                                                          } else {
                                                              setLogoPreview(null);
                                                          }
                                                      }} {...rest} />
                                              </label>
                                          </Button>
                                      </div>
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                          )}/>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={form.control} name="department" render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Department</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value}>
                                      <FormControl><SelectTrigger><SelectValue placeholder="Select a department" /></SelectTrigger></FormControl>
                                      <SelectContent>
                                          {masterData.departments.map(dep => <SelectItem key={dep.id} value={dep.id}>{dep.name}</SelectItem>)}
                                      </SelectContent>
                                  </Select>
                                  <FormMessage />
                              </FormItem>
                          )}/>
                            <FormField control={form.control} name="startDate" render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Start Date</FormLabel>
                                  <Popover open={isDatePickerOpen} onOpenChange={setDatePickerOpen}>
                                      <PopoverTrigger asChild>
                                          <FormControl>
                                              <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !field.value && "text-muted-foreground")}>
                                              <CalendarIcon className="mr-2 h-4 w-4" />
                                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                              </Button>
                                          </FormControl>
                                      </PopoverTrigger>
                                      <PopoverContent className="w-auto p-0" align="start">
                                          <Calendar 
                                              mode="single" 
                                              selected={field.value} 
                                              onSelect={(date) => {
                                                  field.onChange(date);
                                                  setDatePickerOpen(false);
                                              }} 
                                              initialFocus
                                          />
                                      </PopoverContent>
                                  </Popover>
                                  <FormMessage />
                              </FormItem>
                          )}/>
                      </div>
                        <FormField control={form.control} name="salesPersonId" render={({ field }) => (
                          <FormItem>
                              <FormLabel>Sales Person</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                  <FormControl><SelectTrigger><SelectValue placeholder={"Select a sales person"} /></SelectTrigger></FormControl>
                                  <SelectContent>
                                      {salesTeamOptions.map(person => <SelectItem key={person.value} value={person.value}>{person.label}</SelectItem>)}
                                  </SelectContent>
                              </Select>
                              <FormMessage />
                          </FormItem>
                      )}/>
                  </div>

                  <div className="space-y-4">
                      <div className="flex items-center justify-between">
                          <h3 className="text-sm font-medium">Client Coordinator(s)</h3>
                          <Button type="button" variant="outline" size="sm" className="shrink-0" onClick={() => appendCoordinator({ firstName: '', lastName: '', email: '', officePhoneCountryCode: '1', officePhoneNumber: '', officePhoneExt: '', mobilePhoneCountryCode: '1', mobilePhoneNumber: '', streetAddress: '', country: '', state: '', city: '', zipcode: '' })}>
                              <PlusCircle className="mr-2 h-4 w-4" /> Add Coordinator
                          </Button>
                      </div>
                      <FormField control={form.control} name="coordinators" render={() => ( <FormMessage className="!mt-2" /> )} />
                      <div className="space-y-4">
                          {coordinatorFields.map((field, index) => (
                              <CoordinatorFormSection 
                                key={field.id} 
                                form={form} 
                                index={index} 
                                remove={removeCoordinator} 
                                isEditMode={isEditMode}
                                openCoordinators={openCoordinators}
                                setOpenCoordinators={setOpenCoordinators}
                              />
                          ))}
                      </div>
                  </div>
                  
                  <div className="space-y-4">
                        <h3 className="text-sm font-medium">Assign Team</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={form.control} name="duLeadId" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Delivery Unit (DU) Lead</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value} disabled={!departmentValue || duLeadOptions.length === 0}>
                                        <FormControl><SelectTrigger><SelectValue placeholder={!departmentValue ? "Select department first" : "Select a DU Lead"} /></SelectTrigger></FormControl>
                                        <SelectContent>
                                            {duLeadOptions.map(person => <SelectItem key={person.value} value={person.value}>{person.label}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}/>
                            <FormField control={form.control} name="projectManagerId" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Project Manager</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value} disabled={!departmentValue || projectManagerOptions.length === 0}>
                                        <FormControl><SelectTrigger><SelectValue placeholder={!departmentValue ? "Select department first" : "Select a Project Manager"} /></SelectTrigger></FormControl>
                                        <SelectContent>
                                            {projectManagerOptions.map(person => <SelectItem key={person.value} value={person.value}>{person.label}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}/>
                        </div>
                        <FormField control={form.control} name="teamLeadIds" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Team Leads</FormLabel>
                                <FormControl>
                                    <MultiSelect
                                        options={teamLeadOptions}
                                        selected={field.value}
                                        onChange={field.onChange}
                                        className="w-full"
                                        placeholder="Select team leads..."
                                        disabled={!departmentValue || teamLeadOptions.length === 0}
                                    />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}/>
                        <FormField control={form.control} name="teamMemberIds" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Team Members</FormLabel>
                                <FormControl>
                                    <MultiSelect
                                        options={teamMemberOptions}
                                        selected={field.value}
                                        onChange={field.onChange}
                                        className="w-full"
                                        placeholder="Select team members..."
                                        disabled={!departmentValue || teamMemberOptions.length === 0}
                                    />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}/>
                  </div>

                    <div className="space-y-2">
                      <FormField control={form.control} name="notes" render={({ field }) => (
                          <FormItem>
                              <FormLabel>Additional Notes</FormLabel>
                              <FormControl>
                                  <Textarea placeholder="Add any relevant notes, project details, or client history here..." className="min-h-[100px]" {...field} />
                              </FormControl>
                              <FormMessage />
                          </FormItem>
                      )}/>
                      <div className="flex items-start gap-4">
                            <Button type="button" variant="outline" size="sm" onClick={handleGenerateTags} disabled={isGeneratingTags}>
                              {isGeneratingTags ? <div className="ai-spinner mr-2" /> : <WandSparkles className="mr-2 h-4 w-4" />}
                              Generate Tags
                          </Button>
                          <div className="flex flex-wrap gap-2 pt-1">
                              {generatedTags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                          </div>
                      </div>
                  </div>
              </div>
            </form>
          </Form>
        </DialogBody>
        <DialogFooter>
            <Button type="button" variant="ghost" onClick={handleClose}>Close</Button>
            <Button type="button" variant="outline" onClick={handleClear}>Clear</Button>
            <Button type="button" onClick={form.handleSubmit(onSubmit)} disabled={isSaving}>
                {isSaving && <div className="ai-spinner mr-2"/>}
                {isEditMode ? 'Update Client' : 'Save Client'}
            </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


function CoordinatorFormSection({ form, index, remove, isEditMode, openCoordinators, setOpenCoordinators }: { form: any, index: number, remove: (index: number) => void, isEditMode: boolean, openCoordinators: string[], setOpenCoordinators: (ids: string[]) => void }) {
    const countryIso = form.watch(`coordinators.${index}.country`);
    const stateIso = form.watch(`coordinators.${index}.state`);
    const [states, setStates] = useState<ComboboxOption[]>([]);
    const [cities, setCities] = useState<ComboboxOption[]>([]);

    const prevCountryIso = useRef<string>();
    const prevStateIso = useRef<string>();
    
    const id = `coord-${index}`;
    const isOpen = openCoordinators.includes(id);

    const handleOpenChange = (open: boolean) => {
        if (open) {
            setOpenCoordinators([...openCoordinators, id]);
        } else {
            setOpenCoordinators(openCoordinators.filter(i => i !== id));
        }
    }

    useEffect(() => {
        if (countryIso) {
            const countryStates = State.getStatesOfCountry(countryIso).map(s => ({ value: s.isoCode, label: s.name }));
            setStates(countryStates);
            if (prevCountryIso.current !== countryIso && !isEditMode) {
                form.setValue(`coordinators.${index}.state`, '');
                form.setValue(`coordinators.${index}.city`, '');
            }
        } else {
            setStates([]);
        }
        prevCountryIso.current = countryIso;
    }, [countryIso, form, index, isEditMode]);

    useEffect(() => {
        if (stateIso && countryIso) {
            const stateCities = City.getCitiesOfState(countryIso, stateIso).map(c => ({ value: c.name, label: c.name }));
            setCities(stateCities);
            if (prevStateIso.current !== stateIso && !isEditMode) {
                 form.setValue(`coordinators.${index}.city`, '');
            }
        } else {
            setCities([]);
        }
        prevStateIso.current = stateIso;
    }, [stateIso, countryIso, form, index, isEditMode]);
    
    // This effect ensures that on initial load in edit mode, if country/state are set, the dropdowns get populated.
    useEffect(() => {
       if (isEditMode) {
           if (countryIso) {
              const countryStates = State.getStatesOfCountry(countryIso).map(s => ({ value: s.isoCode, label: s.name }));
              setStates(countryStates);
           }
           if (countryIso && stateIso) {
               const stateCities = City.getCitiesOfState(countryIso, stateIso).map(c => ({ value: c.name, label: c.name }));
               setCities(stateCities);
           }
       }
    }, [isEditMode, countryIso, stateIso]);


    return (
        <Collapsible open={isOpen} onOpenChange={handleOpenChange} className="bg-muted/50 p-4 rounded-lg space-y-4 relative">
             <div className="flex items-center justify-between">
                <CollapsibleTrigger asChild>
                    <div className="flex items-center gap-2 cursor-pointer">
                         <ChevronsUpDown className="h-4 w-4" />
                         <span className="font-medium">Coordinator {index + 1}</span>
                    </div>
                </CollapsibleTrigger>
                <Button type="button" variant="ghost" size="icon" className="shrink-0" onClick={() => remove(index)}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                </Button>
            </div>
            <CollapsibleContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={form.control} name={`coordinators.${index}.firstName`} render={({ field }) => (
                        <FormItem><FormLabel>First Name</FormLabel><FormControl><Input placeholder="John" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name={`coordinators.${index}.lastName`} render={({ field }) => (
                        <FormItem><FormLabel>Last Name</FormLabel><FormControl><Input placeholder="Doe" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                </div>
                <FormField control={form.control} name={`coordinators.${index}.email`} render={({ field }) => (
                    <FormItem><FormLabel>Email</FormLabel><FormControl><Input placeholder="john.doe@example.com" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormItem>
                        <FormLabel>Office Phone</FormLabel>
                        <div className="flex gap-2">
                            <FormField control={form.control} name={`coordinators.${index}.officePhoneCountryCode`} render={({ field }) => (
                                <FormItem className="w-24 shrink-0">
                                    <FormControl>
                                        <Combobox
                                            options={majorPhoneCountryCodes}
                                            value={field.value}
                                            onChange={field.onChange}
                                            placeholder="+1"
                                            searchPlaceholder="Search..."
                                            emptyPlaceholder="No code."
                                        />
                                    </FormControl>
                                </FormItem>
                            )}/>
                            <FormField control={form.control} name={`coordinators.${index}.officePhoneNumber`} render={({ field }) => (
                                <FormItem className="flex-grow"><FormControl><Input type="tel" placeholder="555-1234" {...field} /></FormControl></FormItem>
                            )}/>
                            <FormField control={form.control} name={`coordinators.${index}.officePhoneExt`} render={({ field }) => (
                                <FormItem className="w-20 shrink-0"><FormControl><Input placeholder="Ext" {...field} /></FormControl></FormItem>
                            )}/>
                        </div>
                        <FormMessage>
                            {form.formState.errors.coordinators?.[index]?.officePhoneCountryCode?.message || form.formState.errors.coordinators?.[index]?.officePhoneNumber?.message}
                        </FormMessage>
                    </FormItem>
                    <FormItem>
                        <FormLabel>Mobile Phone</FormLabel>
                        <div className="flex gap-2">
                            <FormField control={form.control} name={`coordinators.${index}.mobilePhoneCountryCode`} render={({ field }) => (
                                <FormItem className="w-24 shrink-0">
                                    <FormControl>
                                        <Combobox
                                            options={majorPhoneCountryCodes}
                                            value={field.value}
                                            onChange={field.onChange}
                                            placeholder="+1"
                                            searchPlaceholder="Search..."
                                            emptyPlaceholder="No code."
                                        />
                                    </FormControl>
                                </FormItem>
                            )}/>
                            <FormField control={form.control} name={`coordinators.${index}.mobilePhoneNumber`} render={({ field }) => (
                                <FormItem className="flex-grow"><FormControl><Input type="tel" placeholder="555-5678" {...field} /></FormControl></FormItem>
                            )}/>
                        </div>
                        <FormMessage>
                            {form.formState.errors.coordinators?.[index]?.mobilePhoneCountryCode?.message || form.formState.errors.coordinators?.[index]?.mobilePhoneNumber?.message}
                        </FormMessage>
                    </FormItem>
                </div>
                <FormField control={form.control} name={`coordinators.${index}.streetAddress`} render={({ field }) => (
                    <FormItem><FormLabel>Street Address</FormLabel><FormControl><Input placeholder="123 Main St" {...field} /></FormControl><FormMessage /></FormItem>
                )}/>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <FormField control={form.control} name={`coordinators.${index}.country`} render={({ field }) => (
                        <FormItem><FormLabel>Country</FormLabel><FormControl>
                            <Combobox options={countries} value={field.value} onChange={field.onChange} placeholder="Select country..."/>
                        </FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name={`coordinators.${index}.state`} render={({ field }) => (
                        <FormItem><FormLabel>State</FormLabel><FormControl>
                            <Combobox options={states} value={field.value} onChange={field.onChange} placeholder="Select state..." disabled={!countryIso}/>
                        </FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name={`coordinators.${index}.city`} render={({ field }) => (
                        <FormItem><FormLabel>City</FormLabel><FormControl>
                            <Combobox options={cities} value={field.value} onChange={field.onChange} placeholder="Select city..." disabled={!stateIso}/>
                        </FormControl><FormMessage /></FormItem>
                    )}/>
                    <FormField control={form.control} name={`coordinators.${index}.zipcode`} render={({ field }) => (
                        <FormItem><FormLabel>Zip/Postal Code</FormLabel><FormControl><Input placeholder="12345" {...field} /></FormControl><FormMessage /></FormItem>
                    )}/>
                </div>
            </CollapsibleContent>
        </Collapsible>
    )
}
