
"use client"

import { useState, useEffect } from "react"
import { getTaskHealth, TaskHealthOutput } from "@/ai/flows/task-health-flow"
import type { Task } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface TaskHealthCardProps {
  tasks: Task[]
}

export function TaskHealthCard({ tasks }: TaskHealthCardProps) {
  const [healthInfo, setHealthInfo] = useState<TaskHealthOutput | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let isMounted = true; // Flag to prevent state updates on unmounted component

    if (tasks.length === 0) {
      if (isMounted) {
        setIsLoading(false);
        setHealthInfo({ healthScore: 100, summary: "No tasks assigned. You're all clear!" });
      }
      return;
    }

    const fetchHealthInfo = async () => {
      if (!isMounted) return;
      setIsLoading(true)
      setError(null)
      try {
        // Convert Date objects to ISO strings for server action compatibility
        const serializableTasks = tasks.map(task => ({
          ...task,
          startDate: new Date(task.startDate).toISOString(),
          dueDate: new Date(task.dueDate).toISOString(),
          startedAt: task.startedAt ? new Date(task.startedAt).toISOString() : undefined,
          completedAt: task.completedAt ? new Date(task.completedAt).toISOString() : undefined,
           reviewLog: task.reviewLog?.map(log => ({
            ...log,
            reviewedAt: (log.reviewedAt as any).toDate ? (log.reviewedAt as any).toDate().toISOString() : new Date(log.reviewedAt).toISOString(),
          })) || [],
        }));
        
        const result = await getTaskHealth({ tasks: serializableTasks })
        if (isMounted) setHealthInfo(result)
      } catch (err) {
        console.error("Failed to get task health.", err)
        if (isMounted) setError("AI analysis is temporarily unavailable.")
      } finally {
        if (isMounted) setIsLoading(false)
      }
    }
    
    const timer = setTimeout(fetchHealthInfo, 1000);
    
    return () => {
      isMounted = false;
      clearTimeout(timer);
    }
  }, [tasks])

  const getScoreColor = (score: number) => {
    if (score > 80) return "text-green-500"
    if (score > 50) return "text-amber-500"
    return "text-red-500"
  }

  return (
    <Card className="rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1 h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">My Task Health</CardTitle>
        <CardDescription className="text-xs pt-1">AI-powered summary of your tasks.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="flex items-center space-x-2 pt-4">
            <div className="ai-spinner"></div>
            <p className="text-sm text-muted-foreground">Analyzing...</p>
          </div>
        )}
        {error && !isLoading && (
          <p className="text-sm text-destructive pt-4">{error}</p>
        )}
        {!isLoading && !error && healthInfo && (
          <>
            <div className="flex items-baseline gap-2">
               <p className={cn("text-3xl font-bold", getScoreColor(healthInfo.healthScore))}>{healthInfo.healthScore}</p>
               <p className="text-xs text-muted-foreground">/ 100</p>
            </div>
            <p className="text-xs text-muted-foreground mt-2">{healthInfo.summary}</p>
          </>
        )}
      </CardContent>
    </Card>
  )
}
