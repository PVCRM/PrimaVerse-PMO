
"use client"

import { useState, useMemo, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Download, ArrowLeft } from 'lucide-react';
import { format, startOfDay } from 'date-fns';
import { useUserSessions } from '@/hooks/use-user-sessions';
import type { UserProfile, UserSession } from '@/lib/types';
import { Skeleton } from './ui/skeleton';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';

interface DailyLogPageProps {
  userProfile: UserProfile;
  team: UserProfile[];
}

interface AggregatedSession {
    userId: string;
    employeeName: string;
    employeeId: string;
    loginTime: Date | null;
    logoutTime: Date | null;
    availableHours: number;
    status: 'Logged In' | 'Logged Out';
}

export function DailyLogPage({ userProfile, team }: DailyLogPageProps) {
    const [date, setDate] = useState(startOfDay(new Date()));
    const { sessions, loading } = useUserSessions(date);
    const [selectedEmployee, setSelectedEmployee] = useState<UserProfile | null>(null);

    const aggregatedSessions: AggregatedSession[] = useMemo(() => {
        const userSessionsMap = new Map<string, UserSession[]>();
        sessions.forEach(session => {
            const userSessions = userSessionsMap.get(session.userId) || [];
            userSessions.push(session);
            userSessionsMap.set(session.userId, userSessions);
        });

        return team.map(member => {
            const memberSessions = userSessionsMap.get(member.uid) || [];
            if (memberSessions.length === 0) {
                return {
                    userId: member.uid,
                    employeeName: member.name,
                    employeeId: member.employeeId,
                    loginTime: null,
                    logoutTime: null,
                    availableHours: 0,
                    status: 'Logged Out',
                };
            }

            memberSessions.sort((a, b) => a.loginTime.toDate().getTime() - b.loginTime.toDate().getTime());
            
            const firstLogin = memberSessions[0].loginTime.toDate();
            let lastLogout: Date | null = null;
            let totalHours = 0;
            let loggedIn = false;

            memberSessions.forEach(s => {
                if(s.logoutTime) {
                    lastLogout = s.logoutTime.toDate();
                    totalHours += s.availableHours || 0;
                } else {
                    loggedIn = true;
                }
            });

            return {
                userId: member.uid,
                employeeName: member.name,
                employeeId: member.employeeId,
                loginTime: firstLogin,
                logoutTime: lastLogout,
                availableHours: totalHours,
                status: loggedIn ? 'Logged In' : 'Logged Out',
            };
        });
    }, [team, sessions]);

    const handleDownload = () => {
        if (aggregatedSessions.length === 0) return;
    
        const headers = ['Employee Name', 'Employee ID', 'Status', 'Login Time', 'Logout Time', 'Available Hours'];
        const csvRows = [headers.join(',')];
    
        aggregatedSessions.forEach(({ employeeName, employeeId, status, loginTime, logoutTime, availableHours }) => {
            const login = loginTime ? format(loginTime, 'p') : 'N/A';
            const logout = logoutTime ? format(logoutTime, 'p') : 'N/A';
            const hours = availableHours > 0 ? availableHours.toFixed(2) : 'N/A';
            const row = [employeeName, employeeId, status, login, logout, hours];
            csvRows.push(row.map(val => `"${val}"`).join(','));
        });
    
        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `daily_log_${format(date, 'yyyy-MM-dd')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    if (selectedEmployee) {
        return <DetailedLogView employee={selectedEmployee} date={date} onBack={() => setSelectedEmployee(null)} />;
    }
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
                 <Card className="rounded-xl border shadow-none">
                    <CardHeader>
                        <CardTitle>Select Date</CardTitle>
                        <CardDescription>View logs for a specific day.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex justify-center">
                        <Calendar
                            mode="single"
                            selected={date}
                            onSelect={(d) => setDate(d || new Date())}
                            disabled={(d) => d > new Date()}
                            initialFocus
                        />
                    </CardContent>
                </Card>
            </div>
            <div className="lg:col-span-2">
                <Card className="rounded-xl border shadow-none">
                    <CardHeader>
                        <CardTitle>Employee Daily Log</CardTitle>
                        <CardDescription>
                            Overview of employee login status and available hours for {format(date, 'PPP')}.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Employee</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Login Time</TableHead>
                                        <TableHead>Logout Time</TableHead>
                                        <TableHead className="text-right">Available Hours</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        Array.from({ length: 5 }).map((_, i) => (
                                            <TableRow key={i}>
                                                <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                                                <TableCell><Skeleton className="h-6 w-24 rounded-full" /></TableCell>
                                                <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                                <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                                <TableCell className="text-right"><Skeleton className="h-4 w-16 ml-auto" /></TableCell>
                                            </TableRow>
                                        ))
                                    ) : aggregatedSessions.map((sessionData) => (
                                        <TableRow key={sessionData.userId} onClick={() => setSelectedEmployee(team.find(t => t.uid === sessionData.userId) || null)} className="cursor-pointer">
                                            <TableCell className="font-medium">{sessionData.employeeName}</TableCell>
                                            <TableCell>
                                                <Badge variant={sessionData.status === 'Logged In' ? 'default' : 'secondary'} className={sessionData.status === 'Logged In' ? 'bg-green-100 text-green-800' : ''}>
                                                    {sessionData.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>{sessionData.loginTime ? format(sessionData.loginTime, 'p') : 'N/A'}</TableCell>
                                            <TableCell>{sessionData.logoutTime ? format(sessionData.logoutTime, 'p') : 'N/A'}</TableCell>
                                            <TableCell className="text-right font-medium">{sessionData.availableHours > 0 ? sessionData.availableHours.toFixed(2) : 'N/A'}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                    <CardFooter className="justify-end">
                        <Button variant="outline" onClick={handleDownload}>
                            <Download className="mr-2 h-4 w-4" />
                            Download Today's Log
                        </Button>
                    </CardFooter>
                </Card>
            </div>
        </div>
    );
}


function DetailedLogView({ employee, date, onBack }: { employee: UserProfile, date: Date, onBack: () => void }) {
    const { sessions, loading } = useUserSessions(date, employee.uid);

    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader className="flex flex-row items-center border-b pb-4">
                 <Button variant="outline" size="icon" className="mr-4" onClick={onBack}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <div>
                    <CardTitle>Detailed Log for {employee.name}</CardTitle>
                    <CardDescription>All login/logout events for {format(date, 'PPP')}.</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="pt-6">
                 <div className="border rounded-lg">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Login Time</TableHead>
                                <TableHead>Last Activity / Logout</TableHead>
                                <TableHead>Duration</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                <TableRow><TableCell colSpan={4} className="text-center p-8"><div className="ai-spinner mx-auto" /></TableCell></TableRow>
                            ) : sessions.length > 0 ? (
                                sessions.map(session => (
                                    <TableRow key={session.id}>
                                        <TableCell>{format(session.loginTime.toDate(), 'p')}</TableCell>
                                        <TableCell>{session.logoutTime ? format(session.logoutTime.toDate(), 'p') : 'Active'}</TableCell>
                                        <TableCell>{session.availableHours ? `${session.availableHours.toFixed(2)} hrs` : 'N/A'}</TableCell>
                                        <TableCell>
                                            <Badge variant={session.status === 'active' ? 'default' : 'secondary'} className={session.status === 'active' ? 'bg-green-100 text-green-800' : ''}>
                                                {session.status}
                                            </Badge>
                                        </TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow><TableCell colSpan={4} className="text-center p-8 text-muted-foreground">No sessions recorded for this day.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                 </div>
            </CardContent>
        </Card>
    )
}

    