
"use client"

import { useState, useEffect, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, PlusCircle, Trash2, Download, ArrowLeft, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { format, startOfDay, addDays, subDays, endOfDay, isToday, isFuture, isSameDay } from 'date-fns';
import type { UserProfile, TimesheetEntry, Task, Client, Project, Department } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useTasks } from '@/hooks/use-tasks';
import { useTimesheet, TimesheetData } from '@/hooks/use-timesheet';
import { roleHierarchy } from '@/data/master-data';
import { cn } from '@/lib/utils';
import { collection, addDoc, Timestamp, query, where, getDocs, writeBatch, doc, deleteDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useMasterData } from '@/context/master-data-context';
import { Calendar } from './ui/calendar';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';


interface TimesheetPageProps {
  userProfile: UserProfile;
  team: UserProfile[];
  clients: Client[];
  projects: Project[];
}

export function TimesheetPage({ userProfile, team, clients, projects }: TimesheetPageProps) {
    const isManagerOrLead = roleHierarchy[userProfile.role] >= 1;
    const [currentDate, setCurrentDate] = useState(startOfDay(new Date()));

    return (
        <div className="space-y-6">
            <EmployeeTimesheetView userProfile={userProfile} currentDate={currentDate} setCurrentDate={setCurrentDate} />
            {isManagerOrLead && <ManagerTimesheetView key={`${userProfile.uid}-${currentDate.getTime()}`} userProfile={userProfile} team={team} clients={clients} projects={projects} />}
        </div>
    );
}

// =================================================================
// Employee-Specific Timesheet View
// =================================================================
const nonTaskActivities = [
    { value: 'team-meeting', label: 'Daily Team Meeting' },
    { value: 'interview', label: 'Interview' },
    { value: 'training', label: 'Training' },
    { value: 'client-setup', label: 'New Client Setup Study' },
    { value: 'kra-review', label: 'KRA Reviews' },
    { value: 'company-activities', label: 'Company Activities' },
    { value: 'trial-project', label: 'Trial Project Study' },
];

const nonProductiveActivities = [
    { value: 'idle', label: 'Idle' },
    { value: 'early-out', label: 'Early Out' },
    { value: 'server-downtime', label: 'Server Downtime' },
];

const recreationalEntryTemplate: Omit<TimesheetEntry, 'id' | 'userId' | 'date'> = {
    type: 'recreational',
    projectName: 'Recreational Activities',
    description: 'Lunch, Snacks & Recreational Activities',
    hours: 1,
    isSubmitted: false,
};


function EmployeeTimesheetView({ userProfile, currentDate, setCurrentDate }: { userProfile: UserProfile, currentDate: Date, setCurrentDate: (date: Date) => void }) {
    const { toast } = useToast();
    const { tasks } = useTasks();
    const [entries, setEntries] = useState<Omit<TimesheetEntry, 'userId'>[]>([]);
    const [isLoadingEntries, setIsLoadingEntries] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const isFutureDate = isFuture(currentDate);

    const isTimesheetLocked = useMemo(() => {
        if (entries.length === 0) return false;
        return entries.some(e => e.isSubmitted);
    }, [entries]);

    const fetchEntriesForDate = useCallback(async (date: Date) => {
        setIsLoadingEntries(true);
    
        const q = query(
            collection(db, "timesheet"),
            where('userId', '==', userProfile.uid)
        );
    
        try {
            const snapshot = await getDocs(q);
            const allUserEntries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), date: (doc.data().date as Timestamp).toDate() } as Omit<TimesheetEntry, 'userId'>));
            let fetchedEntries = allUserEntries.filter(entry => isSameDay(entry.date, date));
            
            // Ensure recreational entry exists if it's not a future date
            if (!isFuture(date) && !fetchedEntries.some(e => e.type === 'recreational')) {
                fetchedEntries.push({ ...recreationalEntryTemplate, id: `rec-${date.getTime()}`, date: date });
            }

            setEntries(fetchedEntries);

        } catch (error) {
            console.error("Failed to fetch timesheet entries:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch your timesheet entries.' });
            // Failsafe: if fetch fails, still add the recreational entry for today
            if (!isFuture(date)) {
                 setEntries([{ ...recreationalEntryTemplate, id: `rec-${date.getTime()}`, date: date }]);
            }
        } finally {
            setIsLoadingEntries(false);
        }
    }, [userProfile.uid, toast]);

    useEffect(() => {
        fetchEntriesForDate(currentDate);
    }, [currentDate, fetchEntriesForDate]);
    
    const totalHours = entries.reduce((sum, entry) => sum + (Number(entry.hours) || 0), 0);
    
    const handleAddRow = (type: 'productive-work' | 'non-productive') => {
        if(isTimesheetLocked) return;
        setEntries(prev => [...prev, {
            id: `new-${Date.now()}`,
            date: currentDate,
            type: type,
            projectName: type === 'productive-work' ? 'Productive Activities' : 'Non-productive Activities',
            description: '',
            hours: 0,
        }]);
    };

    const handleUpdateEntry = (index: number, field: keyof TimesheetEntry, value: any) => {
        if(isTimesheetLocked) return;
        const newEntries = [...entries];
        const updatedEntry = { ...newEntries[index], [field]: value };
        newEntries[index] = updatedEntry;
        setEntries(newEntries);
    };

    const handleRemoveEntry = async (index: number) => {
        if(isTimesheetLocked) return;
        const entryToRemove = entries[index];
        
        setEntries(prev => prev.filter((_, i) => i !== index));

        if (entryToRemove && !entryToRemove.id.startsWith('new-') && !entryToRemove.id.startsWith('rec-')) {
            try {
                const docRef = doc(db, 'timesheet', entryToRemove.id);
                await deleteDoc(docRef);
                toast({ title: 'Entry Deleted', description: 'The timesheet entry has been removed.' });
            } catch (error) {
                console.error("Failed to delete timesheet entry:", error);
                toast({ variant: 'destructive', title: 'Error', description: 'Could not delete the entry from the database.' });
                fetchEntriesForDate(currentDate); 
            }
        }
    };

    const handleSubmitForReview = async () => {
        setIsSubmitting(true);
        if (totalHours < 9) {
            toast({ variant: 'destructive', title: "Insufficient Hours", description: "Please log at least 9 hours before submitting." });
            setIsSubmitting(false);
            return;
        }

        const entriesToSave = entries.filter(e => e.hours > 0 && !e.isSubmitted);

        if (entriesToSave.length === 0) {
            toast({ title: "No Changes", description: "Your timesheet has already been submitted."});
            setIsSubmitting(false);
            return;
        }

        const batch = writeBatch(db);

        entriesToSave.forEach(entry => {
            const isNew = entry.id.startsWith('new-') || entry.id.startsWith('rec-');
            const docRef = isNew ? doc(collection(db, 'timesheet')) : doc(db, 'timesheet', entry.id);
            
            const { id, ...entryData } = entry;
            batch.set(docRef, {
                ...entryData,
                userId: userProfile.uid,
                date: Timestamp.fromDate(entry.date),
                isSubmitted: true,
                isApproved: false,
                needsRevision: false,
            });
        });
        
        try {
            await batch.commit();
            toast({
                title: "Timesheet Submitted",
                description: `Your timesheet for ${format(currentDate, 'PPP')} has been submitted for review.`
            });
            fetchEntriesForDate(currentDate); // Refetch to lock the sheet
        } catch (error) {
            console.error("Error submitting timesheet:", error);
            toast({ variant: 'destructive', title: "Submit Error", description: "Could not submit your timesheet." });
        } finally {
            setIsSubmitting(false);
        }
    }
    
    const getProjectNameForEntry = (entry: Omit<TimesheetEntry, 'userId'>) => {
        if (entry.type === 'review') return 'Review';
        if (entry.type === 'task') return entry.projectName || 'Task';
        return entry.projectName;
    };
    
    const getDescriptionForEntry = (entry: Omit<TimesheetEntry, 'userId'>) => {
        if (entry.type === 'review') return entry.taskName || 'Reviewing task';
        if (entry.type === 'task') return entry.taskName || 'Working on task';
        if (entry.type === 'productive-work' || entry.type === 'non-productive') return null; // Dropdown will be shown
        return entry.description;
    };
    
    const productiveActivities = useMemo(() => {
        const selectedDescriptions = entries.filter(e => e.type === 'productive-work').map(e => e.description);
        return nonTaskActivities.map(act => ({...act, disabled: selectedDescriptions.includes(act.label)}));
    }, [entries]);

    const nonProductiveSelectActivities = useMemo(() => {
        const selectedDescriptions = entries.filter(e => e.type === 'non-productive').map(e => e.description);
        return nonProductiveActivities.map(act => ({...act, disabled: selectedDescriptions.includes(act.label)}));
    }, [entries]);


    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>My Daily Timesheet</CardTitle>
                    <CardDescription>Log your billing hours for the day. Minimum 9 hours to submit.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" onClick={() => setCurrentDate(subDays(currentDate, 1))}>
                        <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="font-semibold text-lg w-48 text-center">{format(currentDate, 'PPP')}</span>
                    <Button variant="outline" size="icon" onClick={() => setCurrentDate(addDays(currentDate, 1))} disabled={isToday(currentDate) || isFutureDate}>
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {isTimesheetLocked && (
                    <Alert className="mb-4" variant="default">
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle>Timesheet Submitted</AlertTitle>
                        <AlertDescription>This timesheet has been submitted for review and is now locked.</AlertDescription>
                    </Alert>
                )}
                 {totalHours > 24 && (
                    <Alert className="mb-4" variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>High Hours Warning</AlertTitle>
                        <AlertDescription>You've logged more than 24 hours for a single day. Please double-check your entries before submitting.</AlertDescription>
                    </Alert>
                )}
                <div className="border rounded-lg mb-6">
                <Table>
                    <TableHeader>
                    <TableRow>
                        <TableHead className="w-1/3">Project</TableHead>
                        <TableHead className="w-1/2">Task / Activity</TableHead>
                        <TableHead className="w-[100px] text-right">Hours</TableHead>
                        <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoadingEntries ? (
                            <TableRow>
                                <TableCell colSpan={4} className="h-24 text-center">
                                    <div className="ai-spinner mx-auto"/>
                                </TableCell>
                            </TableRow>
                        ) : entries.map((entry, index) => {
                           const descriptionNode = getDescriptionForEntry(entry);
                           return (
                                <TableRow key={entry.id} className={cn((entry.type === 'recreational' || entry.type === 'non-productive') && 'bg-muted/50')}>
                                    <TableCell>
                                       <Input value={getProjectNameForEntry(entry)} readOnly disabled/>
                                    </TableCell>
                                    <TableCell>
                                        {descriptionNode === null ? (
                                            <Select 
                                                value={entry.description}
                                                onValueChange={value => handleUpdateEntry(index, 'description', value)}
                                                disabled={isTimesheetLocked}
                                            >
                                                <SelectTrigger><SelectValue placeholder="Select activity..."/></SelectTrigger>
                                                <SelectContent>
                                                    {entry.type === 'productive-work' 
                                                        ? productiveActivities.map(act => <SelectItem key={act.value} value={act.label} disabled={act.disabled}>{act.label}</SelectItem>)
                                                        : nonProductiveSelectActivities.map(act => <SelectItem key={act.value} value={act.label} disabled={act.disabled}>{act.label}</SelectItem>)
                                                    }
                                                </SelectContent>
                                            </Select>
                                        ) : (
                                            <Input value={descriptionNode} readOnly disabled />
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        <Input 
                                            type="number" 
                                            className="text-right" 
                                            value={entry.hours}
                                            onChange={e => handleUpdateEntry(index, 'hours', parseFloat(e.target.value) || 0)}
                                            readOnly={entry.type === 'task' || entry.type === 'recreational' || entry.type === 'review' || isTimesheetLocked}
                                            step="0.5"
                                        />
                                    </TableCell>
                                    <TableCell>
                                        {(entry.type === 'productive-work' || entry.type === 'non-productive') && !isTimesheetLocked && (
                                            <Button variant="ghost" size="icon" onClick={() => handleRemoveEntry(index)}>
                                                <Trash2 className="h-4 w-4 text-muted-foreground"/>
                                            </Button>
                                        )}
                                    </TableCell>
                                </TableRow>
                           );
                        })}
                    </TableBody>
                </Table>
                </div>
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Button variant="outline" onClick={() => handleAddRow('productive-work')} disabled={isTimesheetLocked}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Productive
                        </Button>
                        <Button variant="outline" onClick={() => handleAddRow('non-productive')} disabled={isTimesheetLocked}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Non-productive
                        </Button>
                    </div>
                    <div className="flex items-center gap-6 text-right">
                        <div className="text-sm">
                            <p className="text-muted-foreground">Total Hours</p>
                            <p className="font-bold text-lg">{totalHours.toFixed(2)}</p>
                        </div>
                        <Button onClick={handleSubmitForReview} disabled={isSubmitting || isTimesheetLocked || isFutureDate || totalHours < 9}>
                            {isSubmitting && <div className="ai-spinner mr-2"/>}
                            {isTimesheetLocked ? 'Submitted' : 'Submit for Review'}
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}


// =================================================================
// Manager-Specific Timesheet View
// =================================================================

const statusConfig = {
      'Complete': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'Partial': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      'Pending': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      'Approved': 'bg-primary/20 text-primary',
      'Needs Revision': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
}

function TeamMemberRow({ member, date, onRowClick }: { member: UserProfile, date: Date, onRowClick: (employee: UserProfile) => void }) {
    const { timesheetData, loading } = useTimesheet(member.uid, date.getTime());

    if (loading) {
        return (
            <TableRow>
                <TableCell className="font-medium">{member.name}</TableCell>
                <TableCell colSpan={2}><div className="ai-spinner h-4 w-4" /></TableCell>
            </TableRow>
        );
    }
    
    const entry = timesheetData;
    const loggedHours = entry?.totalHours || 0; 
    const status = entry?.status || 'Pending';
    
    return (
        <TableRow key={member.uid} onClick={() => onRowClick(member)} className="cursor-pointer">
            <TableCell className="font-medium">{member.name}</TableCell>
            <TableCell>{loggedHours.toFixed(2)}</TableCell>
            <TableCell>
                <span className={cn('px-2 py-1 text-xs font-medium rounded-full', statusConfig[status])}>{status}</span>
            </TableCell>
        </TableRow>
    )
}


function ManagerTimesheetView({ userProfile, team, clients, projects }: { userProfile: UserProfile, team: UserProfile[], clients: Client[], projects: Project[] }) {
  const { masterData } = useMasterData();
  const [currentDate, setCurrentDate] = useState(startOfDay(new Date()));
  const [selectedEmployee, setSelectedEmployee] = useState<UserProfile | null>(null);

  // Filters
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedClient, setSelectedClient] = useState('all');
  const [selectedProject, setSelectedProject] = useState('all');

  const isFutureDate = isFuture(currentDate);

  const managerTeam = useMemo(() => {
    // Correctly filter for direct reports only
    return team.filter(member => member.reviewerId === userProfile.uid);
  }, [team, userProfile]);

  const departmentOptions = useMemo(() => {
    if (userProfile.role === 'Super Admin') return masterData.departments;
    const userDepts = Array.isArray(userProfile.department) ? userProfile.department : [userProfile.department];
    return masterData.departments.filter(d => userDepts.includes(d.name));
  }, [masterData.departments, userProfile]);
  
  const clientOptions = useMemo(() => {
      if (selectedDepartment === 'all') return clients;
      const department = masterData.departments.find(d => d.id === selectedDepartment);
      if (!department) return clients;
      return clients.filter(c => c.department === department.name);
  }, [clients, selectedDepartment, masterData.departments]);

  const projectOptions = useMemo(() => {
      if(selectedClient === 'all') {
          return projects.filter(p => clientOptions.some(c => c.id === p.clientId));
      }
      return projects.filter(p => p.clientId === selectedClient);
  }, [projects, selectedClient, clientOptions]);

  const filteredTeam = useMemo(() => {
    let filtered = managerTeam;

    if (selectedDepartment !== 'all') {
        const department = masterData.departments.find(d => d.id === selectedDepartment);
        if (department) {
            filtered = filtered.filter(member => {
                const memberDepts = Array.isArray(member.department) ? member.department : [member.department];
                return memberDepts.includes(department.name);
            });
        }
    }

    if (selectedProject !== 'all') {
        const project = projects.find(p => p.id === selectedProject);
        if (project) {
            filtered = filtered.filter(member => project.teamIds?.includes(member.uid));
        }
    } else if (selectedClient !== 'all') {
        const clientProjectIds = projects.filter(p => p.clientId === selectedClient).map(p => p.id);
        filtered = filtered.filter(member => 
            projects.some(p => clientProjectIds.includes(p.id) && p.teamIds?.includes(member.uid))
        );
    }
    
    return filtered;
  }, [managerTeam, selectedDepartment, selectedClient, selectedProject, masterData.departments, projects]);

  const handleDepartmentChange = (value: string) => {
    setSelectedDepartment(value);
    setSelectedClient('all');
    setSelectedProject('all');
  };

  const handleClientChange = (value: string) => {
    setSelectedClient(value);
    setSelectedProject('all');
  };

  const handleDownloadLog = () => {
    alert("Downloading 3 months of logs... (Not implemented yet)");
  }
  
  if (selectedEmployee) {
    return <DetailedEmployeeLog employee={selectedEmployee} onBack={() => setSelectedEmployee(null)} />;
  }

  return (
    <Card className="rounded-xl border shadow-none">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Team Daily Log</CardTitle>
          <CardDescription>Summary of your team's timesheet entries for the day.</CardDescription>
        </div>
        <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setCurrentDate(subDays(currentDate, 1))}>
                <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-semibold text-lg w-48 text-center">{format(currentDate, 'PPP')}</span>
             <Button variant="outline" size="icon" onClick={() => setCurrentDate(addDays(currentDate, 1))} disabled={isToday(currentDate) || isFutureDate}>
                <ChevronRight className="h-4 w-4" />
            </Button>
        </div>
      </CardHeader>
      
       <CardContent className="border-t pt-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <p className="font-medium md:text-right">Filters:</p>
                <Select value={selectedDepartment} onValueChange={handleDepartmentChange}>
                    <SelectTrigger><SelectValue placeholder="All Departments"/></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        {departmentOptions.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                    </SelectContent>
                </Select>
                <Select value={selectedClient} onValueChange={handleClientChange}>
                    <SelectTrigger><SelectValue placeholder="All Clients"/></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Clients</SelectItem>
                        {clientOptions.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                </Select>
                 <Select value={selectedProject} onValueChange={setSelectedProject}>
                    <SelectTrigger><SelectValue placeholder="All Projects"/></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Projects</SelectItem>
                        {projectOptions.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
        </CardContent>

      <CardContent className="border-t pt-6">
            <div className="border rounded-lg">
            <Table>
                <TableHeader>
                <TableRow>
                    <TableHead>Team Member</TableHead>
                    <TableHead>Total Hours Logged</TableHead>
                    <TableHead>Status</TableHead>
                </TableRow>
                </TableHeader>
                <TableBody>
                {filteredTeam.map(member => (
                    <TeamMemberRow key={member.uid} member={member} date={currentDate} onRowClick={setSelectedEmployee} />
                ))}
                </TableBody>
            </Table>
            </div>
      </CardContent>
      <CardFooter className="justify-end pt-6">
        <Button variant="outline" onClick={handleDownloadLog}><Download className="mr-2 h-4 w-4" /> Download Logs</Button>
      </CardFooter>
    </Card>
  );
}

function DetailedEmployeeLog({ employee, onBack }: { employee: UserProfile, onBack: () => void }) {
    const [date, setDate] = useState(startOfDay(new Date()));
    const [entries, setEntries] = useState<TimesheetEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [timesheetStatus, setTimesheetStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');
    const { toast } = useToast();

    const fetchEntries = useCallback(async (uid: string, fetchDate: Date) => {
        setLoading(true);
        const q = query(
            collection(db, "timesheet"), 
            where('userId', '==', uid)
        );
        
        try {
            const snapshot = await getDocs(q);
            const allUserEntries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TimesheetEntry));
            
            const entriesForDate = allUserEntries.filter(entry => 
                isSameDay((entry.date as any as Timestamp).toDate(), fetchDate)
            );
            
            if (entriesForDate.length > 0) {
                if (entriesForDate.every(e => e.isApproved)) {
                    setTimesheetStatus('approved');
                } else if (entriesForDate.some(e => e.needsRevision)) {
                    setTimesheetStatus('rejected');
                } else {
                    setTimesheetStatus('pending');
                }
            } else {
                 setTimesheetStatus('pending');
            }

            setEntries(entriesForDate);
        } catch (error) {
            console.error("Error fetching detailed timesheet:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch detailed log.' });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    useEffect(() => {
        fetchEntries(employee.uid, date);
    }, [employee.uid, date, fetchEntries]);

    const totalHours = entries.reduce((sum, entry) => sum + (Number(entry.hours) || 0), 0);

    const handleApprovalAction = async (action: 'approve' | 'reject') => {
        if (entries.length === 0) {
            toast({ variant: 'destructive', title: 'No Entries', description: 'There are no entries to process for this date.' });
            return;
        }

        const batch = writeBatch(db);
        entries.forEach(entry => {
            const docRef = doc(db, 'timesheet', entry.id);
            batch.update(docRef, { 
                isApproved: action === 'approve',
                needsRevision: action === 'reject' 
            });
        });

        try {
            await batch.commit();
            toast({ title: 'Success', description: `Timesheet has been ${action === 'approve' ? 'approved' : 'sent for revision'}.` });
            fetchEntries(employee.uid, date); // Refetch to show updated status
        } catch (error) {
            console.error('Error processing timesheet:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not process the timesheet.' });
        }
    };
    
    return (
        <Card className="rounded-xl border shadow-none relative">
            <CardHeader className="relative border-b">
                <Button variant="ghost" size="icon" className="absolute top-1/2 left-4 -translate-y-1/2" onClick={onBack}>
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <div className="text-center">
                    <CardTitle>Timesheet for {employee.name}</CardTitle>
                    <CardDescription>{format(date, 'PPP')}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
                <div className="md:col-span-1">
                    <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(d) => setDate(d || new Date())}
                        className="rounded-md border-0 shadow-none p-0"
                        disabled={(date) => isFuture(date)}
                    />
                </div>
                <div className="md:col-span-2">
                    {loading ? (
                         <div className="flex justify-center items-center h-full"><div className="ai-spinner"/></div>
                    ): entries.length > 0 ? (
                        <>
                            <div className="border rounded-lg mb-4">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Project</TableHead>
                                            <TableHead>Task / Activity</TableHead>
                                            <TableHead className="text-right">Hours</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {entries.map(entry => (
                                            <TableRow key={entry.id}>
                                                <TableCell>{entry.projectName || 'N/A'}</TableCell>
                                                <TableCell>{entry.taskName || entry.description}</TableCell>
                                                <TableCell className="text-right">{entry.hours.toFixed(2)}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                             <div className="flex items-center justify-between">
                                <div className="text-lg">
                                    <span className="text-muted-foreground">Total:</span>
                                    <span className="font-bold ml-2">{totalHours.toFixed(2)} / 9.00 hrs</span>
                                </div>
                                {timesheetStatus === 'pending' ? (
                                    <div className="space-x-2">
                                        <Button variant="ghost" size="sm" onClick={() => handleApprovalAction('reject')}><XCircle className="mr-2 h-4 w-4" /> Reject</Button>
                                        <Button variant="outline" size="sm" onClick={() => handleApprovalAction('approve')}><CheckCircle className="mr-2 h-4 w-4" /> Approve</Button>
                                    </div>
                                ) : (
                                     <Alert className={cn("py-2 px-4", timesheetStatus === 'approved' ? 'border-green-500/50' : 'border-red-500/50')}>
                                        <AlertDescription className="flex items-center gap-2">
                                            {timesheetStatus === 'approved' ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />}
                                            Timesheet has been {timesheetStatus}.
                                        </AlertDescription>
                                    </Alert>
                                )}
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full p-8 bg-muted/50 rounded-lg">
                            <p className="text-muted-foreground">No timesheet entries found for this date.</p>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}
