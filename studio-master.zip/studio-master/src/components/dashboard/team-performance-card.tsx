
"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Task, UserProfile } from "@/lib/types"

interface TeamPerformanceCardProps {
    team: UserProfile[];
    tasks: Task[];
}

export function TeamPerformanceCard({ team, tasks }: TeamPerformanceCardProps) {
    
  const completedTasksWithEfficiency = tasks.filter(t => t.status === 'completed' && t.efficiency !== undefined && t.efficiency !== null);
  
  const employeeEfficiencies: { [uid: string]: { totalEfficiency: number; count: number } } = {};
  
  completedTasksWithEfficiency.forEach(task => {
    if (!employeeEfficiencies[task.assigneeId]) {
      employeeEfficiencies[task.assigneeId] = { totalEfficiency: 0, count: 0 };
    }
    employeeEfficiencies[task.assigneeId].totalEfficiency += task.efficiency!;
    employeeEfficiencies[task.assigneeId].count++;
  });

  const chartData = team
    .map(member => {
        const data = employeeEfficiencies[member.uid];
        const avgEfficiency = data && data.count > 0 ? Math.round(data.totalEfficiency / data.count) : 0;
        return {
            name: member.firstName || member.name.split(' ')[0],
            avgEfficiency,
        };
    })
    .filter(member => member.avgEfficiency > 0)
    .sort((a,b) => b.avgEfficiency - a.avgEfficiency)
    .slice(0, 7); // Show top 7 performers


  return (
    <Card className="shadow-none rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1 h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-base font-semibold">Top Performers</CardTitle>
        <CardDescription className="text-xs pt-1">Average task efficiency this month.</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} layout="vertical" margin={{ left: -10 }}>
            <XAxis type="number" hide />
            <YAxis
              dataKey="name"
              type="category"
              tickLine={false}
              axisLine={false}
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <Bar dataKey="avgEfficiency" radius={[0, 5, 5, 0]} fill="hsl(var(--primary))" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

