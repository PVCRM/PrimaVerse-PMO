
"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { Project, Task } from "@/lib/types"

interface ProjectsOverviewCardProps {
  projects: Project[]
  tasks: Task[]
  onProjectClick: (project: Project) => void;
}

export function ProjectsOverviewCard({ projects, tasks, onProjectClick }: ProjectsOverviewCardProps) {

  const getProjectProgress = (projectId: string) => {
    const projectTasks = tasks.filter(t => t.projectId === projectId);
    if (projectTasks.length === 0) return 0;
    const completedTasks = projectTasks.filter(t => t.status === 'completed').length;
    return Math.round((completedTasks / projectTasks.length) * 100);
  }

  return (
    <Card className="shadow-none rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1 h-full">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Projects Overview</CardTitle>
        <CardDescription className="text-sm pt-1 text-muted-foreground">Current progress of active projects.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {projects.filter(p => p.status === 'Active').slice(0, 5).map(project => (
          <div key={project.id} onClick={() => onProjectClick(project)} className="cursor-pointer group">
            <div className="flex justify-between items-center mb-1">
              <p className="text-sm font-medium group-hover:text-primary">{project.name}</p>
              <p className="text-sm text-muted-foreground">{getProjectProgress(project.id)}%</p>
            </div>
            <Progress value={getProjectProgress(project.id)} className="h-2" />
          </div>
        ))}
        {projects.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">No projects to display.</p>
        )}
      </CardContent>
    </Card>
  )
}
