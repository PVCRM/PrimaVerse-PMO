
"use client"

import { PieChart, Pie, Cell, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart"
import type { Task } from "@/lib/types"

interface TasksByStatusCardProps {
  tasks: Task[]
}

const chartConfig = {
  todo: { label: "To Do", color: "hsl(var(--chart-1))" },
  'in-progress': { label: "In Progress", color: "hsl(var(--chart-2))" },
  overdue: { label: "Overdue", color: "hsl(var(--chart-3))" },
  completed: { label: "Completed", color: "hsl(var(--chart-4))" },
} satisfies ChartConfig

export function TasksByStatusCard({ tasks }: TasksByStatusCardProps) {
  const statusCounts = tasks.reduce((acc, task) => {
    acc[task.status] = (acc[task.status] || 0) + 1;
    return acc;
  }, {} as Record<Task['status'], number>);

  const chartData = Object.entries(statusCounts).map(([status, count]) => ({
    status,
    count,
    fill: chartConfig[status as keyof typeof chartConfig].color,
  }));

  return (
    <Card className="shadow-none rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1 h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-base font-semibold">Task Distribution</CardTitle>
        <CardDescription className="text-xs pt-1">Breakdown of tasks by their current status.</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex items-center justify-center pb-0">
        <ChartContainer config={chartConfig} className="mx-auto aspect-square max-h-[250px]">
          <PieChart>
            <Tooltip
              cursor={false}
              content={<ChartTooltipContent hideLabel nameKey="status" />}
            />
            <Pie
              data={chartData}
              dataKey="count"
              nameKey="status"
              innerRadius={60}
              strokeWidth={5}
            >
                {chartData.map((entry) => (
                    <Cell key={`cell-${entry.status}`} fill={entry.fill} />
                ))}
            </Pie>
          </PieChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
