
"use client"

import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useNotifications } from '@/hooks/use-notifications';
import { useRouter } from 'next/navigation';

interface PageHeaderProps {
  title: string;
  children?: React.ReactNode;
}

export function PageHeader({ title, children }: PageHeaderProps) {
  const router = useRouter();
  const { notifications, loading: loadingNotifications } = useNotifications();

  return (
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold text-foreground">{title}</h1>
      <div className="flex items-center gap-4">
        {children}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              {notifications.length > 0 && !loadingNotifications && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                </span>
              )}
              <span className="sr-only">Notifications</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {loadingNotifications ? (
                <DropdownMenuItem disabled>
                  <div className="flex items-center gap-2 py-2 px-2">
                    <div className="ai-spinner h-4 w-4" />
                    <span className="text-muted-foreground text-sm">Loading...</span>
                  </div>
                </DropdownMenuItem>
              ) : notifications.length === 0 ? (
                <DropdownMenuItem disabled>
                  <p className="text-center text-sm text-muted-foreground py-4 w-full">No new notifications</p>
                </DropdownMenuItem>
              ) : (
                <>
                  {notifications.slice(0, 5).map(notification => (
                    <DropdownMenuItem key={notification.id} onSelect={() => notification.link && router.push(notification.link)} className="cursor-pointer">
                        <div className="flex flex-col">
                            <p className="font-medium">{notification.title}</p>
                            <p className="text-xs text-muted-foreground">{notification.description}</p>
                        </div>
                    </DropdownMenuItem>
                  ))}
                  {notifications.length > 5 && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="justify-center text-sm text-muted-foreground hover:bg-accent cursor-pointer">
                          See all notifications
                      </DropdownMenuItem>
                    </>
                  )}
                </>
              )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
