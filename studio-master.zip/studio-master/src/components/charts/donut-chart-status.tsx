"use client";

// This component is not used in FlowKit and can be removed in the future.
export function DonutChartStatus() {
  return null;
}
