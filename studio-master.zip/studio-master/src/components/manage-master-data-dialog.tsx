// This file is no longer used and will be replaced by more specific dialogs.
// It is kept to prevent breaking builds if it's imported elsewhere, but it does nothing.
export function ManageMasterDataDialog() {
  return null;
}
