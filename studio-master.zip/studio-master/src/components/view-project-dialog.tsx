

'use client'

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { Project, Task, UserProfile, Client } from '@/lib/types';
import { format, formatDistance } from 'date-fns';
import { Calendar, Edit, Trash2, Users, ListTodo, CheckCircle, Hourglass, XCircle, Clock, UserCheck, UsersRound, FolderKanban, PowerOff, RotateCcw } from 'lucide-react';
import { Progress } from './ui/progress';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import Image from 'next/image';

interface ViewProjectDialogProps {
  project: Project | null;
  client: Client | null;
  tasks: Task[];
  team: UserProfile[];
  onOpenChange: (open: boolean) => void;
  onEdit: (project: Project) => void;
  onDelete: (project: Project) => void;
  onComplete: (project: Project) => void;
  onReactivate: (project: Project) => void;
  userProfile: UserProfile | null;
  canManage: boolean;
}

export function ViewProjectDialog({ project, client, tasks, team, onOpenChange, onEdit, onDelete, onComplete, onReactivate, userProfile, canManage }: ViewProjectDialogProps) {
  if (!project || !client || !userProfile) return null;

  const handleEdit = () => onEdit(project);
  const handleDelete = () => onDelete(project);
  const handleComplete = () => onComplete(project);
  const handleReactivate = () => onReactivate(project);

  const projectManager = team.find(m => m.uid === project.projectManagerId);
  const teamLeads = team.filter(m => project.teamLeadIds.includes(m.uid));
  const teamMembers = team.filter(m => project.teamMemberIds.includes(m.uid));

  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const progress = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;
  
  const getTaskStatusIcon = (status: Task['status']) => {
    switch(status) {
        case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
        case 'in-progress': return <Hourglass className="h-4 w-4 text-yellow-500" />;
        case 'overdue': return <XCircle className="h-4 w-4 text-red-500" />;
        case 'todo': return <Clock className="h-4 w-4 text-muted-foreground" />;
        case 'pending_review': return <Clock className="h-4 w-4 text-yellow-500" />;
        default: return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  }

  const canEditProject = ['Team Lead', 'Project Manager', 'Director/VP/CXO', 'Super Admin'].includes(userProfile.role);
  const canDeleteProject = ['Director/VP/CXO', 'Super Admin'].includes(userProfile.role);

  return (
    <Dialog open={!!project} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-4">
                <div className="bg-muted p-3 rounded-lg mt-1">
                    <FolderKanban className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <DialogTitle className="text-2xl">{project.name}</DialogTitle>
                  <DialogDescription>{project.projectTypeName}</DialogDescription>
                </div>
            </div>
            <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="font-semibold">{client.name}</p>
                  <p className="text-sm text-muted-foreground">Client Code: {client.code}</p>
                </div>
                <Avatar className="h-12 w-12 border">
                  <AvatarImage src={client.logo} alt={client.name} data-ai-hint="company logo"/>
                  <AvatarFallback>{client.name.charAt(0)}</AvatarFallback>
                </Avatar>
            </div>
          </div>
        </DialogHeader>
        
        <DialogBody>
            <div className="space-y-6">
                {/* General Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center text-sm">
                    <div className="flex items-center gap-3">
                    <Badge variant="secondary" className="h-6 text-base">{project.status}</Badge>
                    </div>
                    <div className="flex items-center gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                        <p className="font-medium">Starts {format(new Date(project.startDate), 'PPP')}</p>
                        {project.endDate && <p className="text-muted-foreground text-xs">{formatDistance(new Date(project.endDate), new Date(project.startDate))} duration</p>}
                    </div>
                    </div>
                    <div>
                        <div className="flex justify-between items-center mb-1">
                            <p className="text-sm font-medium">Progress</p>
                            <p className="text-sm text-muted-foreground">{progress}%</p>
                        </div>
                        <Progress value={progress} className="h-2" />
                    </div>
                </div>

                <Separator />
                
                {/* Assigned Team */}
                <div>
                    <h3 className="text-lg font-semibold mb-4">Assigned Team</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {projectManager && (
                        <div className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <UserCheck className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                            <p className="font-semibold">{projectManager.name}</p>
                            <p className="text-sm text-muted-foreground">Project Manager</p>
                            </div>
                        </div>
                    )}
                    {teamLeads.map(lead => (
                        <div key={lead.uid} className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <UsersRound className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                            <p className="font-semibold">{lead.name}</p>
                            <p className="text-sm text-muted-foreground">Team Lead</p>
                            </div>
                        </div>
                        ))}
                        {teamMembers.map(member => (
                            <div key={member.uid} className="p-4 rounded-lg bg-muted/50 flex items-center gap-4">
                            <Users className="h-5 w-5 text-muted-foreground shrink-0" />
                            <div>
                            <p className="font-semibold">{member.name}</p>
                            <p className="text-sm text-muted-foreground">Team Member</p>
                            </div>
                        </div>
                        ))}
                    </div>
                </div>

                <Separator />
                
                {/* Tasks */}
                <div>
                    <h3 className="text-lg font-semibold mb-4">Tasks ({tasks.length})</h3>
                    <div className="space-y-2 border rounded-lg p-2 max-h-64 overflow-y-auto">
                    {tasks.length > 0 ? (
                        tasks.map(task => (
                        <div key={task.id} className="p-3 rounded-lg bg-muted/50 flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                            {getTaskStatusIcon(task.status)}
                            <div>
                                <p className="font-medium text-sm">{task.title}</p>
                                <p className="text-xs text-muted-foreground">Assigned to: {team.find(m => m.uid === task.assigneeId)?.name || 'N/A'} ・ Due: {format(new Date(task.dueDate), "PPP")}</p>
                            </div>
                            </div>
                            <Badge variant="outline" className="capitalize">{task.priority}</Badge>
                        </div>
                        ))
                    ) : (
                        <p className="text-sm text-muted-foreground bg-muted/50 p-3 text-center rounded-md">No tasks for this project yet.</p>
                    )}
                    </div>
                </div>
            </div>
        </DialogBody>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
            <div className="flex-grow flex justify-end gap-2">
              {canDeleteProject && (
                  <Button onClick={handleDelete} variant="destructive">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Project
                  </Button>
              )}
               {canEditProject && (
                <>
                  {project.status === 'Active' ? (
                    <Button variant="secondary" onClick={handleComplete}>
                        <PowerOff className="mr-2 h-4 w-4" />
                        Complete Project
                    </Button>
                    ) : (
                    <Button variant="secondary" onClick={handleReactivate}>
                            <RotateCcw className="mr-2 h-4 w-4" />
                            Reactivate Project
                        </Button>
                    )}
                  <Button onClick={handleEdit}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Project
                  </Button>
                </>
               )}
            </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
