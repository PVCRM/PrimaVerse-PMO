
"use client"

import { useMemo, useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/role-switcher";
import { Task, UserProfile, Priority } from "@/lib/types";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { usePermissions } from "@/hooks/use-permissions";
import { Button } from './ui/button';
import { roleHierarchy } from '@/data/master-data';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { sortTasks } from '@/ai/flows/sort-tasks-flow';
import { useToast } from '@/hooks/use-toast';
import { ArrowDown, ArrowUp, PlusCircle, Play } from 'lucide-react';
import Link from 'next/link';

interface TasksTableProps {
  tasks: Task[];
  team: UserProfile[];
  userProfile: UserProfile; 
  onRowClick: (task: Task) => void;
  onAddClick: () => void;
  initialTab?: 'ongoing' | 'completed' | 'critical';
  viewMode: 'tasks' | 'all-tasks';
}

type SortableKeys = keyof Task | 'assigneeName';

export function TasksTable({ tasks, team, userProfile, onRowClick, onAddClick, initialTab = 'ongoing', viewMode }: TasksTableProps) {
  const { permissions } = usePermissions();
  const canCreateTasks = permissions[userProfile.role]?.tasks.startsWith('CRUD');

  const inProgressTasks = tasks.filter(t => t.status !== 'completed');
  const completedTasks = tasks.filter(t => t.status === 'completed');
  const criticalTasks = tasks.filter(t => {
      const isOverdue = new Date(t.dueDate) < new Date() && t.status !== 'completed';
      const isHighPriority = t.priority === 'P1' || t.priority === 'P2';
      return t.status !== 'completed' && (isOverdue || isHighPriority);
  });

  const description = viewMode === 'tasks' 
    ? "A list of your assigned tasks. Click a task to see more details."
    : "An overview of all tasks across the organization.";
  
  return (
    <Card className="rounded-xl border shadow-none">
      <CardHeader>
        <CardTitle>{viewMode === 'tasks' ? 'My Tasks' : 'All Tasks'}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={initialTab}>
            <TabsList>
                <TabsTrigger value="ongoing">AI-Sorted Ongoing</TabsTrigger>
                <TabsTrigger value="critical">Critical</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>
            <TabsContent value="ongoing">
                <PaginatedTable 
                    tasks={inProgressTasks}
                    team={team}
                    userProfile={userProfile}
                    onRowClick={onRowClick}
                    onAddClick={onAddClick}
                    canCreateTasks={canCreateTasks}
                    emptyStateTitle="No Ongoing Tasks"
                    emptyStateDescription={canCreateTasks ? "Get started by creating a new task." : "You have no ongoing tasks."}
                    enableAiSort={true}
                />
            </TabsContent>
            <TabsContent value="critical">
                <PaginatedTable 
                    tasks={criticalTasks}
                    team={team}
                    userProfile={userProfile}
                    onRowClick={onRowClick}
                    onAddClick={onAddClick}
                    canCreateTasks={canCreateTasks}
                    emptyStateTitle="No Critical Tasks"
                    emptyStateDescription="Overdue and high-priority tasks will appear here. Great job!"
                />
            </TabsContent>
            <TabsContent value="completed">
                 <PaginatedTable 
                    tasks={completedTasks}
                    team={team}
                    userProfile={userProfile}
                    onRowClick={onRowClick}
                    onAddClick={onAddClick}
                    canCreateTasks={canCreateTasks}
                    emptyStateTitle="No Completed Tasks"
                    emptyStateDescription="Your completed tasks will appear here."
                    isCompletedTab={true}
                />
            </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function PaginatedTable({ tasks, team, userProfile, onRowClick, onAddClick, canCreateTasks, emptyStateTitle, emptyStateDescription, enableAiSort = false, isCompletedTab = false }: any) {
    const [currentPage, setCurrentPage] = useState(1);
    const [sortedTasks, setSortedTasks] = useState(tasks);
    const [isSorting, setIsSorting] = useState(enableAiSort);
    const [manualSortConfig, setManualSortConfig] = useState<{key: SortableKeys, direction: 'asc' | 'desc'} | null>(null);

    const { toast } = useToast();
    const rowsPerPage = 6;
    
    const taskIds = useMemo(() => tasks.map((t: Task) => t.id).join(','), [tasks]);

    useEffect(() => {
        const performSort = async () => {
            if (manualSortConfig) {
                const sorted = [...tasks].sort((a, b) => {
                    const { key, direction } = manualSortConfig;
                    const valA = key === 'assigneeName' ? team.find(m => m.uid === a.assigneeId)?.name || '' : a[key as keyof Task];
                    const valB = key === 'assigneeName' ? team.find(m => m.uid === b.assigneeId)?.name || '' : b[key as keyof Task];

                    if (valA < valB) return direction === 'asc' ? -1 : 1;
                    if (valA > valB) return direction === 'asc' ? 1 : -1;
                    return 0;
                });
                setSortedTasks(sorted);
                setIsSorting(false);
            } else if (enableAiSort && tasks.length > 0) {
                setIsSorting(true);
                try {
                    const serializableTasks = tasks.map((task: Task) => ({
                      ...task,
                      startDate: new Date(task.startDate).toISOString(),
                      dueDate: new Date(task.dueDate).toISOString(),
                      completedAt: task.completedAt ? new Date(task.completedAt).toISOString() : undefined,
                      startedAt: task.startedAt ? new Date(task.startedAt).toISOString() : undefined,
                      activeSince: undefined, // Exclude complex objects
                      reviewLog: [], // Exclude complex objects
                    }));
                    const result = await sortTasks({ tasks: serializableTasks });
                    const sorted = result.sortedTaskIds.map(id => tasks.find((t: Task) => t.id === id)).filter(Boolean) as Task[];
                    const unsorted = tasks.filter((t: Task) => !result.sortedTaskIds.includes(t.id));
                    setSortedTasks([...sorted, ...unsorted]);
                } catch (error) {
                    console.error("AI sorting failed:", error);
                    toast({ variant: 'destructive', title: 'AI Sort Error', description: 'Could not sort tasks. Using default order.' });
                    setSortedTasks(tasks); 
                } finally {
                    setIsSorting(false);
                }
            } else {
                setSortedTasks(tasks);
                setIsSorting(false);
            }
        };
        performSort();
    }, [taskIds, enableAiSort, manualSortConfig]);


    const totalPages = Math.ceil(sortedTasks.length / rowsPerPage);
    const paginatedTasks = sortedTasks.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);
    
    const canViewAssigneeDetail = roleHierarchy[userProfile.role] >= roleHierarchy['Team Lead'];

    const getAssigneeName = (assigneeId: string) => {
        return team.find((member: UserProfile) => member.uid === assigneeId)?.name || 'Unassigned';
    }

    const handleSort = (key: SortableKeys) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (manualSortConfig && manualSortConfig.key === key && manualSortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setManualSortConfig({ key, direction });
    };

    const renderSortArrow = (key: SortableKeys) => {
        if (!manualSortConfig || manualSortConfig.key !== key) return null;
        return manualSortConfig.direction === 'asc' ? <ArrowUp className="ml-2 h-4 w-4" /> : <ArrowDown className="ml-2 h-4 w-4" />;
    };

    const priorityColors: Record<Priority, string> = {
        P1: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
        P2: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
        P3: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
        P4: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
        P5: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200",
    };
    
    if (tasks.length === 0 && !isSorting) {
        return (
            <div className="pt-4">
                <EmptyState 
                    title={emptyStateTitle}
                    description={emptyStateDescription}
                    buttonText={canCreateTasks ? "Add Task" : undefined}
                    onButtonClick={canCreateTasks ? onAddClick : undefined}
                />
            </div>
        );
    }
    
    return (
        <>
            <div className="border rounded-lg mt-4">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="font-bold">
                             <Button variant="ghost" onClick={() => handleSort('title')} className="px-0 hover:bg-transparent">
                                Title {renderSortArrow('title')}
                            </Button>
                        </TableHead>
                        <TableHead className="font-bold">
                             <Button variant="ghost" onClick={() => handleSort('projectName')} className="px-0 hover:bg-transparent">
                                Project {renderSortArrow('projectName')}
                            </Button>
                        </TableHead>
                        <TableHead className="font-bold">
                             <Button variant="ghost" onClick={() => handleSort('assigneeName')} className="px-0 hover:bg-transparent">
                                Assignee {renderSortArrow('assigneeName')}
                            </Button>
                        </TableHead>
                        {isCompletedTab ? (
                            <TableHead className="font-bold">
                                <Button variant="ghost" onClick={() => handleSort('completedAt')} className="px-0 hover:bg-transparent">
                                    Completion Date {renderSortArrow('completedAt')}
                                </Button>
                            </TableHead>
                        ) : (
                            <>
                                <TableHead className="font-bold">
                                    <Button variant="ghost" onClick={() => handleSort('dueDate')} className="px-0 hover:bg-transparent">
                                        Due Date {renderSortArrow('dueDate')}
                                    </Button>
                                </TableHead>
                                <TableHead className="font-bold">
                                     <Button variant="ghost" onClick={() => handleSort('priority')} className="px-0 hover:bg-transparent">
                                        Priority {renderSortArrow('priority')}
                                    </Button>
                                </TableHead>
                            </>
                        )}
                        <TableHead className="font-bold text-center">Status</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {isSorting ? (
                         <TableRow>
                            <TableCell colSpan={7} className="h-24 text-center">
                                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                                    <div className="ai-spinner" />
                                    <span>AI is sorting your tasks...</span>
                                </div>
                            </TableCell>
                        </TableRow>
                    ) : paginatedTasks.map((task: Task) => (
                    <TableRow
                        key={task.id}
                        onClick={() => onRowClick(task)}
                        className="cursor-pointer"
                    >
                        <TableCell className="font-medium">{task.title}</TableCell>
                        <TableCell>{task.projectName}</TableCell>
                        <TableCell>
                            {canViewAssigneeDetail ? (
                                <Button variant="link" asChild className="p-0 h-auto font-normal text-foreground">
                                    <Link href={`/employee-tasks/${task.assigneeId}`} onClick={e => e.stopPropagation()}>{getAssigneeName(task.assigneeId)}</Link>
                                </Button>
                            ) : (
                                <span>{getAssigneeName(task.assigneeId)}</span>
                            )}
                        </TableCell>
                        {isCompletedTab ? (
                             <TableCell>{task.completedAt ? format(new Date(task.completedAt), "PPP") : 'N/A'}</TableCell>
                        ) : (
                            <>
                                <TableCell>{format(new Date(task.dueDate), "PPP")}</TableCell>
                                <TableCell>
                                    <Badge className={cn("capitalize", priorityColors[task.priority])}>{task.priority}</Badge>
                                </TableCell>
                            </>
                        )}
                        <TableCell className="text-center">
                            <Badge variant={isCompletedTab ? 'default' : 'secondary'} className={cn("capitalize", isCompletedTab && "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300")}>{task.status.replace(/_/g, ' ')}</Badge>
                        </TableCell>
                    </TableRow>
                    ))}
                </TableBody>
            </Table>
            </div>
             <div className="flex items-center justify-end space-x-2 py-4">
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</Button>
                <span className="text-sm text-muted-foreground">Page {currentPage} of {totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</Button>
            </div>
        </>
    );
}
