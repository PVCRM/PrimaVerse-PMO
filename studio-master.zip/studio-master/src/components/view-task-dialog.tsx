

'use client';

import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogBody } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import type { Task, Project, Client, UserProfile, Priority, Review } from '@/lib/types';
import { format } from 'date-fns';
import { Calendar, CheckCircle, Clock, Hourglass, ListTodo, Tag, Trash2, User, Users, UserCheck, AlertTriangle, Repeat, MessageSquare, Award, Building, FolderKanban } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { roleHierarchy } from '@/data/master-data';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { LogHoursDialog } from './log-hours-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Input } from './ui/input';
import { Label } from './ui/label';
import { doc, getDoc, collection, query, where, documentId, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Skeleton } from './ui/skeleton';

interface ViewTaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: Task | null;
  onUpdateTask: (taskId: string, data: Partial<Omit<Task, 'id'>>) => Promise<void>;
  onLogHoursAndSubmit: (taskId: string, hours: number) => Promise<void>;
  onDeleteTask: (task: Task) => void;
  refetchTasks: () => void;
}

interface DialogData {
    project: Project | null;
    client: Client | null;
    reviewer: UserProfile | null;
    projectManager: UserProfile | null;
    duLead: UserProfile | null;
    teamLeads: UserProfile[];
}

export function ViewTaskDialog({
  open,
  onOpenChange,
  task,
  onUpdateTask,
  onLogHoursAndSubmit,
  onDeleteTask,
}: ViewTaskDialogProps) {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [isSubmittingTask, setIsSubmittingTask] = useState(false);
  const [isCompletingSelfTask, setIsCompletingSelfTask] = useState(false);
  const [selfCompleteHours, setSelfCompleteHours] = useState('');
  const [dialogData, setDialogData] = useState<DialogData | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(false);

   useEffect(() => {
        if (open && task) {
            const fetchData = async () => {
                setIsLoadingData(true);
                try {
                    // Fetch Project
                    const projectRef = doc(db, 'projects', task.projectId);
                    const projectSnap = await getDoc(projectRef);
                    const project = projectSnap.exists() ? { id: projectSnap.id, ...projectSnap.data() } as Project : null;

                    // Fetch Client
                    let client: Client | null = null;
                    if (project) {
                        const clientRef = doc(db, 'clients', project.clientId);
                        const clientSnap = await getDoc(clientRef);
                        client = clientSnap.exists() ? { id: clientSnap.id, ...clientSnap.data() } as Client : null;
                    }
                    
                    // Gather all manager IDs
                    const managerIds = new Set<string>();
                    if (task.reviewerId) managerIds.add(task.reviewerId);
                    if (project?.projectManagerId) managerIds.add(project.projectManagerId);
                    if (client?.duLeadId) managerIds.add(client.duLeadId);
                    if (project?.teamLeadIds) project.teamLeadIds.forEach(id => managerIds.add(id));

                    const uniqueIds = Array.from(managerIds).filter(Boolean);
                    
                    // Fetch all managers in one query
                    let managers: UserProfile[] = [];
                    if (uniqueIds.length > 0) {
                        const usersQuery = query(collection(db, 'users'), where(documentId(), 'in', uniqueIds));
                        const usersSnap = await getDocs(usersQuery);
                        managers = usersSnap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile));
                    }
                    
                    setDialogData({
                        project,
                        client,
                        reviewer: managers.find(m => m.uid === task.reviewerId) || null,
                        projectManager: managers.find(m => m.uid === project?.projectManagerId) || null,
                        duLead: managers.find(m => m.uid === client?.duLeadId) || null,
                        teamLeads: managers.filter(m => project?.teamLeadIds?.includes(m.uid)) || [],
                    });

                } catch (error) {
                    console.error("Error fetching dialog data:", error);
                    toast({ variant: 'destructive', title: 'Error', description: 'Could not load task details.' });
                } finally {
                    setIsLoadingData(false);
                }
            };
            fetchData();
        } else {
            setDialogData(null); // Reset data when dialog closes
        }
    }, [open, task, toast]);


  if (!task || !userProfile) return null;

  const { project, client, reviewer, projectManager, duLead, teamLeads } = dialogData || {};

  const isAssignee = userProfile.uid === task.assigneeId;
  const isManager = roleHierarchy[userProfile.role] >= 1; // Team Lead or higher
  const isDirectorOrHigher = roleHierarchy[userProfile.role] >= 3;

  const canSubmitForReview = isAssignee && !isManager && !['completed', 'pending_review'].includes(task.status);
  const canDeleteTask = isDirectorOrHigher;
  const canSelfComplete = isAssignee && isManager && !['completed', 'pending_review'].includes(task.status);


  const handleLogHoursSave = async (taskId: string, hours: number) => {
    setIsSaving(true);
    try {
      await onLogHoursAndSubmit(taskId, hours);
      setIsSubmittingTask(false);
      onOpenChange(false);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelfComplete = async () => {
    const hours = parseFloat(selfCompleteHours);
    if (isNaN(hours) || hours <= 0) {
      toast({ variant: 'destructive', title: 'Invalid Hours', description: 'Please enter a valid number of hours.' });
      return;
    }
    
    setIsSaving(true);
    try {
        const totalHours = (task.erroneousHours || 0) + hours;
        await onUpdateTask(task.id, {
            status: 'completed',
            actualHours: hours,
            totalHours: totalHours,
            completedAt: new Date(),
            efficiency: task.estimatedHours > 0 && totalHours > 0 ? Math.round((task.estimatedHours / totalHours) * 100) : 100,
        });
        toast({ title: 'Task Completed', description: 'You have successfully marked the task as complete.' });
        setIsCompletingSelfTask(false);
        onOpenChange(false);
    } catch (e: any) {
        toast({ variant: 'destructive', title: 'Error', description: e.message || 'Could not complete the task.' });
    } finally {
        setIsSaving(false);
    }
  };
  
  const priorityColors: Record<Priority, string> = {
    P1: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    P2: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
    P3: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    P4: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    P5: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200",
  };
  
  const renderReviewLog = (log: Review[]) => (
    <div>
        <h3 className="text-lg font-semibold mb-2">Mistake Log</h3>
        <div className="border rounded-lg max-h-48 overflow-y-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Mistakes</TableHead>
                        <TableHead>Repeated</TableHead>
                        <TableHead>Comment</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {log.map((entry, index) => (
                        <TableRow key={index}>
                            <TableCell className="text-xs">{entry.reviewedAt instanceof Timestamp ? format(entry.reviewedAt.toDate(), 'PP p') : format(new Date(entry.reviewedAt), 'PP p')}</TableCell>
                            <TableCell>{entry.mistakes}</TableCell>
                            <TableCell>{entry.repeatedMistakes}</TableCell>
                            <TableCell className="text-xs">{entry.comment}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    </div>
  );

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <div className="flex items-center gap-4">
              <div className="bg-muted p-3 rounded-lg">
                  <ListTodo className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <DialogTitle className="text-2xl">{task.title}</DialogTitle>
                <DialogDescription>{task.taskTypeName || 'General Task'}</DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <DialogBody>
            {isLoadingData ? (
                <div className="space-y-6">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-32 w-full" />
                </div>
            ) : (
              <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start text-sm">
                      <div className="flex items-center gap-3">
                          <Tag className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Priority</p>
                              <Badge className={cn("capitalize mt-1", priorityColors[task.priority])}>{task.priority}</Badge>
                          </div>
                      </div>
                       <div className="flex items-center gap-3">
                          <CheckCircle className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Status</p>
                              <p className="font-medium capitalize mt-1">{task.status.replace(/_/g, ' ')}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-3">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Start Date</p>
                              <p className="font-medium mt-1">{format(new Date(task.startDate), 'PPP')}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-3">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Due Date</p>
                              <p className="font-medium mt-1">{format(new Date(task.dueDate), 'PPP')}</p>
                          </div>
                      </div>
                  </div>

                  <Separator />
                  
                  <div>
                      <h3 className="text-lg font-semibold mb-2">Description</h3>
                      <div className="p-4 rounded-lg bg-muted/50 text-sm max-h-40 overflow-y-auto">
                          <p className="whitespace-pre-wrap">{task.description || 'No description provided.'}</p>
                      </div>
                  </div>
                  
                  <Separator />

                  <div>
                      <h3 className="text-lg font-semibold mb-4">Project Hierarchy</h3>
                        <div className="space-y-4">
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                               <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                                    <Building className="h-4 w-4 text-muted-foreground shrink-0" />
                                    <div><p className="text-muted-foreground">Client</p><p className="font-medium">{client?.name || 'N/A'}</p></div>
                               </div>
                               <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                                    <FolderKanban className="h-4 w-4 text-muted-foreground shrink-0" />
                                    <div><p className="text-muted-foreground">Project</p><p className="font-medium">{project?.name || 'N/A'}</p></div>
                               </div>
                           </div>
                           <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                               <div className="flex items-center gap-3">
                                  <User className="h-4 w-4 text-muted-foreground shrink-0" />
                                  <div><p className="text-muted-foreground">Reviewer</p><p className="font-medium">{reviewer?.name || 'N/A'}</p></div>
                              </div>
                              <div className="flex items-center gap-3">
                                  <UserCheck className="h-4 w-4 text-muted-foreground shrink-0" />
                                  <div><p className="text-muted-foreground">Project Manager</p><p className="font-medium">{projectManager?.name || 'N/A'}</p></div>
                              </div>
                              <div className="flex items-center gap-3">
                                  <UserCheck className="h-4 w-4 text-muted-foreground shrink-0" />
                                  <div><p className="text-muted-foreground">DU Lead</p><p className="font-medium">{duLead?.name || 'N/A'}</p></div>
                              </div>
                              {(teamLeads || []).map(lead => (
                                  <div key={lead.uid} className="flex items-center gap-3">
                                      <Users className="h-4 w-4 text-muted-foreground shrink-0" />
                                      <div><p className="text-muted-foreground">Team Lead</p><p className="font-medium">{lead.name}</p></div>
                                  </div>
                              ))}
                           </div>
                        </div>
                  </div>
                  
                  <Separator />
                  
                   <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start text-sm">
                      {roleHierarchy[userProfile.role] > 0 && (
                        <div className="flex items-center gap-3">
                            <Hourglass className="h-4 w-4 text-muted-foreground" />
                            <div>
                                <p className="text-muted-foreground">Allotted Hours</p>
                                <p className="font-medium mt-1">{task.estimatedHours} hrs</p>
                            </div>
                        </div>
                      )}
                      <div className="flex items-center gap-3">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Hours Logged (Current Submission)</p>
                              <p className="font-medium mt-1">{task.actualHours ? `${task.actualHours.toFixed(2)} hrs` : 'Not logged'}</p>
                              {task.erroneousHours && task.erroneousHours > 0 && <p className="text-xs text-amber-600">({task.erroneousHours.toFixed(2)}h rework)</p>}
                          </div>
                      </div>
                      <div className="flex items-center gap-3">
                          <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Mistakes</p>
                              <p className="font-medium mt-1">{task.mistakeCount || 0}</p>
                          </div>
                      </div>
                      <div className="flex items-center gap-3">
                          <Repeat className="h-4 w-4 text-muted-foreground" />
                          <div>
                              <p className="text-muted-foreground">Repeated</p>
                              <p className="font-medium mt-1">{task.repeatedMistakeCount || 0}</p>
                          </div>
                      </div>
                      {task.efficiency !== undefined && (
                          <div className="flex items-center gap-3">
                              <Award className="h-4 w-4 text-muted-foreground" />
                              <div>
                                  <p className="text-muted-foreground">Efficiency</p>
                                  <p className="font-medium mt-1">{task.efficiency}%</p>
                              </div>
                          </div>
                      )}
                  </div>
                  
                  {task.reviewLog && task.reviewLog.length > 0 && (
                      <>
                        <Separator />
                        {renderReviewLog(task.reviewLog)}
                      </>
                  )}
              </div>
            )}
          </DialogBody>

          <DialogFooter>
            {canDeleteTask && (
               <Button variant="destructive" className="mr-auto" onClick={() => onDeleteTask(task)}>
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Task
              </Button>
            )}
            <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
            {canSelfComplete && (
              <Button onClick={() => setIsCompletingSelfTask(true)} disabled={isSaving}>
                  {isSaving && <div className="ai-spinner mr-2"/>}
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Mark as Complete
              </Button>
            )}
            {canSubmitForReview && (
              <Button onClick={() => setIsSubmittingTask(true)} disabled={isSaving}>
                  {isSaving && <div className="ai-spinner mr-2"/>}
                  Log Hours &amp; Submit for Review
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <LogHoursDialog
        task={isSubmittingTask ? task : null}
        title="Submit Task For Review"
        description={`Enter the total hours spent on the task: "${task?.title}". This will lock the task and send it for approval.`}
        onOpenChange={(open) => { if (!open) setIsSubmittingTask(false); }}
        onSave={handleLogHoursSave}
      />
      <AlertDialog open={isCompletingSelfTask} onOpenChange={setIsCompletingSelfTask}>
          <AlertDialogContent>
              <AlertDialogHeader>
                  <AlertDialogTitle>Complete Self-Assigned Task</AlertDialogTitle>
                  <AlertDialogDescription>
                      Please log the hours you spent on this task. This will mark the task as complete and log your hours to the timesheet.
                  </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="py-4">
                  <Label htmlFor="self-complete-hours">Hours Spent</Label>
                  <Input 
                    id="self-complete-hours" 
                    type="number" 
                    value={selfCompleteHours}
                    onChange={(e) => setSelfCompleteHours(e.target.value)}
                    placeholder={`e.g., ${task.estimatedHours}`}
                  />
              </div>
              <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSelfComplete} disabled={isSaving}>
                      {isSaving && <div className="ai-spinner mr-2"/>}
                      Confirm & Complete
                  </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
