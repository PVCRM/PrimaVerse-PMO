
"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { usePendingRequests } from '@/hooks/use-pending-requests';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/hooks/use-toast';
import type { UserRole, UserProfile, RoleElevationRequest, ProfileChangeRequest, TimesheetEntry } from '@/lib/types';
import { allRoles, roleHierarchy } from '@/data/master-data';
import { format, formatDistanceToNow, addDays, differenceInDays } from 'date-fns';
import { Badge } from './ui/badge';
import { AlertCircle, Clock4, CheckCircle, XCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { TimesheetData, useTimesheet } from '@/hooks/use-timesheet';
import { useTeam } from '@/hooks/use-team';
import { startOfDay, subDays } from 'date-fns';
import { collection, query, where, getDocs, writeBatch, doc, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

interface ApprovalsPageProps {
    onDataChange: () => void;
}

export function ApprovalsPage({ onDataChange }: ApprovalsPageProps) {
    const { 
        pendingUsers, 
        deactivatedUsers,
        deletedUsers,
        roleRequests, 
        profileChangeRequests, 
        loading, 
        error 
    } = usePendingRequests();
    
    const { 
        approveUser, rejectUser, 
        approveRoleRequest, rejectRoleRequest,
        approveProfileChange, rejectProfileChange,
        reactivateUser,
        deleteUserRecord,
    } = useAuth();
    
    const [selectedRoles, setSelectedRoles] = useState<Record<string, UserRole>>({});
    const { toast } = useToast();

    const handleApproveUser = async (user: UserProfile) => {
        const role = selectedRoles[user.uid];
        if (!role) {
            toast({ variant: 'destructive', title: 'Error', description: 'Please select a role for the user.' });
            return;
        }
        try {
            await approveUser(user.uid, role);
            toast({ title: 'Success', description: `${user.name} has been approved.` });
            onDataChange();
        } catch (e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to approve user.' });
        }
    };
    
    const handleRejectUser = async (uid: string) => {
        try {
            await rejectUser(uid);
            toast({ title: "User Rejected", description: "This user's account has been rejected." });
            onDataChange();
        } catch (e: any) {
            toast({ variant: "destructive", title: "Error", description: e.message || 'Failed to reject user.' });
        }
    };

    const handleReactivate = async (uid: string) => {
        try {
            await reactivateUser(uid);
            toast({ title: 'Success', description: `User has been reactivated.` });
            onDataChange();
        } catch (e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to reactivate user.' });
        }
    }
    const handleDeletePermanently = async (uid: string) => {
         try {
            await deleteUserRecord(uid);
            toast({ title: 'Success', description: `User record has been permanently deleted.` });
            onDataChange();
        } catch (e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to delete user record.' });
        }
    }

    const handleApproveRoleRequest = async (request: RoleElevationRequest) => {
        try {
            await approveRoleRequest(request);
            toast({ title: 'Success', description: `${request.userName}'s role has been updated.`});
            onDataChange();
        } catch(e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to approve role request.' });
        }
    }

    const handleRejectRoleRequest = async (requestId: string) => {
        try {
            await rejectRoleRequest(requestId);
            toast({ title: 'Request Rejected', description: `The role request has been rejected.`});
            onDataChange();
        } catch(e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to reject role request.' });
        }
    }
    
    const handleApproveProfileChange = async (request: ProfileChangeRequest) => {
        try {
            await approveProfileChange(request);
            toast({ title: 'Success', description: `${request.userName}'s profile has been updated.`});
            onDataChange();
        } catch(e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to approve profile change.' });
        }
    }

    const handleRejectProfileChange = async (requestId: string) => {
        try {
            await rejectProfileChange(requestId);
            toast({ title: 'Request Rejected', description: `The profile change request has been rejected.`});
            onDataChange();
        } catch(e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to reject profile change.' });
        }
    }

    
    if (loading) return <div className="flex justify-center items-center p-8"><div className="ai-spinner" /></div>;
    if (error) return <p className="text-destructive">Error loading requests: {error.message}</p>;

    return (
        <Tabs defaultValue="onboarding" className="w-full">
            <TabsList>
                <TabsTrigger value="onboarding">New User Onboarding</TabsTrigger>
                <TabsTrigger value="role_requests">Role Requests</TabsTrigger>
                <TabsTrigger value="profile_requests">Profile Requests</TabsTrigger>
                <TabsTrigger value="timesheets">Timesheet Approvals</TabsTrigger>
                <TabsTrigger value="inactive_users">Inactive Users</TabsTrigger>
            </TabsList>
            <TabsContent value="onboarding">
                <NewUserApprovals 
                    users={pendingUsers} 
                    onApprove={handleApproveUser}
                    onReject={handleRejectUser}
                    selectedRoles={selectedRoles}
                    setSelectedRoles={setSelectedRoles}
                />
            </TabsContent>
            <TabsContent value="role_requests">
                <RoleElevationApprovals 
                    requests={roleRequests}
                    onApprove={handleApproveRoleRequest}
                    onReject={handleRejectRoleRequest}
                />
            </TabsContent>
            <TabsContent value="profile_requests">
                <ProfileChangeApprovals 
                    requests={profileChangeRequests}
                    onApprove={handleApproveProfileChange}
                    onReject={handleRejectProfileChange}
                />
            </TabsContent>
            <TabsContent value="timesheets">
                <TimesheetApprovals />
            </TabsContent>
            <TabsContent value="inactive_users">
                <InactiveUsers
                    deactivatedUsers={deactivatedUsers}
                    deletedUsers={deletedUsers}
                    onReactivate={handleReactivate}
                    onRestore={handleReactivate} // Restore is same as reactivate
                    onDeletePermanently={handleDeletePermanently}
                />
            </TabsContent>
        </Tabs>
    );
}

function NewUserApprovals({ users, onApprove, onReject, selectedRoles, setSelectedRoles }: { users: UserProfile[], onApprove: (user: UserProfile) => void, onReject: (uid: string) => void, selectedRoles: Record<string, UserRole>, setSelectedRoles: (roles: Record<string, UserRole>) => void }) {
    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader>
                <CardTitle>New User Onboarding</CardTitle>
                <CardDescription>Review and approve new users who have signed up. {users.length === 0 && 'There are no new users awaiting approval.'}</CardDescription>
            </CardHeader>
            {users.length > 0 && (
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Department</TableHead>
                                <TableHead>Assign Role</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {users.map(user => (
                                <TableRow key={user.uid}>
                                    <TableCell>
                                        <div className="font-medium">{user.name}</div>
                                        <div className="text-sm text-muted-foreground">{user.email}</div>
                                    </TableCell>
                                    <TableCell>{Array.isArray(user.department) ? user.department.join(', ') : user.department}</TableCell>
                                    <TableCell>
                                        <Select 
                                            value={selectedRoles[user.uid]}
                                            onValueChange={(role) => setSelectedRoles({ ...selectedRoles, [user.uid]: role as UserRole })}>
                                            <SelectTrigger className="w-[180px]">
                                                <SelectValue placeholder="Select a role" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {allRoles.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex items-center justify-end space-x-2">
                                            <Button variant="outline" size="sm" onClick={() => onReject(user.uid)}>Reject</Button>
                                            <Button size="sm" onClick={() => onApprove(user)}>Approve</Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            )}
        </Card>
    );
}

function RoleElevationApprovals({ requests, onApprove, onReject }: { requests: RoleElevationRequest[], onApprove: (req: RoleElevationRequest) => void, onReject: (id: string) => void }) {
    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader>
                <CardTitle>Role Elevation Requests</CardTitle>
                <CardDescription>Approve or reject requests for role promotions. {requests.length === 0 && 'There are no pending role requests.'}</CardDescription>
            </CardHeader>
            {requests.length > 0 && (
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Change</TableHead>
                                <TableHead>Requested</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {requests.map(req => (
                                <TableRow key={req.id}>
                                    <TableCell>
                                        <div className="font-medium">{req.userName}</div>
                                        <div className="text-sm text-muted-foreground">{req.userEmail}</div>
                                    </TableCell>
                                    <TableCell>
                                        <span className="text-muted-foreground">{req.currentRole}</span> → <span className="font-medium">{req.requestedRole}</span>
                                    </TableCell>
                                    <TableCell>{formatDistanceToNow(new Date(req.requestedAt), { addSuffix: true })}</TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex items-center justify-end space-x-2">
                                            <Button variant="outline" size="sm" onClick={() => onReject(req.id!)}>Reject</Button>
                                            <Button size="sm" onClick={() => onApprove(req)}>Approve</Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            )}
        </Card>
    );
}

function ProfileChangeApprovals({ requests, onApprove, onReject }: { requests: ProfileChangeRequest[], onApprove: (req: ProfileChangeRequest) => void, onReject: (id: string) => void }) {
    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader>
                <CardTitle>Profile Change Requests</CardTitle>
                <CardDescription>Approve or reject requests for department or designation changes. {requests.length === 0 && 'There are no pending profile change requests.'}</CardDescription>
            </CardHeader>
            {requests.length > 0 && (
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Change</TableHead>
                                <TableHead>Requested</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                        {requests.map(req => (
                                <TableRow key={req.id}>
                                    <TableCell>
                                        <div className="font-medium">{req.userName}</div>
                                        <div className="text-sm text-muted-foreground">{req.userEmail}</div>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex flex-col">
                                            <span>Dept: <span className="text-muted-foreground">{Array.isArray(req.currentDepartment) ? req.currentDepartment.join(', ') : req.currentDepartment}</span> → <span className="font-medium">{req.requestedDepartment}</span></span>
                                            <span>Desig: <span className="text-muted-foreground">{req.currentDesignation}</span> → <span className="font-medium">{req.requestedDesignation}</span></span>
                                        </div>
                                    </TableCell>
                                    <TableCell>{formatDistanceToNow(new Date(req.requestedAt), { addSuffix: true })}</TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex items-center justify-end space-x-2">
                                            <Button variant="outline" size="sm" onClick={() => onReject(req.id!)}>Reject</Button>
                                            <Button size="sm" onClick={() => onApprove(req)}>Approve</Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            )}
        </Card>
    );
}

function TimesheetApprovals() {
    const { userProfile } = useAuth();
    const { team } = useTeam();
    const { toast } = useToast();
    const [date, setDate] = useState(startOfDay(new Date()));
    const [pendingTimesheets, setPendingTimesheets] = useState<TimesheetData[]>([]);
    const [loading, setLoading] = useState(true);

    const managedTeamIds = team
        .filter(t => roleHierarchy[t.role] < roleHierarchy[userProfile!.role])
        .map(t => t.uid);
    
    useEffect(() => {
        if (managedTeamIds.length === 0) {
            setLoading(false);
            return;
        }
        setLoading(true);
        const q = query(
            collection(db, "timesheet"),
            where('userId', 'in', managedTeamIds),
            where('isSubmitted', '==', true),
            where('isApproved', '==', false),
            where('needsRevision', '==', false),
        );
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const aggregates = new Map<string, Omit<TimesheetData, 'status'>>();

            snapshot.docs.forEach(doc => {
                const entry = { id: doc.id, ...doc.data() } as TimesheetEntry;
                const entryDate = (entry.date as any as Timestamp).toDate();
                if (!isSameDay(entryDate, date)) return;

                const key = `${entry.userId}-${format(entryDate, 'yyyy-MM-dd')}`;
                
                if (!aggregates.has(key)) {
                    aggregates.set(key, {
                        userId: entry.userId,
                        date: entryDate,
                        totalHours: 0,
                        entryIds: [],
                        isApproved: false,
                        needsApproval: true,
                    });
                }
                const current = aggregates.get(key)!;
                current.totalHours += entry.hours;
                current.entryIds.push(entry.id);
            });
            const dataWithStatus = Array.from(aggregates.values()).map(ts => ({
                ...ts,
                status: ts.totalHours >= 9 ? 'Complete' as const : 'Partial' as const,
            }));

            setPendingTimesheets(dataWithStatus);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching pending timesheets:", error);
            setLoading(false);
        });
        return () => unsubscribe();
    }, [managedTeamIds, date]);


    const handleApprovalAction = async (timesheetUserId: string, entryIds: string[], action: 'approve' | 'reject') => {
        if (entryIds.length === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'No timesheet entries found for this user and date.' });
            return;
        }

        const batch = writeBatch(db);
        entryIds.forEach(id => {
            const docRef = doc(db, 'timesheet', id);
            batch.update(docRef, { 
                isApproved: action === 'approve', 
                needsRevision: action === 'reject' 
            });
        });
        
        try {
            await batch.commit();
            toast({ title: 'Success', description: `Timesheet has been ${action === 'approve' ? 'approved' : 'sent for revision'}.` });
        } catch (error) {
            console.error('Error processing timesheet:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not process the timesheet.' });
        }
    };

    const statusConfig = {
      'Complete': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'Partial': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    }

    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Timesheet Approvals</CardTitle>
                    <CardDescription>
                        Review and approve submitted timesheets from your team.
                    </CardDescription>
                </div>
                 <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" onClick={() => setDate(subDays(date, 1))}>
                        <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="font-semibold text-lg w-48 text-center">{format(date, 'PPP')}</span>
                    <Button variant="outline" size="icon" onClick={() => setDate(addDays(date, 1))}>
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </CardHeader>
            {loading ? (
                <CardContent className="flex justify-center items-center p-8"><div className="ai-spinner" /></CardContent>
            ) : pendingTimesheets.length > 0 ? (
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Employee</TableHead>
                                <TableHead>Hours Logged</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {pendingTimesheets.map(ts => {
                                const employee = team.find(t => t.uid === ts.userId);
                                if (!employee) return null;
                                return (
                                    <TableRow key={ts.userId}>
                                        <TableCell className="font-medium">{employee.name}</TableCell>
                                        <TableCell>{ts.totalHours.toFixed(2)} / 9.00</TableCell>
                                        <TableCell><span className={cn('px-2 py-1 text-xs font-medium rounded-full', statusConfig[ts.status as keyof typeof statusConfig])}>{ts.status}</span></TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex items-center justify-end space-x-2">
                                                <Button variant="ghost" size="sm" onClick={() => handleApprovalAction(ts.userId, ts.entryIds, 'reject')}><XCircle className="mr-2 h-4 w-4" /> Reject</Button>
                                                <Button variant="outline" size="sm" onClick={() => handleApprovalAction(ts.userId, ts.entryIds, 'approve')}><CheckCircle className="mr-2 h-4 w-4" /> Approve</Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                )
                            })}
                        </TableBody>
                    </Table>
                </CardContent>
            ) : (
                <CardContent className="text-center text-muted-foreground py-12">
                    No timesheets awaiting approval for {format(date, 'PPP')}.
                </CardContent>
            )}
        </Card>
    );
}


function InactiveUsers({ deactivatedUsers, deletedUsers, onReactivate, onRestore, onDeletePermanently }: { deactivatedUsers: UserProfile[], deletedUsers: UserProfile[], onReactivate: (uid: string) => void, onRestore: (uid: string) => void, onDeletePermanently: (uid: string) => void }) {
    return (
        <div className="space-y-6">
            <Card className="rounded-xl border shadow-none">
                <CardHeader>
                    <CardTitle>Deactivated Users</CardTitle>
                    <CardDescription>These users are in sleep mode and cannot log in. They can be reactivated at any time. {deactivatedUsers.length === 0 && 'There are no deactivated users.'}</CardDescription>
                </CardHeader>
                {deactivatedUsers.length > 0 && (
                    <CardContent>
                        <Table>
                            <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Department</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                            <TableBody>
                                {deactivatedUsers.map(user => (
                                    <TableRow key={user.uid}>
                                        <TableCell><div className="font-medium">{user.name}</div><div className="text-sm text-muted-foreground">{user.email}</div></TableCell>
                                        <TableCell>{Array.isArray(user.department) ? user.department.join(', ') : user.department}</TableCell>
                                        <TableCell className="text-right"><Button size="sm" variant="outline" onClick={() => onReactivate(user.uid)}>Reactivate</Button></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                )}
            </Card>

            <Card className="rounded-xl border shadow-none">
                <CardHeader>
                    <CardTitle>Recently Deleted Users</CardTitle>
                    <CardDescription>These users have been soft-deleted. They can be restored within 30 days of deletion. {deletedUsers.length === 0 && 'There are no recently deleted users.'}</CardDescription>
                </CardHeader>
                {deletedUsers.length > 0 && (
                    <CardContent>
                        <Table>
                            <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Deleted On</TableHead><TableHead>Restorable Until</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                            <TableBody>
                                {deletedUsers.map(user => {
                                    const deletedDate = user.deletedAt ? new Date(user.deletedAt) : new Date();
                                    const restorableUntil = addDays(deletedDate, 30);
                                    const isExpired = differenceInDays(new Date(), restorableUntil) > 0;
                                    
                                    return (
                                        <TableRow key={user.uid}>
                                            <TableCell><div className="font-medium">{user.name}</div><div className="text-sm text-muted-foreground">{user.email}</div></TableCell>
                                            <TableCell>{format(deletedDate, 'PPP')}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    {isExpired && <AlertCircle className="h-4 w-4 text-destructive" />}
                                                    <span className={isExpired ? 'text-destructive' : ''}>{format(restorableUntil, 'PPP')}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="space-x-2">
                                                    <Button size="sm" variant="outline" onClick={() => onRestore(user.uid)} disabled={isExpired}>Restore</Button>
                                                    <Button size="sm" variant="destructive" onClick={() => onDeletePermanently(user.uid)}>Delete Permanently</Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    )
                                })}
                            </TableBody>
                        </Table>
                    </CardContent>
                )}
            </Card>
        </div>
    )
}
