

"use client"

import { useState, useMemo, useCallback, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useTasks } from '@/hooks/use-tasks';
import { useTeam } from '@/hooks/use-team';
import { useProjects } from '@/hooks/use-projects';
import { useToast } from '@/hooks/use-toast';
import type { Task, Review, TimesheetEntry } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Filter } from 'lucide-react';
import { EmptyState } from './role-switcher';
import { ReviewTaskDialog } from './review-task-dialog';
import { Timestamp, collection, addDoc, doc, writeBatch, onSnapshot, query, where, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { format, startOfDay } from 'date-fns';
import { roleHierarchy } from '@/data/master-data';
import { LogHoursDialog } from './log-hours-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { DateRange } from "react-day-picker";
import { subDays, isSameDay } from 'date-fns';


interface TimesheetAggregate {
    userId: string;
    userName: string;
    date: Date;
    totalHours: number;
    entryIds: string[];
}

type ApprovalItem = 
    | { type: 'task'; data: Task; submittedAt: Date; }
    | { type: 'timesheet'; data: TimesheetAggregate; submittedAt: Date; };


export function ReviewsAndApprovalsPage() {
    const { userProfile } = useAuth();
    const { tasks, loading: loadingTasks, updateTask } = useTasks();
    const { team, loading: loadingTeam } = useTeam();
    const { projects, loading: loadingProjects } = useProjects();
    const { toast } = useToast();
    
    // States for task review dialog
    const [reviewingTask, setReviewingTask] = useState<Task | null>(null);
    const [reviewAction, setReviewAction] = useState<'approve' | 'reject'>('approve');
    const [taskToLogReviewTimeFor, setTaskToLogReviewTimeFor] = useState<Task | null>(null);

    // State for timesheet approvals
    const [pendingTimesheets, setPendingTimesheets] = useState<TimesheetAggregate[]>([]);
    const [loadingTimesheet, setLoadingTimesheet] = useState(true);
    

    const managedTeamIds = useMemo(() => {
        if (!userProfile) return [];
        return team.filter(t => t.reviewerId === userProfile.uid).map(t => t.uid);
    }, [userProfile, team]);

    useEffect(() => {
        if (!userProfile || roleHierarchy[userProfile.role] < 1 || managedTeamIds.length === 0) {
            setLoadingTimesheet(false);
            return;
        }

        const q = query(
            collection(db, "timesheet"),
            where('userId', 'in', managedTeamIds),
            where('isSubmitted', '==', true),
            where('isApproved', '==', false),
            where('needsRevision', '==', false)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const aggregates = new Map<string, TimesheetAggregate>();

            snapshot.docs.forEach(doc => {
                const entry = { id: doc.id, ...doc.data() } as TimesheetEntry;
                const entryDate = (entry.date as any as Timestamp).toDate();
                const key = `${entry.userId}-${format(entryDate, 'yyyy-MM-dd')}`;
                
                const employee = team.find(t => t.uid === entry.userId);

                if (!aggregates.has(key)) {
                    aggregates.set(key, {
                        userId: entry.userId,
                        userName: employee?.name || 'Unknown User',
                        date: entryDate,
                        totalHours: 0,
                        entryIds: [],
                    });
                }
                const current = aggregates.get(key)!;
                current.totalHours += entry.hours;
                current.entryIds.push(entry.id);
            });

            setPendingTimesheets(Array.from(aggregates.values()));
            setLoadingTimesheet(false);
        }, (error) => {
            console.error("Error fetching pending timesheets for notifications:", error);
            setLoadingTimesheet(false);
        });

        return () => unsubscribe();

    }, [userProfile, managedTeamIds, team]);


    const approvalItems = useMemo(() => {
        if (!userProfile) return [];

        const taskItems: ApprovalItem[] = tasks
            .filter(task => task.reviewerId === userProfile.uid && task.status === 'pending_review')
            .map(task => ({
                type: 'task',
                data: task,
                submittedAt: task.startedAt || new Date(), // Use startedAt as submission proxy
            }));

        const timesheetItems: ApprovalItem[] = (pendingTimesheets || [])
            .map(ts => ({
                type: 'timesheet',
                data: ts,
                submittedAt: startOfDay(new Date(ts.date)),
            }));
        
        return [...taskItems, ...timesheetItems].sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
    }, [userProfile, tasks, pendingTimesheets]);

    const handleOpenTaskReviewDialog = (task: Task, action: 'approve' | 'reject') => {
        setReviewAction(action);
        setReviewingTask(task);
    }
    
    const handleSaveTaskReview = async (taskId: string, mistakeCount: number, repeatedMistakeCount: number, comments: string) => {
        const taskToUpdate = tasks.find(t => t.id === taskId);
        if (!taskToUpdate) return;
        
        const newReview: Review = {
            comment: comments,
            mistakes: mistakeCount,
            repeatedMistakes: repeatedMistakeCount,
            reviewedAt: Timestamp.now(),
        };

        const existingLog = taskToUpdate.reviewLog || [];
        const updatedLog = [...existingLog, newReview];
        
        const totalMistakes = updatedLog.reduce((sum, log) => sum + log.mistakes, 0);
        const totalRepeatedMistakes = updatedLog.reduce((sum, log) => sum + log.repeatedMistakes, 0);
        
        try {
            if (reviewAction === 'approve') {
                 const totalHours = (taskToUpdate.erroneousHours || 0) + (taskToUpdate.actualHours || 0);

                await updateTask(taskId, {
                    status: 'completed',
                    completedAt: new Date(),
                    mistakeCount: totalMistakes,
                    repeatedMistakeCount: totalRepeatedMistakes,
                    reviewLog: updatedLog,
                    totalHours: totalHours,
                    efficiency: taskToUpdate.estimatedHours > 0 && totalHours > 0 ? Math.round((taskToUpdate.estimatedHours / totalHours) * 100) : 100,
                });

                toast({ title: 'Task Approved', description: `"${taskToUpdate.title}" has been marked as complete and hours logged to timesheet.` });
            } else { // Reject
                await updateTask(taskId, {
                    status: 'in-progress',
                    erroneousHours: (taskToUpdate.erroneousHours || 0) + (taskToUpdate.actualHours || 0),
                    actualHours: 0,
                    mistakeCount: totalMistakes,
                    repeatedMistakeCount: totalRepeatedMistakes,
                    reviewLog: updatedLog,
                });
                toast({ title: 'Task Rejected', description: `"${taskToUpdate.title}" has been sent back for revision.` });
            }
            setTaskToLogReviewTimeFor(taskToUpdate);
        } catch (error: any) {
            toast({ variant: 'destructive', title: 'Error', description: error.message || `Could not ${reviewAction} task.` });
        }
    };

    const handleLogReviewerHours = async (taskId: string, hours: number) => {
        if (!userProfile || !taskToLogReviewTimeFor) return;

        try {
            const timesheetCollectionRef = collection(db, 'timesheet');
            await addDoc(timesheetCollectionRef, {
                userId: userProfile.uid,
                date: Timestamp.now(),
                type: 'review',
                taskId: taskId,
                projectId: taskToLogReviewTimeFor.projectId,
                projectName: "Review",
                taskName: `Review: ${taskToLogReviewTimeFor.title}`,
                description: `Review for task: ${taskToLogReviewTimeFor.title}`,
                hours: hours,
                isSubmitted: false,
                isApproved: false,
                needsRevision: false,
            });
            toast({ title: "Review Time Logged", description: `You have logged ${hours} hour(s) for reviewing the task.` });
            setTaskToLogReviewTimeFor(null);
        } catch (error) {
            console.error("Error logging reviewer hours:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not log your review time.' });
        }
    };
    
    const handleTimesheetApprovalAction = async (timesheetUserId: string, entryIds: string[], action: 'approve' | 'reject') => {
        if (entryIds.length === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'No timesheet entries found for this user and date.' });
            return;
        }

        const batch = writeBatch(db);
        entryIds.forEach(id => {
            const docRef = doc(db, 'timesheet', id);
            batch.update(docRef, { 
                isApproved: action === 'approve', 
                needsRevision: action === 'reject' 
            });
        });
        
        try {
            await batch.commit();
            toast({ title: 'Success', description: `Timesheet has been ${action === 'approve' ? 'approved' : 'sent for revision'}.` });
        } catch (error) {
            console.error('Error processing timesheet:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not process the timesheet.' });
        }
    };

    if (loadingTasks || loadingTeam || loadingTimesheet || loadingProjects) {
        return <div className="flex justify-center p-8"><div className="ai-spinner"/></div>
    }

    return (
        <>
            <Card className="rounded-xl border shadow-none">
                <CardHeader>
                    <CardTitle>Reviews &amp; Approvals Queue</CardTitle>
                    <CardDescription>Review and approve tasks and timesheets submitted by your team.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {approvalItems.length === 0 ? (
                        <div className="pt-8">
                             <EmptyState title="No Items to Review" description="Your team has no pending tasks or timesheets for you to review." />
                        </div>
                    ) : (
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Type</TableHead>
                                        <TableHead>Details</TableHead>
                                        <TableHead>Submitted By</TableHead>
                                        <TableHead>Submitted On</TableHead>
                                        <TableHead className="text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {approvalItems.map((item, index) => {
                                        const assigneeId = item.type === 'task' ? item.data.assigneeId : item.data.userId;
                                        const assignee = team.find(t => t.uid === assigneeId);

                                        return (
                                            <TableRow key={`${item.type}-${'id' in item.data ? item.data.id : item.data.userId}-${index}`}>
                                                <TableCell className="font-medium capitalize">{item.type}</TableCell>
                                                <TableCell>
                                                    {item.type === 'task' ? item.data.title : `Timesheet for ${format(new Date(item.data.date), 'PPP')}`}
                                                </TableCell>
                                                <TableCell>{assignee?.name || 'N/A'}</TableCell>
                                                <TableCell>{format(item.submittedAt, 'PP p')}</TableCell>
                                                <TableCell className="text-right space-x-2">
                                                    <Button variant="ghost" size="sm" onClick={() => item.type === 'task' ? handleOpenTaskReviewDialog(item.data, 'reject') : handleTimesheetApprovalAction(item.data.userId, item.data.entryIds, 'reject')}>
                                                        <XCircle className="h-4 w-4 mr-2" /> Reject
                                                    </Button>
                                                    <Button variant="outline" size="sm" onClick={() => item.type === 'task' ? handleOpenTaskReviewDialog(item.data, 'approve') : handleTimesheetApprovalAction(item.data.userId, item.data.entryIds, 'approve')}>
                                                        <CheckCircle className="h-4 w-4 mr-2" /> Approve
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        )
                                    })}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>
            <ReviewTaskDialog 
                task={reviewingTask}
                onOpenChange={() => setReviewingTask(null)}
                onSave={handleSaveTaskReview}
                actionType={reviewAction}
            />
            <LogHoursDialog
                task={taskToLogReviewTimeFor}
                title="Log Review Hours"
                description={`Enter the hours spent reviewing: "${taskToLogReviewTimeFor?.title}"`}
                onOpenChange={() => setTaskToLogReviewTimeFor(null)}
                onSave={handleLogReviewerHours}
            />
        </>
    );
}
