
"use client";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from 'lucide-react';

export function PendingApprovalBanner() {
    return (
        <div className="p-4 border-b">
            <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Account Pending Approval</AlertTitle>
                <AlertDescription>
                    Your account is currently awaiting approval from an administrator. 
                    Your access is limited until your account is activated. You can configure your profile in the settings page.
                </AlertDescription>
            </Alert>
        </div>
    )
}
