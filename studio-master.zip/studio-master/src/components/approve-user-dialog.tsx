
"use client";

import { useState, useEffect } from 'react';
import type { UserProfile, UserRole } from '@/lib/types';
import { allRoles } from '@/data/master-data';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface ApproveUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApprove: (role: UserRole) => Promise<void>;
  employee: UserProfile;
}

export function ApproveUserDialog({ open, onOpenChange, onApprove, employee }: ApproveUserDialogProps) {
  const [selectedRole, setSelectedRole] = useState<UserRole | ''>('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (open && employee) {
      setSelectedRole(employee.role || '');
    } else {
      setSelectedRole('');
    }
  }, [open, employee]);

  const handleApprove = async () => {
    if (!selectedRole) return;
    setIsSaving(true);
    await onApprove(selectedRole);
    setIsSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Approve {employee.name}</DialogTitle>
          <DialogDescription>Select a role for this user to activate their account.</DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <Label htmlFor="role-select" className="mb-2 block">Assign Role</Label>
          <Select value={selectedRole} onValueChange={(role) => setSelectedRole(role as UserRole)}>
            <SelectTrigger id="role-select"><SelectValue placeholder="Select a role..." /></SelectTrigger>
            <SelectContent>{allRoles.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleApprove} disabled={!selectedRole || isSaving}>
            {isSaving && <div className="ai-spinner mr-2" />}
            Approve User
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
