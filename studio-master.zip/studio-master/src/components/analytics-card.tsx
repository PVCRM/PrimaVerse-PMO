
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { LucideIcon } from 'lucide-react';

interface KpiCardProps {
  title: string
  value: string
  description?: string
  footer?: string
  isWarning?: boolean
  icon?: LucideIcon
  className?: string;
  onClick?: () => void;
}

export function KpiCard({ title, description, value, footer, isWarning = false, icon: Icon, className, onClick }: KpiCardProps) {
  const cardClassName = cn(
    "shadow-none rounded-xl p-2 transition-all hover:shadow-md hover:-translate-y-1",
    onClick && "cursor-pointer",
    className
  );

  return (
    <Card className={cardClassName} onClick={onClick}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold">{title}</CardTitle>
            {Icon && <div className="p-3 bg-primary/10 rounded-lg"><Icon className="h-5 w-5 text-primary" /></div>}
        </div>
        {description && <CardDescription className="text-xs pt-1">{description}</CardDescription>}
      </CardHeader>
      <CardContent className="flex items-baseline gap-2">
        <p className={cn("text-3xl font-bold", isWarning ? "text-destructive" : "text-foreground")}>
          {value}
        </p>
        {footer && <p className={cn("text-xs", isWarning ? "text-destructive" : "text-muted-foreground")}>{footer}</p>}
      </CardContent>
    </Card>
  )
}
    