

"use client";

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogBody,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { Task } from "@/lib/types";

interface LogHoursDialogProps {
  task: Task | null;
  title?: string;
  description?: string;
  onOpenChange: (open: boolean) => void;
  onSave: (taskId: string, hours: number) => Promise<void>;
}

export function LogHoursDialog({ task, title, description, onOpenChange, onSave }: LogHoursDialogProps) {
  const [hours, setHours] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (task) {
      setHours(""); // Reset hours when a new task is selected
    }
  }, [task]);

  const handleSave = async () => {
    const numHours = parseFloat(hours);
    if (!task || isNaN(numHours) || numHours <= 0) {
      toast({
        variant: "destructive",
        title: "Invalid Input",
        description: "Please enter a valid number of hours.",
      });
      return;
    }

    setIsSaving(true);
    try {
      await onSave(task.id, numHours);
      onOpenChange(false); // Close dialog on successful save
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to log hours.",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={!!task} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title || "Log Actual Hours"}</DialogTitle>
          <DialogDescription>
            {description || `Enter the total hours spent on the task: "${task?.title}".`}
          </DialogDescription>
        </DialogHeader>
        <DialogBody>
          <div className="space-y-2">
            <Label htmlFor="actual-hours">Hours</Label>
            <Input
              id="actual-hours"
              type="number"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              placeholder={`e.g., ${task?.estimatedHours || 2}`}
            />
          </div>
        </DialogBody>
        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            disabled={isSaving}
          >
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving && <div className="ai-spinner mr-2" />}
            Save & Log
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
