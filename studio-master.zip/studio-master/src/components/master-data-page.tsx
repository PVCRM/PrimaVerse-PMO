

"use client"

import { useState, useEffect, useMemo } from 'react';
import { useMasterData } from '@/context/master-data-context';
import { useToast } from '@/hooks/use-toast';
import { allRoles, roleHierarchy } from '@/data/master-data';
import type { Department, Designation, ProjectType, TaskType } from '@/lib/types';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogBody } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, Edit, Trash2, ArrowUp, ArrowDown, Upload } from "lucide-react";
import { Textarea } from './ui/textarea';
import type { MasterDataItem } from '@/context/master-data-context';
import { ImportProjectTypesDialog } from './import-project-types-dialog';
import { ImportTaskTypesDialog } from './import-task-types-dialog';


type SortDirection = 'asc' | 'desc';
type SortConfig = { key: string; direction: SortDirection };

export function MasterDataPage() {
    const { masterData, addMasterDataItem, updateMasterDataItem, deleteMasterDataItem, bulkAddProjectTypes, bulkAddTaskTypes } = useMasterData();
    const [activeTab, setActiveTab] = useState('departments');
    const [isImportProjectTypesOpen, setIsImportProjectTypesOpen] = useState(false);
    const [isImportTaskTypesOpen, setIsImportTaskTypesOpen] = useState(false);

    const [sortConfig, setSortConfig] = useState({
        departments: { key: 'name', direction: 'asc' } as SortConfig,
        designations: { key: 'departmentName', direction: 'asc' } as SortConfig,
        projectTypes: { key: 'departmentName', direction: 'asc' } as SortConfig,
        taskTypes: { key: 'departmentName', direction: 'asc' } as SortConfig,
    });

    const handleSort = (tab: keyof typeof sortConfig) => (key: string) => {
        setSortConfig(prev => {
            const isAsc = prev[tab].key === key && prev[tab].direction === 'asc';
            return {
                ...prev,
                [tab]: {
                    key,
                    direction: isAsc ? 'desc' : 'asc',
                }
            };
        });
    };
    
    const sortedData = useMemo(() => {
        const departments = [...masterData.departments];
        const designations = masterData.designations.map(d => ({...d, departmentName: masterData.departments.find(dep => dep.id === d.departmentId)?.name || 'N/A'}));
        const projectTypes = masterData.projectTypes.map(pt => ({...pt, departmentName: masterData.departments.find(dep => dep.id === pt.departmentId)?.name || 'N/A'}));
        const taskTypes = masterData.taskTypes.map(tt => {
            const projectType = masterData.projectTypes.find(pt => pt.id === tt.projectTypeId);
            const department = projectType ? masterData.departments.find(d => d.id === projectType.departmentId) : null;
            return {
                ...tt,
                projectTypeName: projectType?.name || 'N/A',
                departmentName: department?.name || 'N/A',
            }
        });
        
        const sort = <T,>(data: T[], config: SortConfig) => {
            const { key, direction } = config;
            if (key) {
                (data as any[]).sort((a, b) => {
                    if (a[key] < b[key]) return direction === 'asc' ? -1 : 1;
                    if (a[key] > b[key]) return direction === 'asc' ? 1 : -1;
                    return 0;
                });
            }
            return data;
        };
        
        return {
            departments: sort(departments, sortConfig.departments),
            designations: sort(designations, sortConfig.designations),
            projectTypes: sort(projectTypes, sortConfig.projectTypes),
            taskTypes: sort(taskTypes, sortConfig.taskTypes),
        }
    }, [masterData, sortConfig]);

    return (
        <>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="departments">Departments</TabsTrigger>
                <TabsTrigger value="designations">Designations</TabsTrigger>
                <TabsTrigger value="project_types">Project Types</TabsTrigger>
                <TabsTrigger value="task_types">Task Types</TabsTrigger>
                <TabsTrigger value="roles">Roles</TabsTrigger>
            </TabsList>
            <TabsContent value="departments">
                <MasterDataTable
                    title="Departments"
                    description="Manage the departments in your organization."
                    data={sortedData.departments}
                    columns={[{ accessor: 'name', header: 'Department Name' }]}
                    collectionName="departments"
                    FormComponent={DepartmentForm}
                    addMasterDataItem={addMasterDataItem}
                    updateMasterDataItem={updateMasterDataItem}
                    deleteMasterDataItem={deleteMasterDataItem}
                    sortConfig={sortConfig.departments}
                    onSort={handleSort('departments')}
                />
            </TabsContent>
            <TabsContent value="designations">
                 <MasterDataTable
                    title="Designations"
                    description="Manage job titles and link them to departments."
                    data={sortedData.designations}
                    columns={[{ accessor: 'name', header: 'Designation Name' }, { accessor: 'departmentName', header: 'Department' }]}
                    collectionName="designations"
                    FormComponent={DesignationForm}
                    addMasterDataItem={addMasterDataItem}
                    updateMasterDataItem={updateMasterDataItem}
                    deleteMasterDataItem={deleteMasterDataItem}
                    dependencies={{ departments: masterData.departments }}
                    sortConfig={sortConfig.designations}
                    onSort={handleSort('designations')}
                />
            </TabsContent>
            <TabsContent value="project_types">
                 <MasterDataTable
                    title="Project Types"
                    description="Manage the types of projects your teams work on."
                    data={sortedData.projectTypes}
                    columns={[{ accessor: 'name', header: 'Project Type Name' }, { accessor: 'departmentName', header: 'Department' }]}
                    collectionName="projectTypes"
                    FormComponent={ProjectTypeForm}
                    onImportClick={() => setIsImportProjectTypesOpen(true)}
                    addMasterDataItem={addMasterDataItem}
                    updateMasterDataItem={updateMasterDataItem}
                    deleteMasterDataItem={deleteMasterDataItem}
                    dependencies={{ departments: masterData.departments }}
                    sortConfig={sortConfig.projectTypes}
                    onSort={handleSort('projectTypes')}
                />
            </TabsContent>
            <TabsContent value="task_types">
                 <MasterDataTable
                    title="Task Types"
                    description="Manage predefined tasks for different project types."
                    data={sortedData.taskTypes}
                    columns={[
                        { accessor: 'name', header: 'Task Type Name' }, 
                        { accessor: 'projectTypeName', header: 'Project Type' },
                        { accessor: 'departmentName', header: 'Department' }
                    ]}
                    collectionName="taskTypes"
                    FormComponent={TaskTypeForm}
                    onImportClick={() => setIsImportTaskTypesOpen(true)}
                    addMasterDataItem={addMasterDataItem}
                    updateMasterDataItem={updateMasterDataItem}
                    deleteMasterDataItem={deleteMasterDataItem}
                    dependencies={{ departments: masterData.departments, projectTypes: masterData.projectTypes }}
                    sortConfig={sortConfig.taskTypes}
                    onSort={handleSort('taskTypes')}
                />
            </TabsContent>
            <TabsContent value="roles">
                <Card className="rounded-xl border shadow-none">
                     <CardHeader className="pb-2">
                        <CardTitle className="text-lg">System Roles</CardTitle>
                        <p className="text-sm text-muted-foreground pt-1">
                            These are the core user roles in the system. They are fixed and cannot be changed from this interface.
                        </p>
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Role</TableHead>
                                        <TableHead>Permissions Level</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {[...allRoles, 'Super Admin'].map(role => (
                                        <TableRow key={role}>
                                            <TableCell className="font-medium">{role}</TableCell>
                                            <TableCell>Level {roleHierarchy[role]}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </TabsContent>
        </Tabs>
        
        <ImportProjectTypesDialog 
            open={isImportProjectTypesOpen}
            onOpenChange={setIsImportProjectTypesOpen}
            onImport={bulkAddProjectTypes}
        />
        <ImportTaskTypesDialog
            open={isImportTaskTypesOpen}
            onOpenChange={setIsImportTaskTypesOpen}
            onImport={bulkAddTaskTypes}
        />
        </>
    );
}

interface MasterDataTableProps<T extends MasterDataItem> {
    title: string;
    description: string;
    data: T[];
    columns: { accessor: keyof T; header: string }[];
    collectionName: 'departments' | 'designations' | 'projectTypes' | 'taskTypes';
    FormComponent: React.FC<any>;
    onImportClick?: () => void;
    addMasterDataItem: Function;
    updateMasterDataItem: Function;
    deleteMasterDataItem: Function;
    sortConfig: SortConfig;
    onSort: (key: string) => void;
    dependencies?: Record<string, any>;
}

function MasterDataTable<T extends MasterDataItem>({ 
    title, description, data, columns, collectionName, 
    FormComponent, onImportClick, addMasterDataItem, updateMasterDataItem, deleteMasterDataItem, 
    dependencies, sortConfig, onSort
}: MasterDataTableProps<T>) {
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<T | null>(null);

    const handleOpenForm = (item: T | null = null) => {
        setEditingItem(item);
        setIsFormOpen(true);
    };

    const handleSave = async (itemData: Omit<T, 'id'> | Omit<T, 'id'>[]) => {
        if (editingItem) {
            // Edit mode is always single
            await updateMasterDataItem(collectionName, editingItem.id, itemData as Omit<T, 'id'>);
        } else {
            // Add mode can be single or bulk
            await addMasterDataItem(collectionName, itemData);
        }
        setIsFormOpen(false);
        setEditingItem(null);
    };

    return (
        <Card className="rounded-xl border shadow-none">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                    <CardTitle className="text-lg">{title}</CardTitle>
                    <p className="text-sm text-muted-foreground pt-1">{description}</p>
                </div>
                <div className="flex items-center gap-2">
                    {onImportClick && (
                        <Button variant="outline" onClick={onImportClick}>
                            <Upload className="mr-2 h-4 w-4" /> Import from CSV
                        </Button>
                    )}
                    <Button onClick={() => handleOpenForm()}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Add New
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                <div className="border rounded-lg">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                {columns.map(col => (
                                    <TableHead key={String(col.accessor)}>
                                        <Button variant="ghost" onClick={() => onSort(String(col.accessor))} className="px-2 py-1 h-auto -ml-2">
                                            {col.header}
                                            {sortConfig.key === col.accessor && (
                                                sortConfig.direction === 'asc' 
                                                    ? <ArrowUp className="ml-2 h-4 w-4" /> 
                                                    : <ArrowDown className="ml-2 h-4 w-4" />
                                            )}
                                        </Button>
                                    </TableHead>
                                ))}
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {data.map(item => (
                                <TableRow key={item.id}>
                                    {columns.map(col => <TableCell key={String(col.accessor)}>{item[col.accessor] as any}</TableCell>)}
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="icon" onClick={() => handleOpenForm(item)}><Edit className="h-4 w-4" /></Button>
                                        <Button variant="ghost" size="icon" onClick={() => deleteMasterDataItem(collectionName, item.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                <FormComponent
                    open={isFormOpen}
                    onOpenChange={setIsFormOpen}
                    itemToEdit={editingItem}
                    onSave={handleSave}
                    {...dependencies}
                />
            </CardContent>
        </Card>
    );
}

// --- Forms --- //

function DepartmentForm({ open, onOpenChange, onSave, itemToEdit }: { open: boolean, onOpenChange: (open: boolean) => void, onSave: (data: Omit<Department, 'id'> | Omit<Department, 'id'>[]) => void, itemToEdit: Department | null }) {
    const [name, setName] = useState('');
    const isEditMode = !!itemToEdit;

    useEffect(() => {
        if (open && itemToEdit) {
            setName(itemToEdit.name);
        } else {
            setName('');
        }
    }, [open, itemToEdit]);
    
    const handleClose = () => {
        setName('');
        onOpenChange(false);
    }

    const handleSubmit = () => { 
        if (!name) return;
        if (isEditMode) {
            onSave({ name });
        } else {
            const names = name.split(',').map(n => n.trim()).filter(Boolean);
            if(names.length > 0) {
                onSave(names.map(n => ({ name: n })));
            } else {
                handleClose();
            }
        }
    };

    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{itemToEdit ? 'Edit' : 'Add'} Department</DialogTitle>
                    <DialogDescription>
                        {isEditMode ? 'Enter the new name for the department.' : 'Enter one or more department names, separated by commas.'}
                    </DialogDescription>
                </DialogHeader>
                <DialogBody>
                    <div className="space-y-2">
                        <Label htmlFor="dept-name">Department Name{isEditMode ? '' : '(s)'}</Label>
                        {isEditMode ? (
                           <Input id="dept-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Civil Engineering" />
                        ) : (
                           <Textarea id="dept-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Civil Engineering, Mechanical, MEP (BIM)" />
                        )}
                    </div>
                </DialogBody>
                <DialogFooter>
                    <Button variant="ghost" onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleSubmit}>{itemToEdit ? 'Update' : 'Save'}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function DesignationForm({ open, onOpenChange, onSave, itemToEdit, departments }: { open: boolean, onOpenChange: (open: boolean) => void, onSave: (data: Omit<Designation, 'id'> | Omit<Designation, 'id'>[]) => void, itemToEdit: Designation | null, departments: Department[] }) {
    const [name, setName] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const isEditMode = !!itemToEdit;

    useEffect(() => {
        if (open && itemToEdit) {
            setName(itemToEdit.name || '');
            setDepartmentId(itemToEdit.departmentId || '');
        } else {
            setName('');
            setDepartmentId('');
        }
    }, [open, itemToEdit]);
    
    const handleClose = () => {
        setName('');
        setDepartmentId('');
        onOpenChange(false);
    }

    const handleSubmit = () => { 
        if (!name || !departmentId) return;
        if (isEditMode) {
             onSave({ name, departmentId });
        } else {
            const names = name.split(',').map(n => n.trim()).filter(Boolean);
            if(names.length > 0) {
                onSave(names.map(n => ({ name: n, departmentId })));
            } else {
                handleClose();
            }
        }
    };

    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{itemToEdit ? 'Edit' : 'Add'} Designation</DialogTitle>
                    <DialogDescription>
                        {isEditMode ? 'Update the designation.' : 'Define new designations for a department. For multiple, separate names with commas.'}
                    </DialogDescription>
                </DialogHeader>
                <DialogBody>
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="desig-dept">Department</Label>
                            <Select value={departmentId} onValueChange={setDepartmentId}>
                                <SelectTrigger id="desig-dept"><SelectValue placeholder="Select a department" /></SelectTrigger>
                                <SelectContent>
                                    {departments.map(dept => <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="desig-name">Designation Name{isEditMode ? '' : '(s)'}</Label>
                             {isEditMode ? (
                               <Input id="desig-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Senior Engineer"/>
                             ) : (
                               <Textarea id="desig-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Jr. Engineer, Sr. Engineer, Team Lead"/>
                             )}
                        </div>
                    </div>
                </DialogBody>
                <DialogFooter>
                    <Button variant="ghost" onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleSubmit}>{itemToEdit ? 'Update' : 'Save'}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function ProjectTypeForm({ open, onOpenChange, onSave, itemToEdit, departments }: { open: boolean, onOpenChange: (open: boolean) => void, onSave: (data: Omit<ProjectType, 'id'> | Omit<ProjectType, 'id'>[]) => void, itemToEdit: ProjectType | null, departments: Department[] }) {
    const [name, setName] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const isEditMode = !!itemToEdit;

    useEffect(() => {
        if (open && itemToEdit) {
            setName(itemToEdit.name || '');
            setDepartmentId(itemToEdit.departmentId || '');
        } else {
            setName('');
            setDepartmentId('');
        }
    }, [open, itemToEdit]);
    
    const handleClose = () => {
        setName('');
        setDepartmentId('');
        onOpenChange(false);
    };

    const handleSubmit = () => { 
        if (!name || !departmentId) return;
        if(isEditMode) {
            onSave({ name, departmentId });
        } else {
            const names = name.split(',').map(n => n.trim()).filter(Boolean);
            if(names.length > 0) {
                onSave(names.map(n => ({ name: n, departmentId })));
            } else {
                handleClose();
            }
        }
    };
    
    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{itemToEdit ? 'Edit' : 'Add'} Project Type</DialogTitle>
                     <DialogDescription>
                         {isEditMode ? 'Update the project type.' : 'Define new project types for a department. For multiple, separate names with commas.'}
                    </DialogDescription>
                </DialogHeader>
                <DialogBody>
                    <div className="space-y-4">
                         <div className="space-y-2">
                            <Label htmlFor="pt-dept">Department</Label>
                            <Select value={departmentId} onValueChange={setDepartmentId}>
                                <SelectTrigger id="pt-dept"><SelectValue placeholder="Select a department" /></SelectTrigger>
                                <SelectContent>
                                    {departments.map(dept => <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="pt-name">Project Type Name{isEditMode ? '' : '(s)'}</Label>
                            {isEditMode ? (
                               <Input id="pt-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Land Development"/>
                            ) : (
                               <Textarea id="pt-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Survey, Land Development, Structural"/>
                            )}
                        </div>
                    </div>
                </DialogBody>
                <DialogFooter>
                    <Button variant="ghost" onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleSubmit}>{itemToEdit ? 'Update' : 'Save'}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function TaskTypeForm({ open, onOpenChange, onSave, itemToEdit, departments, projectTypes }: { open: boolean, onOpenChange: (open: boolean) => void, onSave: (data: Omit<TaskType, 'id'> | Omit<TaskType, 'id'>[]) => void, itemToEdit: TaskType | null, departments: Department[], projectTypes: ProjectType[] }) {
    const [name, setName] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const [projectTypeId, setProjectTypeId] = useState('');
    const isEditMode = !!itemToEdit;

    const availableProjectTypes = useMemo(() => {
        if (!departmentId) return [];
        return projectTypes.filter(pt => pt.departmentId === departmentId);
    }, [departmentId, projectTypes]);

    useEffect(() => {
        if (open && itemToEdit) {
            const projectType = projectTypes.find(pt => pt.id === itemToEdit.projectTypeId);
            setName(itemToEdit.name);
            setProjectTypeId(itemToEdit.projectTypeId);
            if (projectType) {
                setDepartmentId(projectType.departmentId);
            }
        } else {
            setName('');
            setDepartmentId('');
            setProjectTypeId('');
        }
    }, [open, itemToEdit, projectTypes]);
    
    useEffect(() => {
        if (!isEditMode) {
             setProjectTypeId('');
        }
    }, [departmentId, isEditMode]);
    
    const handleClose = () => {
        setName('');
        setDepartmentId('');
        setProjectTypeId('');
        onOpenChange(false);
    };

    const handleSubmit = () => { 
        if (!name || !projectTypeId) return;
        if(isEditMode) {
            onSave({ name, projectTypeId });
        } else {
            const names = name.split(',').map(n => n.trim()).filter(Boolean);
            if (names.length > 0) {
                 onSave(names.map(n => ({ name: n, projectTypeId })));
            } else {
                handleClose();
            }
        }
    };
    
    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{itemToEdit ? 'Edit' : 'Add'} Task Type</DialogTitle>
                     <DialogDescription>
                         {isEditMode ? 'Update the task type.' : 'Define new task types for a project type. For multiple, separate names with commas.'}
                    </DialogDescription>
                </DialogHeader>
                <DialogBody>
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="tt-dept">Department</Label>
                            <Select value={departmentId} onValueChange={setDepartmentId}>
                                <SelectTrigger id="tt-dept"><SelectValue placeholder="Select a department" /></SelectTrigger>
                                <SelectContent>
                                    {departments.map(dept => <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="tt-pt">Project Type</Label>
                            <Select value={projectTypeId} onValueChange={setProjectTypeId} disabled={!departmentId}>
                                <SelectTrigger id="tt-pt"><SelectValue placeholder="Select a project type" /></SelectTrigger>
                                <SelectContent>
                                    {availableProjectTypes.map(pt => <SelectItem key={pt.id} value={pt.id}>{pt.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="tt-name">Task Type Name{isEditMode ? '' : '(s)'}</Label>
                            {isEditMode ? (
                               <Input id="tt-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Boundary"/>
                            ) : (
                                <Textarea id="tt-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Boundary, Topo, Linework"/>
                            )}
                        </div>
                    </div>
                </DialogBody>
                <DialogFooter>
                    <Button variant="ghost" onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleSubmit}>{itemToEdit ? 'Update' : 'Save'}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

    
