

"use client";

import { useMemo, useEffect, useState } from 'react';
import { useAuth } from './use-auth';
import { usePendingRequests } from './use-pending-requests';
import { useTasks } from './use-tasks';
import { format } from 'date-fns';
import { useTeam } from './use-team';
import { roleHierarchy } from '@/data/master-data';
import { collection, query, where, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { TimesheetEntry } from '@/lib/types';


export type NotificationType = 'new_user' | 'role_request' | 'profile_request' | 'timesheet_approval' | 'task_approval';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  description: string;
  createdAt: Date; // For sorting
  link?: string;
}

export function useNotifications() {
    const { userProfile } = useAuth();
    const { pendingUsers, roleRequests, profileChangeRequests, loading: loadingRequests } = usePendingRequests();
    const { team, loading: loadingTeam } = useTeam();
    const { tasks, loading: loadingTasks } = useTasks();
    const [pendingTimesheets, setPendingTimesheets] = useState<TimesheetEntry[]>([]);
    const [loadingTimesheet, setLoadingTimesheet] = useState(true);

    const managedTeamIds = useMemo(() => {
        if (!userProfile || !team) return [];
        // A user's reviewer is their manager. We find all team members who report to the current user.
        return team.filter(t => t.reviewerId === userProfile.uid).map(t => t.uid);
    }, [userProfile, team]);

    useEffect(() => {
        if (!userProfile || roleHierarchy[userProfile.role] < 1 || managedTeamIds.length === 0) {
            setLoadingTimesheet(false);
            return;
        }

        const q = query(
            collection(db, "timesheet"),
            where('userId', 'in', managedTeamIds),
            where('isSubmitted', '==', true),
            where('isApproved', '==', false),
            where('needsRevision', '==', false)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedTimesheets = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                date: (doc.data().date as Timestamp).toDate(),
            })) as TimesheetEntry[];
            setPendingTimesheets(fetchedTimesheets);
        }, (error) => {
            console.error("Error fetching pending timesheets for notifications:", error);
            setLoadingTimesheet(false);
        });

        return () => unsubscribe();

    }, [userProfile, managedTeamIds]);

    const notifications = useMemo(() => {
        if (!userProfile) return [];

        const allNotifications: Notification[] = [];
        
        // Task and Timesheet approvals for relevant managers
        if (roleHierarchy[userProfile.role] >= 1) { // Team Leads and above
            // Task Approvals
            tasks.forEach(task => {
                if (task.reviewerId === userProfile.uid && task.status === 'pending_review') {
                     allNotifications.push({
                        id: `task-${task.id}`,
                        type: 'task_approval',
                        title: 'Task For Review',
                        description: `${team.find(t=>t.uid===task.assigneeId)?.name || 'A user'} submitted task: "${task.title}".`,
                        createdAt: task.startedAt || new Date(),
                        link: '/dashboard?view=reviews-approvals',
                    });
                }
            });

            // Timesheet Approvals
            const processedTimesheets = new Map<string, Notification>();
            pendingTimesheets.forEach(ts => {
                const key = `${ts.userId}-${format(ts.date, 'yyyy-MM-dd')}`;
                if (!processedTimesheets.has(key)) {
                    const employee = team.find(t => t.uid === ts.userId);
                    if (employee) {
                        processedTimesheets.set(key, {
                             id: `timesheet-${key}`,
                             type: 'timesheet_approval',
                             title: 'Timesheet For Review',
                             description: `${employee.name} submitted their timesheet for ${format(ts.date, 'PPP')}.`,
                             createdAt: ts.date,
                             link: '/dashboard?view=reviews-approvals',
                        });
                    }
                }
            });
            allNotifications.push(...Array.from(processedTimesheets.values()));
        }
        
        // Admin-level approvals
        if (userProfile.role === 'Super Admin') {
            pendingUsers.forEach(user => {
                const createdAtDate = user.createdAt instanceof Date ? user.createdAt : user.createdAt.toDate();
                allNotifications.push({
                    id: `user-${user.uid}`,
                    type: 'new_user',
                    title: 'New User For Approval',
                    description: `${user.name} is waiting for approval.`,
                    createdAt: createdAtDate,
                    link: '/dashboard?view=approvals'
                });
            });

            roleRequests.forEach(req => {
                allNotifications.push({
                    id: `role-${req.id!}`,
                    type: 'role_request',
                    title: 'Role Elevation Request',
                    description: `${req.userName} requested promotion to ${req.requestedRole}.`,
                    createdAt: new Date(req.requestedAt),
                    link: '/dashboard?view=approvals'
                });
            });

             profileChangeRequests.forEach(req => {
                allNotifications.push({
                    id: `profile-${req.id!}`,
                    type: 'profile_request',
                    title: 'Profile Change Request',
                    description: `${req.userName} requested a profile change.`,
                    createdAt: new Date(req.requestedAt),
                    link: '/dashboard?view=approvals'
                });
            });
        }
        
        return allNotifications.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    }, [userProfile, pendingUsers, roleRequests, profileChangeRequests, team, tasks, pendingTimesheets]);

    const loading = loadingRequests || loadingTeam || loadingTimesheet || loadingTasks;

    return { notifications, loading };
}
