
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, query, where, onSnapshot, Timestamp, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { UserSession } from '@/lib/types';
import { startOfDay, endOfDay } from 'date-fns';

export function useUserSessions(date: Date, userId?: string) {
    const [sessions, setSessions] = useState<UserSession[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchSessions = useCallback(async () => {
        setLoading(true);
        const start = startOfDay(date);
        const end = endOfDay(date);

        let q;
        if (userId) {
            q = query(
                collection(db, "user-sessions"),
                where('userId', '==', userId),
                where('loginTime', '>=', start),
                where('loginTime', '<=', end),
                orderBy('loginTime', 'asc')
            );
        } else {
             q = query(
                collection(db, "user-sessions"),
                where('loginTime', '>=', start),
                where('loginTime', '<=', end)
            );
        }

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedSessions = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
            } as UserSession));
            setSessions(fetchedSessions);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching user sessions:", error);
            setLoading(false);
        });

        return unsubscribe;
    }, [date, userId]);

    useEffect(() => {
        const unsubscribePromise = fetchSessions();
        return () => {
            unsubscribePromise.then(unsub => unsub && unsub());
        };
    }, [fetchSessions]);

    return { sessions, loading };
}

    