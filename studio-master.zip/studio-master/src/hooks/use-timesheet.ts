
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, query, where, onSnapshot, Timestamp, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { startOfDay, isSameDay } from 'date-fns';
import type { TimesheetEntry, UserProfile } from '@/lib/types';
import { roleHierarchy } from '@/data/master-data';


export function useTimesheet(userProfile: UserProfile | null, team: UserProfile[]) {
    const [timesheetData, setTimesheetData] = useState<TimesheetEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);

    const refetchTimesheet = useCallback(async () => {
        if (!userProfile) {
            setTimesheetData([]);
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);
        
        let userIdsToFetch: string[] = [];
        switch(userProfile.role) {
            case 'Employee':
                userIdsToFetch = [userProfile.uid];
                break;
            case 'Team Lead':
                userIdsToFetch = team.filter(m => m.reviewerId === userProfile.uid).map(m => m.uid);
                userIdsToFetch.push(userProfile.uid);
                break;
            case 'Project Manager':
            case 'Director/VP/CXO':
            case 'Super Admin':
                userIdsToFetch = team.map(m => m.uid);
                break;
        }
        
        if (userIdsToFetch.length === 0) {
            setTimesheetData([]);
            setLoading(false);
            return;
        }

        try {
            // Firestore 'in' query has a limit of 30. For larger teams, batching is needed.
            const q = query(
                collection(db, "timesheet"),
                where('userId', 'in', userIdsToFetch.slice(0, 30))
            );
            
            const snapshot = await getDocs(q);
            const allUserEntries = snapshot.docs.map(doc => ({ 
                id: doc.id, 
                ...doc.data(),
                date: (doc.data().date as Timestamp).toDate(),
            })) as TimesheetEntry[];

            setTimesheetData(allUserEntries);

        } catch (err: any) {
             console.error("Error fetching timesheet data:", err);
             setError(err);
        } finally {
            setLoading(false);
        }
    }, [userProfile, team]);

    useEffect(() => {
        refetchTimesheet();
    }, [refetchTimesheet]);

    return { timesheetData, loading, error, refetchTimesheet };
}
