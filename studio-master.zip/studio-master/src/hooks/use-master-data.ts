// This file is intentionally left with minimal code.
// The main context logic has been moved to /src/context/master-data-context.tsx
// to resolve a build error related to using JSX in a .ts file.

import { useMasterData as useMasterDataContext } from '@/context/master-data-context';

// Re-export for any potential internal usage, though direct use is now from context.
export const useMasterData = useMasterDataContext;
