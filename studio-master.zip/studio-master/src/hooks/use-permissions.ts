
"use client";

import { useState, useEffect, useCallback } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { UserRole, Permission, PermissionLevel } from '@/lib/types';
import { allRoles, roleHierarchy } from '@/data/master-data';

type PermissionsConfig = Record<UserRole, Permission>;

const defaultPermissions: PermissionsConfig = {
    'Employee': { dashboard: 'View Only', clients: 'Hide', projects: 'Hide', tasks: 'Mark Complete', team: 'Hide', reports: 'Hide' },
    'Team Lead': { dashboard: 'View Only', clients: 'CRUD', projects: 'CRUD', tasks: 'CRUD', team: 'CRUD', reports: 'Hide' },
    'Project Manager': { dashboard: 'View Only', clients: 'CRUD', projects: 'CRUD', tasks: 'CRUD + Billing', team: 'CRUD', reports: 'CRUD' },
    'Director/VP/CXO': { dashboard: 'CRUD', clients: 'CRUD + Billing', projects: 'CRUD + Billing', tasks: 'CRUD + Billing', team: 'CRUD', reports: 'CRUD' },
    'Super Admin': { dashboard: 'CRUD', clients: 'CRUD + Billing', projects: 'CRUD + Billing', tasks: 'CRUD + Billing', team: 'CRUD', reports: 'CRUD' },
};

export function usePermissions() {
    const [permissions, setPermissions] = useState<PermissionsConfig>({} as PermissionsConfig);
    const [loading, setLoading] = useState(true);

    const fetchPermissions = useCallback(async () => {
        setLoading(true);
        try {
            const docRef = doc(db, 'app-config', 'permissions');
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                const data = docSnap.data() as PermissionsConfig;
                const completePermissions = { ...defaultPermissions };
                allRoles.forEach(role => {
                    completePermissions[role] = data[role] || defaultPermissions[role];
                });
                completePermissions['Super Admin'] = defaultPermissions['Super Admin'];
                setPermissions(completePermissions);
            } else {
                await setDoc(docRef, defaultPermissions);
                setPermissions(defaultPermissions);
            }
        } catch (error) {
            console.error("Error fetching permissions:", error);
            setPermissions(defaultPermissions);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchPermissions();
    }, [fetchPermissions]);

    const updatePermission = (role: UserRole, module: keyof Permission, level: PermissionLevel) => {
        if (role === 'Super Admin') return; 
        setPermissions(prev => ({
            ...prev,
            [role]: {
                ...prev[role],
                [module]: level
            }
        }));
    };

    const savePermissions = async () => {
        const docRef = doc(db, 'app-config', 'permissions');
        const permissionsToSave = { ...permissions, 'Super Admin': defaultPermissions['Super Admin'] };
        await setDoc(docRef, permissionsToSave);
    };

    const isAtLeast = (role: UserRole, userRole?: UserRole) => {
      if (!userRole) return false;
      return roleHierarchy[userRole] >= roleHierarchy[role];
    }

    return { permissions, loading, updatePermission, savePermissions, refetch: fetchPermissions, isAtLeast };
}
