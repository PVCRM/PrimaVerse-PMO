
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, Timestamp, where, addDoc, doc, updateDoc, deleteDoc, getDoc, or } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Project } from '@/lib/types';
import { useAuth } from './use-auth';
import { usePermissions } from './use-permissions';
import { roleHierarchy } from '@/data/master-data';

export function useProjects(ready: boolean = true) {
  const { userProfile } = useAuth();
  const { permissions, loading: loadingPermissions } = usePermissions();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchProjects = useCallback(async () => {
    if (!ready || !userProfile || loadingPermissions) {
        if (!loadingPermissions) setLoading(false);
        return;
    }

    const userPermissions = permissions[userProfile.role];
    if (!userPermissions || userPermissions.projects === 'Hide') {
        setProjects([]);
        setLoading(false);
        return;
    }
    
    setLoading(true);
    setError(null);
    try {
      const projectsRef = collection(db, 'projects');
      let q;
      
      const userLevel = roleHierarchy[userProfile.role];
      const userDepartments = Array.isArray(userProfile.department) ? userProfile.department : [''];

      if (userLevel >= roleHierarchy['Super Admin']) {
        q = query(projectsRef, orderBy('startDate', 'desc'));
      } else if (userLevel >= roleHierarchy['Director/VP/CXO'] && userDepartments.length > 0) {
        q = query(projectsRef, where('department', 'in', userDepartments), orderBy('startDate', 'desc'));
      } else if (userLevel >= roleHierarchy['Team Lead']) {
         q = query(projectsRef, where('teamIds', 'array-contains', userProfile.uid));
      } else { 
        q = query(projectsRef, where('teamIds', 'array-contains', userProfile.uid));
      }
      
      if (!q) {
        setProjects([]);
        setLoading(false);
        return;
      }

      const querySnapshot = await getDocs(q);
      let allProjects = querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          status: data.status || 'Active', 
          startDate: (data.startDate as Timestamp).toDate(),
          endDate: data.endDate ? (data.endDate as Timestamp).toDate() : undefined,
        } as Project;
      });

      // The OR query for PM/TL cannot be combined with orderBy, so we sort client-side.
      if (userLevel >= roleHierarchy['Team Lead'] && userLevel < roleHierarchy['Director/VP/CXO']) {
        allProjects.sort((a, b) => b.startDate.getTime() - a.startDate.getTime());
      }
      
      setProjects(allProjects);
    } catch (err: any) {
      console.error("Error fetching projects:", err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [userProfile, permissions, loadingPermissions, ready]);

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  const canPerformAction = (action: 'create' | 'edit' | 'delete') => {
    if (!userProfile) return false;
    const role = userProfile.role;
    if (action === 'create' || action === 'edit') {
        return ['Team Lead', 'Project Manager', 'Director/VP/CXO', 'Super Admin'].includes(role);
    }
    if(action === 'delete') {
        return ['Director/VP/CXO', 'Super Admin'].includes(role);
    }
    return false;
  }

  const addProject = async (newProjectData: Omit<Project, 'id'>) => {
    if (!canPerformAction('create')) {
      throw new Error("You don't have permission to add projects.");
    }
    const projectsRef = collection(db, 'projects');
    const projectToSave: any = {
      ...newProjectData,
      status: 'Active',
      startDate: Timestamp.fromDate(newProjectData.startDate),
    };
    if (newProjectData.endDate) {
        projectToSave.endDate = Timestamp.fromDate(newProjectData.endDate);
    }
    await addDoc(projectsRef, projectToSave);
    await fetchProjects();
  };

  const updateProject = async (projectId: string, projectData: Partial<Project>) => {
     if (!canPerformAction('edit')) {
      throw new Error("You don't have permission to update projects.");
    }
    const projectRef = doc(db, 'projects', projectId);
    const dataToUpdate: any = { ...projectData };
    if (dataToUpdate.startDate) dataToUpdate.startDate = Timestamp.fromDate(new Date(dataToUpdate.startDate));
    if (dataToUpdate.endDate) dataToUpdate.endDate = Timestamp.fromDate(new Date(dataToUpdate.endDate));

    await updateDoc(projectRef, dataToUpdate as any);
    await fetchProjects();
  };
  
  const deleteProject = async (projectId: string) => {
     if (!canPerformAction('delete')) {
      throw new Error("You don't have permission to delete projects.");
    }
    const projectRef = doc(db, 'projects', projectId);
    await deleteDoc(projectRef);
    await fetchProjects();
  };

  return { projects, addProject, updateProject, deleteProject, loading, error, refetch: fetchProjects };
}
