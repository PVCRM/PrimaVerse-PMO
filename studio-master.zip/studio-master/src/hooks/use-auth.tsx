
"use client";

import React, { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { onAuthStateChanged, User, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc, collection, addDoc, query, where, getDocs, Timestamp, updateDoc, limit, writeBatch, onSnapshot, orderBy, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import type { UserProfile, UserRole, RoleElevationRequest, ProfileChangeRequest, UserStatus, RequestStatus, Permission, UserSession } from '@/lib/types';
import type { EmployeeFormOnSaveValues } from '@/components/add-employee-dialog';
import { deleteUserPermanently, addUser } from '@/ai/flows/user-management-flow';
import { roleHierarchy } from '@/data/master-data';
import { z } from 'zod';
import { startOfDay, isSameDay } from 'date-fns';

type PermissionsConfig = Record<UserRole, Permission>;

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signIn: (identifier: string, pass: string) => Promise<any>;
  signUp: (email: string, pass: string, firstName: string, lastName: string, department: string, designation: string) => Promise<{profile: UserProfile, isFirstUser: boolean}>;
  addEmployeeByHr: (formData: EmployeeFormOnSaveValues) => Promise<void>;
  signOutUser: () => Promise<void>;
  
  approveUser: (uid: string, role: UserRole) => Promise<void>;
  rejectUser: (uid: string) => Promise<void>;
  
  approveRoleRequest: (request: RoleElevationRequest) => Promise<void>;
  rejectRoleRequest: (requestId: string) => Promise<void>;

  approveProfileChange: (request: ProfileChangeRequest) => Promise<void>;
  rejectProfileChange: (requestId: string) => Promise<void>;
  
  requestRoleElevation: (requestedRole: UserRole) => Promise<void>;
  getRoleRequestStatus: () => Promise<RoleElevationRequest | null>;
  requestProfileChange: (requestedDepartment: string, requestedDesignation: string) => Promise<void>;
  getProfileChangeRequestStatus: () => Promise<ProfileChangeRequest | null>;

  updateUserProfile: (uid: string, data: Partial<Pick<UserProfile, 'name' | 'firstName' | 'lastName' | 'employeeId' | 'mobileCountryCode' | 'mobileNumber' | 'department' | 'designation' | 'role'>>) => Promise<void>;
  deactivateEmployee: (uid: string) => Promise<void>;
  deleteEmployee: (uid: string) => Promise<void>;
  reactivateUser: (uid: string) => Promise<void>;
  deleteUserRecord: (uid: string) => Promise<void>;
  bulkAddEmployees: (employees: EmployeeFormOnSaveValues[]) => Promise<{ successes: number; failures: { employee: EmployeeFormOnSaveValues; error: string }[] }>;
  
  hasPermission: (permissions: PermissionsConfig | null, module: keyof Permission, level: 'View' | 'CRUD') => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<{ id: string, data: UserSession } | null>(null);
  const activityTimerRef = React.useRef<NodeJS.Timeout | null>(null);
  
  const endSession = useCallback(async (sessionId: string, userId: string, loginTime: Timestamp) => {
    const sessionRef = doc(db, 'user-sessions', sessionId);
    const logoutTime = Timestamp.now();
    
    const today = startOfDay(loginTime.toDate());
    const sessionsQuery = query(
        collection(db, 'user-sessions'),
        where('userId', '==', userId),
        where('loginTime', '>=', today)
    );
    const snapshot = await getDocs(sessionsQuery);
    let totalActiveMillis = 0;
    snapshot.forEach(doc => {
        const data = doc.data();
        const start = data.loginTime.toMillis();
        const end = doc.id === sessionId ? logoutTime.toMillis() : (data.logoutTime?.toMillis() || start);
        totalActiveMillis += (end - start);
    });

    const availableHours = totalActiveMillis / (1000 * 60 * 60);
    
    await updateDoc(sessionRef, {
        logoutTime,
        status: 'ended',
        availableHours: Math.max(0, availableHours),
    });
    setSession(null);
  }, []);

  useEffect(() => {
    let unsubscribeUserDoc: (() => void) | null = null;
  
    const unsubscribeAuth = onAuthStateChanged(auth, async (authUser) => {
      // If there's an old user doc listener, unsubscribe from it
      if (unsubscribeUserDoc) {
        unsubscribeUserDoc();
        unsubscribeUserDoc = null;
      }
  
      if (authUser) {
        const userDocRef = doc(db, "users", authUser.uid);
  
        // Set up a new listener for the new user's document
        unsubscribeUserDoc = onSnapshot(userDocRef, async (snapshot) => {
          if (snapshot.exists()) {
            const profile = snapshot.data() as UserProfile;
            
            if (profile.status === 'active') {
              setUser(authUser);
              setUserProfile({ uid: authUser.uid, ...profile });
              setLoading(false);
            } else {
              // User exists but is not active, sign them out
              await signOut(auth);
              setUser(null);
              setUserProfile(null);
              setLoading(false);
            }
          } else {
            // User is authenticated but has no profile, sign them out
            await signOut(auth);
            setUser(null);
            setUserProfile(null);
            setLoading(false);
          }
        }, (error) => {
            console.error("Error listening to user document:", error);
            setUserProfile(null);
            setLoading(false);
        });
      } else {
        // No authenticated user
        setUser(null);
        setUserProfile(null);
        setLoading(false);
      }
    });
  
    // Cleanup function for the auth state listener
    return () => {
      unsubscribeAuth();
      if (unsubscribeUserDoc) {
        unsubscribeUserDoc();
      }
    };
  }, []);

  const signIn = async (identifier: string, pass: string) => {
    let email = identifier;
    const isEmail = z.string().email().safeParse(identifier).success;

    if (!isEmail) {
      try {
        const usersRef = collection(db, "users");
        const q = query(usersRef, where("employeeId", "==", identifier), limit(1));
        const querySnapshot = await getDocs(q);
        if (querySnapshot.empty) {
          throw new Error("No user found with that Employee ID.");
        }
        const userDoc = querySnapshot.docs[0].data();
        email = userDoc.email;
      } catch (error) {
        throw new Error("No user found with that Employee ID.");
      }
    }
      
    const userCredential = await signInWithEmailAndPassword(auth, email, pass);
    return userCredential;
  };

  const signUp = async (email: string, pass: string, firstName: string, lastName: string, department: string, designation: string): Promise<{ profile: UserProfile, isFirstUser: boolean }> => {
    throw new Error("Public sign-up is disabled.");
  };

  const addEmployeeByHr = async (formData: EmployeeFormOnSaveValues) => {
    const userRole = userProfile?.role;
    if (!userRole || !['Director/VP/CXO', 'Super Admin'].includes(userRole)) {
        throw new Error("You do not have permission to create new users.");
    }
    await addUser(formData);
  };

  const signOutUser = async () => {
    await signOut(auth);
  };
  
  const approveUser = async (uid: string, role: UserRole) => {
    const userDocRef = doc(db, 'users', uid);
    await updateDoc(userDocRef, {
      role: role,
      status: 'active' as UserStatus,
    });
  };

  const rejectUser = async (uid: string) => {
      const userDocRef = doc(db, 'users', uid);
      await updateDoc(userDocRef, {
          status: 'deactivated' as UserStatus,
      });
  }
  
  const approveRoleRequest = async (request: RoleElevationRequest) => {
      if (!request.id) throw new Error("Request ID is missing");
      const batch = writeBatch(db);
      
      const requestRef = doc(db, 'roleRequests', request.id);
      batch.update(requestRef, { status: 'approved' as RequestStatus });
      
      const userRef = doc(db, 'users', request.userId);
      batch.update(userRef, { role: request.requestedRole });
      
      await batch.commit();
  }

  const rejectRoleRequest = async (requestId: string) => {
      const requestRef = doc(db, 'roleRequests', requestId);
      await updateDoc(requestRef, { status: 'rejected' as RequestStatus });
  }

  const approveProfileChange = async (request: ProfileChangeRequest) => {
      if (!request.id) throw new Error("Request ID is missing");
      const batch = writeBatch(db);

      const requestRef = doc(db, 'profileChangeRequests', request.id);
      batch.update(requestRef, { status: 'approved' as RequestStatus });

      const userRef = doc(db, 'users', request.userId);
      batch.update(userRef, { 
          department: request.requestedDepartment,
          designation: request.requestedDesignation
      });

      await batch.commit();
  }

  const rejectProfileChange = async (requestId: string) => {
      const requestRef = doc(db, 'profileChangeRequests', requestId);
      await updateDoc(requestRef, { status: 'rejected' as RequestStatus });
  }

  const requestRoleElevation = async (requestedRole: UserRole) => {
    if (!user || !userProfile) {
      throw new Error("You must be logged in to make a request.");
    }
    
    const requestsRef = collection(db, 'roleRequests');
    const q = query(requestsRef, where('userId', '==', user.uid), where('status', '==', 'pending'));
    const snapshot = await getDocs(q);

    if (!snapshot.empty) {
      throw new Error("You already have a pending role elevation request.");
    }

    const newRequest: Omit<RoleElevationRequest, 'id'> = {
      userId: user.uid,
      userName: userProfile.name,
      userEmail: userProfile.email || '',
      currentRole: userProfile.role,
      requestedRole,
      status: 'pending',
      requestedAt: Timestamp.now(),
    };

    await addDoc(requestsRef, newRequest);
  };

  const getRoleRequestStatus = async (): Promise<RoleElevationRequest | null> => {
    if (!user) return null;
    
    const requestsRef = collection(db, 'roleRequests');
    const q = query(requestsRef, where('userId', '==', user.uid), where('status', '==', 'pending'));
    
    const snapshot = await getDocs(q);
    if (snapshot.empty) {
      return null;
    }
    
    const docData = snapshot.docs[0];
    return { id: docData.id, ...docData.data() } as RoleElevationRequest;
  };

  const requestProfileChange = async (requestedDepartment: string, requestedDesignation: string) => {
    if (!user || !userProfile) {
      throw new Error("You must be logged in to make a request.");
    }

    const requestsRef = collection(db, 'profileChangeRequests');
    const q = query(requestsRef, where('userId', '==', user.uid), where('status', '==', 'pending'));
    const snapshot = await getDocs(q);

    if (!snapshot.empty) {
      throw new Error("You already have a pending profile change request.");
    }

    const newRequest: Omit<ProfileChangeRequest, 'id'> = {
      userId: user.uid,
      userName: userProfile.name,
      userEmail: userProfile.email || '',
      currentDepartment: userProfile.department,
      requestedDepartment,
      currentDesignation: userProfile.designation,
      requestedDesignation: requestedDesignation,
      status: 'pending',
      requestedAt: Timestamp.now(),
    };

    await addDoc(requestsRef, newRequest);
  };

  const getProfileChangeRequestStatus = async (): Promise<ProfileChangeRequest | null> => {
    if (!user) return null;

    const requestsRef = collection(db, 'profileChangeRequests');
    const q = query(requestsRef, where('userId', '==', user.uid), where('status', '==', 'pending'));
    
    const snapshot = await getDocs(q);
    if (snapshot.empty) {
      return null;
    }

    const docData = snapshot.docs[0];
    return { id: docData.id, ...docData.data() } as ProfileChangeRequest;
  };
  
  const internalProfile = userProfile;
  const primaryRole = internalProfile?.role; 

  const updateUserProfile = async (uid: string, data: Partial<Pick<UserProfile, 'name' | 'firstName' | 'lastName' | 'employeeId' | 'mobileCountryCode' | 'mobileNumber' | 'department' | 'designation' | 'role'>>) => {
    if (!internalProfile || !primaryRole || !['Director/VP/CXO', 'Super Admin'].includes(primaryRole)) {
      throw new Error("You don't have permission to update user profiles.");
    }
    
    const usersRef = collection(db, "users");
    if (data.employeeId) {
        const q = query(usersRef, where("employeeId", "==", data.employeeId), limit(1));
        const snapshot = await getDocs(q);
        if (snapshot.docs.some(doc => doc.id !== uid)) {
              throw new Error(`Employee ID "${data.employeeId}" is already taken by another user.`);
        }
    }
    const userDocRef = doc(db, 'users', uid);
    await updateDoc(userDocRef, data);
  };
  
  const deactivateEmployee = async (uid: string) => {
    if (!internalProfile || !primaryRole || !['Director/VP/CXO', 'Super Admin'].includes(primaryRole)) {
      throw new Error("You don't have permission to deactivate users.");
    }
    const userDocRef = doc(db, 'users', uid);
    await updateDoc(userDocRef, { status: 'deactivated' });
  };
  
  const deleteEmployee = async (uid: string) => {
    if (!internalProfile || !primaryRole || !['Director/VP/CXO', 'Super Admin'].includes(primaryRole)) {
      throw new Error("You don't have permission to delete users.");
    }
    const userDocRef = doc(db, 'users', uid);
    await updateDoc(userDocRef, { status: 'deleted', deletedAt: Timestamp.now() });
  };
  
  const reactivateUser = async (uid: string) => {
    if (!internalProfile || !primaryRole || primaryRole !== 'Super Admin') {
      throw new Error("You don't have permission to reactivate users.");
    }
    const userDocRef = doc(db, 'users', uid);
    await updateDoc(userDocRef, { status: 'active', deletedAt: null });
  };
  
  const deleteUserRecord = async (uid: string) => {
    if (!internalProfile || !primaryRole || primaryRole !== 'Super Admin') {
      throw new Error("You don't have permission to permanently delete users.");
    }
    await deleteUserPermanently(uid);
  };
  
  const bulkAddEmployees = async (employees: EmployeeFormOnSaveValues[]): Promise<{ successes: number; failures: { employee: EmployeeFormOnSaveValues; error: string }[] }> => {
    if (!internalProfile || !primaryRole || !['Director/VP/CXO', 'Super Admin'].includes(primaryRole)) {
      throw new Error("You don't have permission for bulk imports.");
    }
    
    let successes = 0;
    const failures: { employee: EmployeeFormOnSaveValues; error: string }[] = [];
  
    for (const employee of employees) {
      try {
        await addEmployeeByHr(employee);
        successes++;
      } catch (error: any) {
        failures.push({ employee, error: error.message });
      }
    }
    
    return { successes, failures };
  };

  const hasPermission = (permissions: PermissionsConfig | null, module: keyof Permission, level: 'View' | 'CRUD'): boolean => {
    if (!internalProfile || !permissions) return false;
    
    const role = internalProfile.role;
    
    const hasAccess = (() => {
        const permission = permissions[role]?.[module];
        if (!permission || permission === 'Hide') return false;
        
        if (level === 'View') {
            return permission !== 'Hide';
        }
        if (level === 'CRUD') {
            return permission === 'CRUD' || permission === 'CRUD + Billing';
        }
        return false;
    })();

    return hasAccess;
  };

  const value: AuthContextType = {
    user,
    userProfile,
    loading,
    signIn,
    signUp,
    addEmployeeByHr,
    signOutUser,
    approveUser,
    rejectUser,
    approveRoleRequest,
    rejectRoleRequest,
    approveProfileChange,
    rejectProfileChange,
    requestRoleElevation,
    getRoleRequestStatus,
    requestProfileChange,
    getProfileChangeRequestStatus,
    updateUserProfile,
    deactivateEmployee,
    deleteEmployee,
    reactivateUser,
    deleteUserRecord,
    bulkAddEmployees,
    hasPermission,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
