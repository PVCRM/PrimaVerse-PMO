
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, where, onSnapshot, doc, getDoc, documentId } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { UserProfile, Project, Client } from '@/lib/types';
import { useAuth } from './use-auth';
import { roleHierarchy } from '@/data/master-data';
import { useProjects } from './use-projects';
import { useClients } from './use-clients';

export function useTeam() {
  const { userProfile } = useAuth();
  const [team, setTeam] = useState<UserProfile[]>([]);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchTeam = useCallback(async () => {
    if (!userProfile) {
        setLoading(false);
        return () => {};
    }

    setLoading(true);
    setError(null);

    const userLevel = roleHierarchy[userProfile.role];
    let q;

    try {
        if (userLevel >= roleHierarchy['Super Admin']) {
            q = query(collection(db, 'users'), where('status', '!=', 'deleted'));
        } else if (userLevel >= roleHierarchy['Director/VP/CXO']) {
            const userDepartments = Array.isArray(userProfile.department) ? userProfile.department : [userProfile.department];
            q = query(collection(db, 'users'), where('department', 'array-contains-any', userDepartments), where('status', '!=', 'deleted'));
        } else if (userLevel >= roleHierarchy['Team Lead']) {
            q = query(collection(db, 'users'), where('reviewerId', '==', userProfile.uid), where('status', '!=', 'deleted'));
        } else {
            // Employee view: just themselves.
            setTeam([userProfile]);
            setLoading(false);
            return () => {};
        }
            
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            let allUsers = querySnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
            if(userLevel === roleHierarchy['Team Lead']) {
                allUsers.push(userProfile);
            }
            allUsers.sort((a, b) => a.name.localeCompare(b.name));
            setTeam(allUsers);
            setLoading(false);
        }, (err) => {
            console.error("Error fetching team:", err);
            setError(err);
            setLoading(false);
        });

        return unsubscribe;

    } catch (err: any) {
        console.error("Error building team query:", err);
        setError(err);
        setLoading(false);
        return () => {};
    }
    
  }, [userProfile]);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    const executeFetch = async () => {
        try {
            const unsub = await fetchTeam();
            if (unsub) {
              unsubscribe = unsub;
            }
        } catch (err: any) {
            setError(err);
            setLoading(false);
        }
    };
    executeFetch();
    
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [fetchTeam]);
  
  const refetchTeam = () => {
     fetchTeam();
  };

  return { team, loading, error, refetch: refetchTeam };
}
