
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, Timestamp, where, or, writeBatch, doc, addDoc, updateDoc, deleteDoc, documentId } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Client, Project, UserProfile } from '@/lib/types';
import { useAuth } from './use-auth';
import { usePermissions } from './use-permissions';
import { roleHierarchy } from '@/data/master-data';

// Overload signatures
export function useClients(ready: boolean, allProjects?: Project[], scope?: 'self' | 'pm' | 'department' | 'all', scopeParams?: { userId?: string; departmentId?: string; }): { clients: Client[]; addClient: (newClientData: Omit<Client, "id" | "projectCount" | "employeeCount" | "status">) => Promise<{ id: string; name: string; code: string; logo: string; department: string; startDate: Date; coordinators: import("/usr/src/app/src/lib/types").ClientCoordinator[]; duLeadId: string; projectManagerId: string; teamLeadIds: string[]; teamMemberIds: string[]; salesPersonId: string; notes: string; tags: string[]; status: import("/usr/src/app/src/lib/types").ClientStatus; }>; updateClient: (clientId: string, clientData: Partial<Omit<Client, "id" | "projectCount" | "employeeCount">>) => Promise<void>; deleteClient: (clientId: string) => Promise<void>; bulkAddClients: (data: any[], team: UserProfile[]) => Promise<{ successes: number; failures: { item: any; error: string; }[]; }>; loading: boolean; error: Error | null; refetch: () => Promise<void>; };
export function useClients(ready: boolean, allProjects?: Project[], scope?: string, scopeParams?: any): any {
  const { userProfile } = useAuth();
  const { permissions, loading: loadingPermissions } = usePermissions();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchClients = useCallback(async () => {
    if (!ready || !userProfile || loadingPermissions) {
      if (!loadingPermissions) setLoading(false);
      return;
    }
    
    const userPermissions = permissions[userProfile.role];
    if (!userPermissions || userPermissions.clients === 'Hide') {
      setClients([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const clientsCollection = collection(db, 'clients');
      let q;
      
      const userLevel = roleHierarchy[userProfile.role];
      const userDepartments = Array.isArray(userProfile.department) ? userProfile.department : [userProfile.department];

      if (userLevel >= roleHierarchy['Super Admin']) {
           q = query(clientsCollection, orderBy('name', 'asc'));
      } else if (userLevel >= roleHierarchy['Director/VP/CXO']) {
        q = query(clientsCollection, where('department', 'in', userDepartments), orderBy('name', 'asc'));
      } else if (userLevel >= roleHierarchy['Team Lead']) {
        q = query(clientsCollection, 
            or(
                where('projectManagerId', '==', userProfile.uid),
                where('teamLeadIds', 'array-contains', userProfile.uid),
                where('duLeadId', '==', userProfile.uid)
            )
        );
      } else { // Employee
        const clientIdsFromProjects = [...new Set(allProjects?.map(p => p.clientId) || [])];
        if (clientIdsFromProjects.length > 0) {
          q = query(clientsCollection, where(documentId(), 'in', clientIdsFromProjects.slice(0, 30)));
        } else {
          q = null; 
        }
      }
      
      let fetchedClients: Client[] = [];
      if (q) {
        const querySnapshot = await getDocs(q);
        const projectCounts = new Map<string, number>();
        const employeeCounts = new Map<string, Set<string>>();

        if (allProjects) {
          allProjects.forEach(project => {
              if (project.status === 'Active') {
                projectCounts.set(project.clientId, (projectCounts.get(project.clientId) || 0) + 1);
              }
              if (project.teamIds) {
                  if (!employeeCounts.has(project.clientId)) {
                      employeeCounts.set(project.clientId, new Set());
                  }
                  project.teamIds.forEach(id => employeeCounts.get(project.clientId)!.add(id));
              }
          });
        }

        fetchedClients = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            status: doc.data().status || 'Active', 
            startDate: (doc.data().startDate as any as Timestamp).toDate(),
            projectCount: projectCounts.get(doc.id) || 0,
            employeeCount: employeeCounts.get(doc.id)?.size || 0,
        }) as Client);
      
        if (userLevel >= roleHierarchy['Team Lead'] && userLevel < roleHierarchy['Director/VP/CXO']) {
          fetchedClients.sort((a, b) => a.name.localeCompare(b.name));
        }
      }
      
      setClients(fetchedClients);
    } catch (err: any) {
      console.error("Error fetching clients:", err);
      if (err.code === 'failed-precondition' || err.code === 'invalid-argument') {
          setError(new Error("A database index is required for this query. Please check the Firebase console."));
      } else {
          setError(err);
      }
    } finally {
      setLoading(false);
    }
  }, [userProfile, permissions, loadingPermissions, ready, allProjects]);

  useEffect(() => {
    fetchClients();
  }, [fetchClients]);
  
  const canPerformAction = (level: 'view' | 'edit' | 'delete') => {
    if (!userProfile) return false;
    const role = userProfile.role;
    switch(level) {
        case 'view':
            return true;
        case 'edit':
            return ['Project Manager', 'Director/VP/CXO', 'Super Admin'].includes(role);
        case 'delete':
            return ['Director/VP/CXO', 'Super Admin'].includes(role);
        default:
            return false;
    }
  }

  const addClient = async (newClientData: Omit<Client, 'id' | 'projectCount' | 'employeeCount' | 'status'>) => {
    if (!canPerformAction('edit')) { 
        throw new Error("You don't have permission to add clients.");
    }
    const clientsRef = collection(db, 'clients');
    
    const clientToSave = {
        ...newClientData,
        status: 'Active',
        startDate: Timestamp.fromDate(newClientData.startDate)
    };
    
    const docRef = await addDoc(clientsRef, clientToSave);
    await fetchClients();
    return { ...newClientData, id: docRef.id };
  };

  const updateClient = async (clientId: string, clientData: Partial<Omit<Client, 'id' | 'projectCount' | 'employeeCount'>>) => {
     if (!canPerformAction('edit')) {
        throw new Error("You don't have permission to update clients.");
    }
    const clientRef = doc(db, 'clients', clientId);

    const clientToSave = {
      ...clientData,
    };
    if (clientData.startDate) {
        (clientToSave as any).startDate = Timestamp.fromDate(clientData.startDate);
    }

    await updateDoc(clientRef, clientToSave as any);
    await fetchClients();
  };

  const deleteClient = async (clientId: string) => {
    if (!canPerformAction('delete')) {
        throw new Error("You don't have permission to delete clients.");
    }
    
    const clientRef = doc(db, 'clients', clientId);
    await deleteDoc(clientRef);
    await fetchClients();
  }

  const bulkAddClients = async (data: any[], team: UserProfile[]) => {
    if (!canPerformAction('edit')) {
      throw new Error("You don't have permission to import clients.");
    }
    let successes = 0;
    const failures: { item: any; error: string }[] = [];
    const batch = writeBatch(db);
    const clientsCollection = collection(db, "clients");
    const emailToUidMap = new Map(team.map(member => [member.email, member.uid]));

    for (const item of data) {
      try {
        const duLeadId = emailToUidMap.get(item.DULeadEmail) || '';
        const projectManagerId = emailToUidMap.get(item.ProjectManagerEmail) || '';
        const salesPersonId = emailToUidMap.get(item.SalesPersonEmail) || '';
        const teamLeadIds = item.TeamLeadEmails.split(',').map((e: string) => emailToUidMap.get(e.trim()) || '').filter(Boolean);

        if (!duLeadId || !projectManagerId || !salesPersonId) {
            failures.push({ item, error: "Required team member email not found or invalid." });
            continue;
        }

        const newClient = {
          name: item.ClientName,
          code: item.ClientCode,
          department: item.Department,
          startDate: Timestamp.fromDate(new Date(item.StartDate)),
          duLeadId,
          projectManagerId,
          salesPersonId,
          teamLeadIds,
          teamMemberIds: [], 
          status: 'Active',
          logo: 'https://placehold.co/40x40.png',
          notes: item.Notes || '',
          tags: (item.Tags || '').split(',').map((t:string) => t.trim()).filter(Boolean),
          coordinators: [{
            id: `coord-${Date.now()}`,
            firstName: item.CoordinatorFirstName,
            lastName: item.CoordinatorLastName,
            email: item.CoordinatorEmail,
            officePhoneCountryCode: item.OfficePhoneCountryCode || '1',
            officePhoneNumber: item.OfficePhoneNumber || '',
            officePhoneExt: item.OfficePhoneExt || '',
            mobilePhoneCountryCode: item.MobilePhoneCountryCode || '1',
            mobilePhoneNumber: item.MobilePhoneNumber || '',
            streetAddress: item.StreetAddress || '',
            country: item.Country || '',
            state: item.State || '',
            city: item.City || '',
            zipcode: item.Zipcode || '',
          }],
        };
        const docRef = doc(clientsCollection);
        batch.set(docRef, newClient);
        successes++;
      } catch (e: any) {
        failures.push({ item, error: e.message || "An unknown error occurred." });
      }
    }
    
    await batch.commit();
    if (successes > 0) await fetchClients();
    return { successes, failures };
  };

  return { clients, addClient, updateClient, deleteClient, bulkAddClients, loading, error, refetch: fetchClients };
}
