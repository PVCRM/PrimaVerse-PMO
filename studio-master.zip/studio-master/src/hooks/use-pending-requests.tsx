
"use client";

import { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from './use-auth';
import type { UserProfile, RoleElevationRequest, ProfileChangeRequest } from '@/lib/types';

export function usePendingRequests() {
    const { userProfile } = useAuth();
    const [pendingUsers, setPendingUsers] = useState<UserProfile[]>([]);
    const [deactivatedUsers, setDeactivatedUsers] = useState<UserProfile[]>([]);
    const [deletedUsers, setDeletedUsers] = useState<UserProfile[]>([]);
    const [roleRequests, setRoleRequests] = useState<RoleElevationRequest[]>([]);
    const [profileChangeRequests, setProfileChangeRequests] = useState<ProfileChangeRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
        if (!userProfile || userProfile.role !== 'Super Admin') {
            setLoading(false);
            return;
        }

        const queries = [
            { ref: collection(db, 'users'), setter: setPendingUsers, statusValue: 'pending_approval' },
            { ref: collection(db, 'users'), setter: setDeactivatedUsers, statusValue: 'deactivated' },
            { ref: collection(db, 'users'), setter: setDeletedUsers, statusValue: 'deleted' },
            { ref: collection(db, 'roleRequests'), setter: setRoleRequests, statusValue: 'pending' },
            { ref: collection(db, 'profileChangeRequests'), setter: setProfileChangeRequests, statusValue: 'pending' }
        ];

        const unsubscribes = queries.map(({ ref, setter, statusValue }) => {
            const q = query(ref, where('status', '==', statusValue));
            
            return onSnapshot(q, (snapshot) => {
                const data = snapshot.docs.map(doc => {
                    const docData = doc.data();
                    const item: any = { id: doc.id, ...docData };

                    // Convert Timestamps
                    if (item.requestedAt && item.requestedAt instanceof Timestamp) {
                        item.requestedAt = item.requestedAt.toDate();
                    }
                    if (item.createdAt && item.createdAt instanceof Timestamp) {
                        item.createdAt = item.createdAt.toDate();
                    }
                     if (item.deletedAt && item.deletedAt instanceof Timestamp) {
                        item.deletedAt = item.deletedAt.toDate();
                    }
                    
                    return item;
                });
                setter(data as any);
            }, (err) => {
                console.error(`Error fetching pending items:`, err);
                setError(err);
            });
        });

        setLoading(false);

        // Cleanup function
        return () => {
            unsubscribes.forEach(unsub => {
                if (unsub) unsub();
            });
        };

    }, [userProfile]);

    return { pendingUsers, deactivatedUsers, deletedUsers, roleRequests, profileChangeRequests, loading, error };
}
