
import { Timestamp } from 'firebase/firestore';

export type UserRole = 'Employee' | 'Team Lead' | 'Project Manager' | 'Director/VP/CXO' | 'Super Admin';
export type UserStatus = 'pending_approval' | 'active' | 'deactivated' | 'deleted';
export type RequestStatus = 'pending' | 'approved' | 'rejected';
export type ClientStatus = 'Active' | 'Inactive';
export type ProjectStatus = 'Active' | 'Inactive';
export type Priority = 'P1' | 'P2' | 'P3' | 'P4' | 'P5';
export type View = 'dashboard' | 'clients' | 'projects' | 'tasks' | 'team' | 'reports' | 'settings' | 'approvals' | 'master-data' | 'permissions' | 'timesheet' | 'reviews-approvals' | 'critical-tasks' | 'resource-utility' | 'daily-log' | 'all-tasks';


export type PermissionLevel = 'Hide' | 'View Only' | 'CRUD' | 'CRUD + Billing' | 'Mark Complete';

export interface Permission {
  dashboard: PermissionLevel;
  clients: PermissionLevel;
  projects: PermissionLevel;
  tasks: PermissionLevel;
  team: PermissionLevel;
  reports: PermissionLevel;
}

export interface Department { 
  id: string; 
  name: string; 
}

export interface Designation { 
  id: string; 
  name: string; 
  departmentId: string;
}

export interface ProjectType { 
  id: string; 
  name: string; 
  departmentId: string;
}

export interface TaskType {
  id: string;
  name: string;
  projectTypeId: string;
}

export interface ClientCoordinator {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  officePhoneCountryCode: string;
  officePhoneNumber: string;
  officePhoneExt: string;
  mobilePhoneCountryCode: string;
  mobilePhoneNumber: string;
  streetAddress: string;
  country: string;
  state: string;
  city: string;
  zipcode: string;
}

export interface Client {
  id: string;
  name: string;
  code: string;
  logo: string;
  department: string;
  startDate: Date;
  coordinators: ClientCoordinator[];
  duLeadId: string;
  projectManagerId: string;
  teamLeadIds: string[];
  teamMemberIds: string[];
  salesPersonId: string;
  notes: string;
  tags: string[];
  status: ClientStatus;
  projectCount?: number;
  employeeCount?: number;
}


export interface Project {
  id: string;
  name: string;
  clientId: string;
  clientName?: string;
  department: string;
  projectTypeId: string;
  projectTypeName?: string;
  projectManagerId: string;
  teamLeadIds: string[];
  teamMemberIds: string[];
  teamIds?: string[];
  startDate: Date;
  endDate?: Date;
  status: ProjectStatus;
  estimatedHours: number;
}

export interface Review {
    comment: string;
    mistakes: number;
    repeatedMistakes: number;
    reviewedAt: Timestamp;
}

export interface Task {
  id: string;
  clientId: string;
  title: string;
  description: string;
  status: "completed" | "in-progress" | "overdue" | "todo" | "pending_review";
  priority: Priority;
  projectId: string;
  projectName?: string;
  taskTypeId: string;
  taskTypeName?: string;
  assigneeId: string;
  reviewerId: string;
  startDate: Date;
  dueDate: Date;
  estimatedHours: number;
  startedAt?: Date;
  actualHours?: number;
  totalHours?: number;
  completedAt?: Date;
  reviewComments?: string; // Legacy field, will be deprecated
  mistakeCount?: number;
  repeatedMistakeCount?: number;
  reviewLog?: Review[];
  erroneousHours?: number;
  efficiency?: number;
  activeSince?: Timestamp | null;
}

export interface UserProfile {
  uid: string;
  employeeId: string;
  email: string | null;
  name: string;
  firstName: string;
  lastName: string;
  mobileCountryCode?: string;
  mobileNumber?: string;
  role: UserRole;
  status: UserStatus;
  department: string[];
  designation: string;
  createdAt?: Timestamp;
  deletedAt?: Timestamp;
  reviewerId?: string; // ID of the user's primary reviewer (TL or PM)
}


export interface RoleElevationRequest {
  id?: string;
  userId: string;
  userName: string;
  userEmail: string;
  currentRole: UserRole;
  requestedRole: UserRole;
  status: RequestStatus;
  requestedAt: Date;
}

export interface ProfileChangeRequest {
    id?: string;
    userId: string;
    userName: string;
    userEmail: string;
    currentDepartment: string[];
    requestedDepartment: string;
    currentDesignation: string;
    requestedDesignation: string;
    status: RequestStatus;
    requestedAt: Date;
}

export interface TimesheetEntry {
    id: string;
    userId: string;
    date: Date;
    type: 'task' | 'productive-work' | 'recreational' | 'non-productive' | 'review';
    taskId?: string;
    projectId?: string;
    taskName?: string;
    projectName?: string;
    description: string; // e.g., 'Learning', 'Peer Reviewing' for productive-work
    hours: number;
    isApproved?: boolean;
    isSubmitted?: boolean;
    needsRevision?: boolean;
}

export interface UserSession {
    id: string;
    userId: string;
    loginTime: Timestamp;
    logoutTime?: Timestamp;
    lastActive: Timestamp;
    status: 'active' | 'ended';
    availableHours?: number;
}
