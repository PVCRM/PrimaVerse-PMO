
import admin from 'firebase-admin';

const ADMIN_APP_NAME = 'firebase-admin-app-perspective-pmo-singleton';

/**
 * Gets the singleton Firebase Admin app instance.
 * Initializes the app if it's not already created.
 * This is the robust way to handle initialization in a Next.js environment.
 */
function getAdminApp() {
    // Check if the app is already initialized
    if (admin.apps.some(app => app?.name === ADMIN_APP_NAME)) {
        return admin.app(ADMIN_APP_NAME);
    }

    // If not initialized, create a new app instance
    const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');

    if (!process.env.FIREBASE_PROJECT_ID || !process.env.FIREBASE_CLIENT_EMAIL || !privateKey) {
        console.error("Firebase Admin initialization failed. One or more environment variables (FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY) are missing.");
        throw new Error("Firebase Admin SDK: Missing environment variables for initialization.");
    }
    
    try {
        return admin.initializeApp({
            credential: admin.credential.cert({
                projectId: process.env.FIREBASE_PROJECT_ID,
                clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
                privateKey: privateKey,
            }),
        }, ADMIN_APP_NAME);
    } catch (error: any) {
        if (error.code === 'auth/invalid-credential') {
            console.error('Firebase Admin initialization failed: The service account credentials are not valid. Please check your .env file.');
        } else {
             console.error('Firebase Admin initialization failed with an unexpected error:', error);
        }
        throw new Error(`Firebase Admin initialization failed: ${error.message}`);
    }
}


export function getAuth() {
    return getAdminApp().auth();
}

export function getFirestore() {
    return getAdminApp().firestore();
}
