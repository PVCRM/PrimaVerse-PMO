
import { getAuth, getFirestore } from '@/lib/firebase-admin';
import { Timestamp } from 'firebase-admin/firestore';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const input = await req.json();
    const auth = getAuth();
    const firestore = getFirestore();

    // Check if user already exists
    try {
      await auth.getUserByEmail(input.email);
      return NextResponse.json({ error: 'User already exists' }, { status: 400 });
    } catch (err: any) {
      if (err.code !== 'auth/user-not-found') {
        return NextResponse.json({ error: err.message }, { status: 500 });
      }
    }

    // Create user in Firebase Auth
    const user = await auth.createUser({
      email: input.email,
      password: input.password,
      displayName: `${input.firstName} ${input.lastName}`.trim(),
    });

    // Create Firestore document
    const userDocRef = firestore.collection('users').doc(user.uid);
    const userProfile = {
      uid: user.uid,
      employeeId: input.employeeId,
      email: input.email,
      name: `${input.firstName} ${input.lastName}`.trim(),
      firstName: input.firstName,
      lastName: input.lastName,
      mobileCountryCode: input.mobileCountryCode,
      mobileNumber: input.mobileNumber,
      role: input.role,
      status: 'pending_approval',
      department: input.department,
      designation: input.designation,
      createdAt: Timestamp.now(),
    };

    await userDocRef.set(userProfile);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('[API ERROR]', error);
    return NextResponse.json({ error: error.message || 'Something went wrong' }, { status: 500 });
  }
}
