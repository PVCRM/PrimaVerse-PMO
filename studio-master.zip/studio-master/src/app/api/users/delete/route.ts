import { getAuth, getFirestore } from '@/lib/firebase-admin';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { uid } = await req.json();
    if (!uid) {
        return NextResponse.json({ error: 'User UID is required' }, { status: 400 });
    }

    const auth = getAuth();
    const firestore = getFirestore();

    // Auth deletion is the most critical part.
    try {
        await auth.deleteUser(uid);
    } catch (error: any) {
        // If user not found in Auth, it's not a fatal error for this flow.
        // We still want to try deleting from Firestore.
        if (error.code !== 'auth/user-not-found') {
            console.error(`Failed to delete user ${uid} from Firebase Auth:`, error);
            throw new Error(`Failed to delete user from Authentication: ${error.message}`);
        }
    }

    // Now, delete from Firestore.
    const userDocRef = firestore.collection('users').doc(uid);
    await userDocRef.delete();
    
    return NextResponse.json({ success: true, message: `User ${uid} deleted successfully.` });

  } catch (error: any) {
    console.error('[API DELETE USER ERROR]', error);
    return NextResponse.json({ error: error.message || 'Something went wrong' }, { status: 500 });
  }
}
