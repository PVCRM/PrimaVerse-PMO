
"use client"

import React from 'react';
import { AuthGuard } from '@/components/auth-guard';
import { MasterDataProvider } from '@/context/master-data-context';
import { SidebarProvider } from '@/components/ui/sidebar';
import { Sidebar, SidebarHeader, SidebarContent, SidebarFooter } from '@/components/ui/sidebar';
import AppNavigation from './AppNavigation';
import UserMenu from './UserMenu';
import { useDashboard, DashboardProvider } from '@/context/dashboard-context';

function DashboardLayoutContent({ children }: { children: React.ReactNode }) {
  const { setActiveView, activeView } = useDashboard();
  return (
    <AuthGuard>
        <SidebarProvider>
             <div className="relative flex min-h-screen w-full bg-background group/sidebar-wrapper">
                  <Sidebar>
                    <SidebarHeader>
                        <div className="p-2">
                            <h1 className="text-lg font-semibold text-foreground">Perspective PMO</h1>
                            <p className="text-xs text-muted-foreground">by PVD</p>
                        </div>
                    </SidebarHeader>
                    <SidebarContent>
                      <AppNavigation activeView={activeView} setActiveView={setActiveView} />
                    </SidebarContent>
                    <SidebarFooter>
                      <UserMenu setActiveView={setActiveView} />
                    </SidebarFooter>
                  </Sidebar>
                  <main className="flex flex-col flex-grow transition-all duration-300 ease-in-out group-data-[state=expanded]/sidebar-wrapper:ml-64 group-data-[state=collapsed]/sidebar-wrapper:ml-20">
                    {children}
                  </main>
              </div>
        </SidebarProvider>
    </AuthGuard>
  );
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    // Wrap the entire layout with MasterDataProvider and DashboardProvider
    <MasterDataProvider>
        <DashboardProvider>
            <DashboardLayoutContent>{children}</DashboardLayoutContent>
        </DashboardProvider>
    </MasterDataProvider>
  )
}

    