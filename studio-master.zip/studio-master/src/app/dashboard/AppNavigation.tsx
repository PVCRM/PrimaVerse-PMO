
"use client"

import React from 'react';
import type { View } from '@/lib/types'; // Using a simplified View type
import { useAuth } from '@/hooks/use-auth';
import { usePermissions } from '@/hooks/use-permissions';
import { SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarMenuBadge } from '@/components/ui/sidebar';
import { Home, ClipboardList, Briefcase, Users, BarChart3, Settings, CalendarClock, GanttChartSquare, ClipboardCheck, LayoutList } from 'lucide-react';
import type { Permission } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { roleHierarchy } from '@/data/master-data';

interface AppNavigationProps {
    activeView: View;
    setActiveView: (view: View) => void;
}

interface NavItem {
  view: View;
  label: string;
  icon: React.ElementType;
  permissionKey?: keyof Permission;
  permissionLevel?: 'View Only' | 'CRUD' | 'CRUD + Billing' | 'Mark Complete';
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { view: 'dashboard', label: 'Dashboard', icon: Home },
  { view: 'tasks', label: 'My Tasks', icon: ClipboardList, permissionKey: 'tasks' },
  { view: 'timesheet', label: 'My Timesheet', icon: CalendarClock },
  { view: 'reviews-approvals', label: 'My Approvals', icon: ClipboardCheck },
  { view: 'clients', label: 'Clients', icon: Briefcase, permissionKey: 'clients', permissionLevel: 'View Only' },
  { view: 'projects', label: 'Projects', icon: GanttChartSquare, permissionKey: 'projects', permissionLevel: 'View Only' },
  { view: 'all-tasks', label: 'All Tasks', icon: LayoutList, permissionKey: 'tasks' },
  { view: 'team', label: 'Team', icon: Users, permissionKey: 'team', permissionLevel: 'View Only' },
  { view: 'reports', label: 'Reports', icon: BarChart3, permissionKey: 'reports', permissionLevel: 'View Only' },
];

export default function AppNavigation({ activeView, setActiveView }: AppNavigationProps) {
  const { userProfile, loading: authLoading } = useAuth();
  const { permissions, loading: permissionsLoading } = usePermissions();

  if (authLoading || permissionsLoading || !userProfile || !permissions[userProfile.role]) {
    return (
      <div className="space-y-2 p-2">
        {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex items-center gap-2 p-2">
                <Skeleton className="h-6 w-6 rounded" />
                <Skeleton className="h-4 w-24" />
            </div>
        ))}
      </div>
    );
  }

  const isSuperAdmin = userProfile.role === 'Super Admin';
  const userPermissions = permissions[userProfile.role];
  const userLevel = roleHierarchy[userProfile.role];

  const hasAccess = (item: NavItem) => {
    if (isSuperAdmin) return true;
    if (item.adminOnly) return false;

    // Show "Clients" only to Director+.
    if (item.view === 'clients' && userLevel < roleHierarchy['Director/VP/CXO']) {
        return false;
    }
    
    // Hide views for employees
    if (userLevel === 0) {
        if (item.view === 'all-tasks' || item.view === 'reviews-approvals') {
            return false;
        }
    }

    // Special case for 'all-tasks' view
    if (item.view === 'all-tasks') {
        return ['Team Lead', 'Project Manager', 'Director/VP/CXO'].includes(userProfile.role);
    }
    
    // Hide Reports for TLs and PMs
    if (['reports'].includes(item.view) && ['Team Lead', 'Project Manager'].includes(userProfile.role)) {
      return false;
    }
    
    if (!item.permissionKey) return true;
    
    const requiredPermission = item.permissionLevel || 'View Only';
    const currentPermission = userPermissions[item.permissionKey];

    if (currentPermission === 'Hide') return false;

    // If the item is 'My Tasks', we just need to ensure the permission is not 'Hide'.
    if (item.view === 'tasks') {
        return currentPermission !== 'Hide';
    }

    if (requiredPermission === 'View Only') {
        return ['View Only', 'CRUD', 'CRUD + Billing'].includes(currentPermission);
    }
    if (requiredPermission === 'CRUD') {
        return ['CRUD', 'CRUD + Billing'].includes(currentPermission);
    }
    
    return currentPermission === requiredPermission;
  };

  return (
    <SidebarMenu>
      {navItems.filter(hasAccess).map((item) => (
        <SidebarMenuItem key={item.view}>
          <SidebarMenuButton
            isActive={activeView === item.view}
            onClick={() => setActiveView(item.view)}
            tooltip={item.label}
          >
            <item.icon />
            <span>{item.label}</span>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );
}
