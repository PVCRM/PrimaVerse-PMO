
"use client"

import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import type { View } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { ChevronUp, LogOut, Settings, Database, SlidersHorizontal, ShieldCheck } from 'lucide-react';
import { useSidebar } from '@/components/ui/sidebar';

// The setActiveView function now needs to be passed down from the page
interface UserMenuProps {
    setActiveView: (view: View) => void;
}

export default function UserMenu({ setActiveView }: UserMenuProps) {
  const { userProfile, signOutUser } = useAuth();
  const { state } = useSidebar();

  const getInitials = (name: string) => {
    return name ? name.split(' ').map(n => n[0]).join('').toUpperCase() : 'U';
  };
  
  if (!userProfile) {
    return null;
  }
  
  const userName = userProfile.name || "User";
  const userRole = userProfile.role || "User";
  const isSuperAdmin = userProfile.role === 'Super Admin';
 
  const adminMenuItems = [
    { view: 'approvals', label: 'Admin Approvals', icon: ShieldCheck, adminOnly: true },
    { view: 'master-data', label: 'Master Data', icon: Database, adminOnly: true },
    { view: 'permissions', label: 'Permissions', icon: SlidersHorizontal, adminOnly: true },
  ];

  if (state === 'collapsed') {
    return (
       <DropdownMenu>
        <DropdownMenuTrigger asChild>
           <Avatar className="h-10 w-10 cursor-pointer border-2 border-transparent hover:border-primary transition-colors">
              <AvatarImage src={`https://placehold.co/40x40/A093E2/FFFFFF.png?text=${getInitials(userName)}`} alt={userName} data-ai-hint="person avatar"/>
              <AvatarFallback>{getInitials(userName)}</AvatarFallback>
            </Avatar>
        </DropdownMenuTrigger>
        <DropdownMenuContent side="right" align="start" className="mb-2">
            <DropdownMenuLabel>{userName}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setActiveView('settings')}>
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
             {isSuperAdmin && <DropdownMenuSeparator />}
            {isSuperAdmin && adminMenuItems.map(item => (
                <DropdownMenuItem key={item.view} onClick={() => setActiveView(item.view as View)}>
                    <item.icon className="mr-2 h-4 w-4" />
                    <span>{item.label}</span>
                </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={signOutUser}>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="w-full justify-start items-center text-left h-auto p-2">
            <div className="flex items-center gap-3">
                 <Avatar className="h-10 w-10">
                    <AvatarImage src={`https://placehold.co/40x40/A093E2/FFFFFF.png?text=${getInitials(userName)}`} alt={userName} data-ai-hint="person avatar"/>
                    <AvatarFallback>{getInitials(userName)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 truncate">
                    <p className="font-semibold text-sm truncate">{userName}</p>
                    <p className="text-xs text-muted-foreground truncate">{userRole}</p>
                </div>
            </div>
             <ChevronUp className="h-4 w-4 text-muted-foreground ml-auto" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent side="top" align="start" className="w-[var(--radix-dropdown-menu-trigger-width)] mb-2">
        <DropdownMenuItem onClick={() => setActiveView('settings')}>
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
        </DropdownMenuItem>
        {isSuperAdmin && <DropdownMenuSeparator />}
        {isSuperAdmin && adminMenuItems.map(item => (
            <DropdownMenuItem key={item.view} onClick={() => setActiveView(item.view as View)}>
                <item.icon className="mr-2 h-4 w-4" />
                <span>{item.label}</span>
            </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={signOutUser}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
