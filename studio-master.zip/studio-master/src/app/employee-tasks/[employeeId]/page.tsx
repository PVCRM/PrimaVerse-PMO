
"use client"

import { useState, useMemo, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTasks } from '@/hooks/use-tasks';
import { useTeam } from '@/hooks/use-team';
import { useAuth } from '@/hooks/use-auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ListTodo } from 'lucide-react';
import type { Task, Priority } from '@/lib/types';
import { format } from 'date-fns';
import { AuthGuard } from '@/components/auth-guard';
import { cn } from '@/lib/utils';
import { AnimatedGradientBackground } from '@/components/animated-gradient-background';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const priorityColors: Record<Priority, string> = {
    P1: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    P2: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
    P3: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    P4: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    P5: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200",
};

const statusColors: Record<Task['status'], string> = {
    "todo": "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200",
    "in-progress": "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    "overdue": "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    "pending_review": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    "completed": "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
};


function EmployeeTasksPageContent() {
    const params = useParams();
    const router = useRouter();
    const { employeeId } = params;

    const { userProfile, loading: loadingAuth } = useAuth();
    const { team, loading: loadingTeam } = useTeam();
    const { tasks, loading: loadingTasks } = useTasks();

    const employee = useMemo(() => {
        if (!employeeId || loadingTeam) return null;
        return team.find(member => member.uid === employeeId);
    }, [employeeId, team, loadingTeam]);

    const employeeTasks = useMemo(() => {
        if (!employeeId || loadingTasks) return [];
        return tasks.filter(task => task.assigneeId === employeeId);
    }, [employeeId, tasks, loadingTasks]);
    
    const isLoading = loadingAuth || loadingTeam || loadingTasks;

    const getInitials = (name: string = '') => {
        return name ? name.split(' ').map(n => n[0]).join('').toUpperCase() : '';
    }
    
    const getReviewerName = (reviewerId: string) => {
        return team.find(member => member.uid === reviewerId)?.name || 'N/A';
    }

    if (isLoading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="ai-spinner"></div>
            </div>
        );
    }
    
    if (!employee) {
        return (
            <div className="flex h-screen items-center justify-center">
                <Card>
                    <CardHeader>
                        <CardTitle>Employee Not Found</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>The requested employee could not be found.</p>
                        <Button onClick={() => router.back()} className="mt-4">Go Back</Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="relative flex min-h-screen flex-col">
            <AnimatedGradientBackground />
            <div className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6">
                <div className="flex items-center gap-4">
                    <Button variant="outline" size="icon" onClick={() => router.back()}>
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <Avatar className="h-16 w-16 border-2 border-primary">
                        <AvatarImage src={`https://placehold.co/64x64/A093E2/FFFFFF.png?text=${getInitials(employee.name)}`} alt={employee.name} data-ai-hint="person avatar"/>
                        <AvatarFallback>{getInitials(employee.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <h1 className="text-2xl font-bold">{employee.name}</h1>
                        <p className="text-muted-foreground">{employee.designation}</p>
                    </div>
                    <Badge variant="outline" className="ml-auto">{employeeTasks.length} Total Tasks</Badge>
                </div>
                
                {employeeTasks.length > 0 ? (
                    <Card>
                        <CardContent className="p-0">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Task</TableHead>
                                        <TableHead>Project</TableHead>
                                        <TableHead>Reviewer</TableHead>
                                        <TableHead>Allotted Hrs</TableHead>
                                        <TableHead>Start Date</TableHead>
                                        <TableHead>End Date</TableHead>
                                        <TableHead>Status</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {employeeTasks.map((task) => (
                                       <TableRow key={task.id}>
                                           <TableCell className="font-medium">{task.title}</TableCell>
                                           <TableCell>{task.projectName}</TableCell>
                                           <TableCell>{getReviewerName(task.reviewerId)}</TableCell>
                                           <TableCell>{task.estimatedHours}</TableCell>
                                           <TableCell>{format(task.startDate, 'PPP')}</TableCell>
                                           <TableCell>{format(task.dueDate, 'PPP')}</TableCell>
                                           <TableCell>
                                                <Badge className={cn("capitalize", statusColors[task.status])}>
                                                    {task.status.replace('_', ' ')}
                                                </Badge>
                                           </TableCell>
                                       </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                ) : (
                    <Card className="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed shadow-none">
                         <ListTodo className="h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="text-xl font-semibold tracking-tight">No Tasks Found</h3>
                        <p className="text-muted-foreground mt-2 max-w-sm">This employee has no tasks assigned.</p>
                    </Card>
                )}
            </div>
        </div>
    );
}

export default function EmployeeTasksPage() {
    return (
        <AuthGuard>
            <EmployeeTasksPageContent />
        </AuthGuard>
    )
}
