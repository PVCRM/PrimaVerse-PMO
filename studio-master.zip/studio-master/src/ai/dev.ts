
import { config } from 'dotenv';
config();

import '@/ai/flows/smart-recommendations.ts';
import '@/ai/flows/generate-tags-flow.ts';
import '@/ai/flows/task-health-flow.ts';
import '@/ai/flows/user-management-flow.ts';
import '@/ai/flows/sort-tasks-flow.ts';
