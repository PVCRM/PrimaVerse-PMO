
'use server';

/**
 * @fileOverview An AI flow to analyze project data and determine a health score.
 *
 * - getProjectHealth - A function that analyzes project and task data to return a health score and summary.
 * - ProjectHealthInput - The input type for the getProjectHealth function.
 * - ProjectHealthOutput - The return type for the getProjectHealth function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { Project, Task } from '@/lib/types';

const ProjectHealthInputSchema = z.object({
  projects: z.array(z.any()).describe("An array of project objects."),
  tasks: z.array(z.any()).describe("An array of task objects associated with the projects."),
});
export type ProjectHealthInput = z.infer<typeof ProjectHealthInputSchema>;

const ProjectHealthOutputSchema = z.object({
  healthScore: z
    .number()
    .describe('An overall health score from 0 to 100, where 100 is perfectly healthy.'),
  summary: z
    .string()
    .describe('A concise summary of the key risks, issues, or achievements.'),
});
export type ProjectHealthOutput = z.infer<typeof ProjectHealthOutputSchema>;

export async function getProjectHealth(
  input: ProjectHealthInput
): Promise<ProjectHealthOutput> {
  return projectHealthFlow(input);
}

const prompt = ai.definePrompt({
  name: 'projectHealthPrompt',
  input: {schema: ProjectHealthInputSchema},
  output: {schema: ProjectHealthOutputSchema},
  prompt: `You are an expert business analyst specializing in organizational efficiency. Analyze the following data, which includes all projects and tasks for an entire organization, to determine an overall **Organization Health Score**.

The health score should be a single number between 0 and 100, where 100 represents a perfectly healthy and efficient organization with all projects on track, and 0 represents an organization in critical condition with significant project delays and risks.

When calculating the score and summary, consider a holistic, organization-wide view based on these factors:
- The ratio of overdue tasks to completed tasks across all projects.
- The timeliness of task completion across the organization. A task is on time if its 'completedAt' date is on or before its 'dueDate'.
- The number and severity of projects that are behind schedule.
- The overall progress of the entire project portfolio.
- Any concentration of risks in specific departments or project types.

A task is considered overdue if it is not 'completed' and the current date is after its 'dueDate'. Compare only the date part. For example, a task due on July 9th is only overdue starting on July 10th. A task completed on its due date is considered on time.

Projects Data:
{{{json projects}}}

Tasks Data:
{{{json tasks}}}

Provide a concise, professional summary highlighting the most critical information an executive would need to know about the organization's overall operational health.
`,
});

const projectHealthFlow = ai.defineFlow(
  {
    name: 'projectHealthFlow',
    inputSchema: ProjectHealthInputSchema,
    outputSchema: ProjectHealthOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
