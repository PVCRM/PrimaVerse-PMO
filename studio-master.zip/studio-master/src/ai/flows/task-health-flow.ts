
'use server';
/**
 * @fileOverview An AI flow to analyze task data and determine a health score for an employee.
 *
 * - getTaskHealth - A function that analyzes task data to return a health score and summary.
 * - TaskHealthInput - The input type for the getTaskHealth function.
 * - TaskHealthOutput - The return type for the getTaskHealth function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { Task } from '@/lib/types';

const TaskHealthInputSchema = z.object({
  tasks: z.array(z.any()).describe("An array of task objects assigned to a user."),
});
export type TaskHealthInput = z.infer<typeof TaskHealthInputSchema>;

const TaskHealthOutputSchema = z.object({
  healthScore: z
    .number()
    .describe('A personal productivity and task health score from 0 to 100, where 100 is perfectly on track.'),
  summary: z
    .string()
    .describe('A concise summary of the task status, highlighting upcoming deadlines and any overdue items.'),
});
export type TaskHealthOutput = z.infer<typeof TaskHealthOutputSchema>;

export async function getTaskHealth(
  input: TaskHealthInput
): Promise<TaskHealthOutput> {
  return taskHealthFlow(input);
}

const prompt = ai.definePrompt({
  name: 'taskHealthPrompt',
  input: {schema: TaskHealthInputSchema},
  output: {schema: TaskHealthOutputSchema},
  prompt: `You are a productivity assistant. Analyze the following list of tasks for a single user to determine an overall task health score and provide a summary.

The health score should be a single number between 0 and 100, where 100 means all tasks are on schedule or completed.

Consider factors like:
- Number of overdue tasks. A task is considered overdue if it is not 'completed' and the current date is after its 'dueDate'. For this calculation, compare only the date part, ignoring time of day. For example, a task due on July 9th is only overdue starting on July 10th.
- Number of tasks due soon.
- The ratio of 'todo' vs 'in-progress' vs 'completed' tasks.

Tasks Data:
{{{json tasks}}}

Provide a concise, encouraging summary highlighting what's on track and what needs attention.
`,
});

const taskHealthFlow = ai.defineFlow(
  {
    name: 'taskHealthFlow',
    inputSchema: TaskHealthInputSchema,
    outputSchema: TaskHealthOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
