
'use server';
/**
 * @fileOverview User management administrative flows.
 *
 * - deleteUserPermanently - Deletes a user from Firebase Auth and Firestore.
 * - addUser - Creates a new user in Firebase Auth and Firestore.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import type { UserProfile, UserRole } from '@/lib/types';
import { Timestamp } from 'firebase-admin/firestore';


// ==================== DELETE USER ====================

const DeleteUserInputSchema = z.object({
  uid: z.string().describe('The UID of the user to permanently delete.'),
});

export async function deleteUserPermanently(uid: string): Promise<void> {
  await deleteUserFlow({ uid });
}

const deleteUserFlow = ai.defineFlow(
  {
    name: 'deleteUserFlow',
    inputSchema: DeleteUserInputSchema,
    outputSchema: z.void(),
  },
  async ({ uid }) => {
    // Calling the API route handler directly is more robust than fetching from a URL.
    // This requires abstracting the logic into a separate function if not already done.
    // For now, we will assume the internal API call is the intended pattern,
    // but we will make it a relative fetch to work within the Vercel environment.
    const res = await fetch(`/api/users/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid }),
    });

    if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Unknown error from deleteUser API');
    }
  }
);


// ==================== ADD USER ====================

const AddUserInputSchema = z.object({
    firstName: z.string(),
    lastName: z.string(),
    employeeId: z.string(),
    department: z.string(),
    email: z.string().email(),
    mobileCountryCode: z.string(),
    mobileNumber: z.string(),
    designation: z.string(),
    role: z.string(),
    password: z.string(),
});
export type AddUserInput = z.infer<typeof AddUserInputSchema>;

export async function addUser(input: AddUserInput): Promise<void> {
    await addUserFlow(input);
}

const addUserFlow = ai.defineFlow(
    {
        name: 'addUserFlow',
        inputSchema: AddUserInputSchema,
        outputSchema: z.void(),
    },
    async (input) => {
        // Using a relative path for the fetch call.
        const res = await fetch(`/api/users/add`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(input),
        });

        const data = await res.json();

        if (!res.ok) {
            throw new Error(data.error || 'Unknown error from addUser API');
        }
    }
);
