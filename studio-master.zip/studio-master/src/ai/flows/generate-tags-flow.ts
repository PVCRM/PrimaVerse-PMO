'use server';
/**
 * @fileOverview An AI flow to generate tags from notes.
 *
 * - generateTagsFromNotes - A function that takes notes and returns a list of tags.
 * - GenerateTagsInput - The input type.
 * - GenerateTagsOutput - The output type.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateTagsInputSchema = z.object({
  notes: z.string().describe('The notes from which to generate tags.'),
});
export type GenerateTagsInput = z.infer<typeof GenerateTagsInputSchema>;

const GenerateTagsOutputSchema = z.object({
  tags: z.array(z.string()).describe('A list of 1-3 word tags generated from the notes.'),
});
export type GenerateTagsOutput = z.infer<typeof GenerateTagsOutputSchema>;

export async function generateTagsFromNotes(
  input: GenerateTagsInput
): Promise<GenerateTagsOutput> {
  return generateTagsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateTagsPrompt',
  input: {schema: GenerateTagsInputSchema},
  output: {schema: GenerateTagsOutputSchema},
  prompt: `You are an expert in project management. Read the following notes about a client project and generate a list of 3-5 relevant tags. The tags should be concise (1-3 words) and useful for categorizing and searching for this client later.

Notes:
{{{notes}}}

Generate the tags.
`,
});

const generateTagsFlow = ai.defineFlow(
  {
    name: 'generateTagsFlow',
    inputSchema: GenerateTagsInputSchema,
    outputSchema: GenerateTagsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
