
'use server';
/**
 * @fileOverview An AI flow to sort tasks based on priority.
 *
 * - sortTasks - A function that takes tasks and returns a sorted list of task IDs.
 * - SortTasksInput - The input type.
 * - SortTasksOutput - The output type.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { Task } from '@/lib/types';
import { startOfDay } from 'date-fns';

const SortTasksInputSchema = z.object({
  tasks: z.array(z.any()).describe("An array of task objects to be sorted."),
});
export type SortTasksInput = z.infer<typeof SortTasksInputSchema>;

const SortTasksOutputSchema = z.object({
  sortedTaskIds: z.array(z.string()).describe('An array of task IDs in the recommended sorted order.'),
});
export type SortTasksOutput = z.infer<typeof SortTasksOutputSchema>;

export async function sortTasks(
  input: SortTasksInput
): Promise<SortTasksOutput> {
  return sortTasksFlow(input);
}

// This sorting logic is now handled directly in TypeScript for performance.
// The AI prompt is kept for reference but is no longer called.
const prompt = ai.definePrompt({
  name: 'sortTasksPrompt',
  input: {schema: SortTasksInputSchema},
  output: {schema: SortTasksOutputSchema},
  prompt: `You are an expert project manager responsible for prioritizing a user's task list. Analyze the following tasks and sort them based on urgency and importance.

The sorting criteria, in order of importance, are:
1.  **Overdue Tasks**: Any task where the due date is in the past. Sort these first by priority (P1 is highest) and then by the oldest due date.
2.  **Tasks Due Today**: Any task due on the current date. Sort these by priority (P1 is highest).
3.  **Upcoming Tasks**: Tasks due in the future. Sort these by priority (P1 is highest) and then by the soonest due date.

Today's date is ${new Date().toDateString()}.

Return ONLY the array of task IDs in the correctly sorted order.

Tasks:
{{{json tasks}}}
`,
});

const sortTasksFlow = ai.defineFlow(
  {
    name: 'sortTasksFlow',
    inputSchema: SortTasksInputSchema,
    outputSchema: SortTasksOutputSchema,
  },
  async input => {
    if (input.tasks.length <= 1) {
        return { sortedTaskIds: input.tasks.map(t => t.id) };
    }

    const today = startOfDay(new Date());

    const getPriorityValue = (priority: Task['priority']) => {
        return parseInt(priority.substring(1), 10);
    };

    const sortedTasks = input.tasks.sort((a, b) => {
        const aDueDate = startOfDay(new Date(a.dueDate));
        const bDueDate = startOfDay(new Date(b.dueDate));

        const aIsOverdue = aDueDate < today;
        const bIsOverdue = bDueDate < today;
        const aIsDueToday = aDueDate.getTime() === today.getTime();
        const bIsDueToday = bDueDate.getTime() === today.getTime();
        
        // 1. Overdue tasks come first
        if (aIsOverdue && !bIsOverdue) return -1;
        if (!aIsOverdue && bIsOverdue) return 1;
        if (aIsOverdue && bIsOverdue) {
            // Sort by priority, then oldest due date
            const priorityDiff = getPriorityValue(a.priority) - getPriorityValue(b.priority);
            if (priorityDiff !== 0) return priorityDiff;
            return aDueDate.getTime() - bDueDate.getTime();
        }
        
        // 2. Tasks due today come next
        if (aIsDueToday && !bIsDueToday) return -1;
        if (!aIsDueToday && bIsDueToday) return 1;
        if (aIsDueToday && bIsDueToday) {
            // Sort by priority
            return getPriorityValue(a.priority) - getPriorityValue(b.priority);
        }
        
        // 3. Upcoming tasks
        // Sort by priority, then soonest due date
        const priorityDiff = getPriorityValue(a.priority) - getPriorityValue(b.priority);
        if (priorityDiff !== 0) return priorityDiff;
        return aDueDate.getTime() - bDueDate.getTime();
    });

    return { sortedTaskIds: sortedTasks.map(t => t.id) };
  }
);
