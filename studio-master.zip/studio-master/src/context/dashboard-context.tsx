
"use client";

import { createContext, useContext, type ReactNode, type Dispatch, type SetStateAction, useState, useMemo, useCallback, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useProjects } from "@/hooks/use-projects";
import { useTasks } from "@/hooks/use-tasks";
import { useClients } from "@/hooks/use-clients";
import { useTeam } from "@/hooks/use-team";
import { useTimesheet } from "@/hooks/use-timesheet";
import { useMasterData } from "@/hooks/use-master-data";
import { usePermissions } from "@/hooks/use-permissions";
import type { Client, Project, Task, UserProfile, Permission, TimesheetEntry } from "@/lib/types";

export type View = 'dashboard' | 'clients' | 'projects' | 'tasks' | 'team' | 'reports' | 'settings' | 'approvals' | 'master-data' | 'permissions' | 'timesheet' | 'reviews-approvals' | 'critical-tasks' | 'resource-utility' | 'daily-log' | 'all-tasks';

export interface DashboardContextType {
  activeView: View;
  setActiveView: Dispatch<SetStateAction<View>>;
  isLoading: boolean;
  
  // Data
  allProjects: Project[];
  allTasks: Task[];
  allClients: Client[];
  team: UserProfile[];
  timesheetData: TimesheetEntry[];
  masterData: any;
  permissions: any;

  // Actions
  addProject: (projectData: Omit<Project, 'id'>) => Promise<void>;
  updateProject: (projectId: string, projectData: Partial<Project>) => Promise<void>;
  deleteProject: (projectId: string) => Promise<void>;
  refetchProjects: () => void;

  addTask: (taskData: Omit<Task, 'id'>) => Promise<void>;
  updateTask: (taskId: string, data: Partial<Omit<Task, 'id'>>) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;
  refetchTasks: () => void;

  addClient: (clientData: Omit<Client, 'id' | 'projectCount' | 'employeeCount' | 'status'>) => Promise<{ id: string; name: string; code: string; logo: string; department: string; startDate: Date; coordinators: import("/usr/src/app/src/lib/types").ClientCoordinator[]; duLeadId: string; projectManagerId: string; teamLeadIds: string[]; teamMemberIds: string[]; salesPersonId: string; notes: string; tags: string[]; status: import("/usr/src/app/src/lib/types").ClientStatus; }>;
  updateClient: (clientId: string, clientData: Partial<Omit<Client, 'id' | 'projectCount' | 'employeeCount'>>) => Promise<void>;
  deleteClient: (clientId: string) => Promise<void>;
  bulkAddClients: (data: any[], team: UserProfile[]) => Promise<{ successes: number; failures: { item: any; error: string }[]; }>;
  refetchClients: () => void;

  refetchTeam: () => void;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export const DashboardProvider = ({ children }: { children: ReactNode }) => {
  const { userProfile, loading: authLoading } = useAuth();
  const [activeView, setActiveView] = useState<View>('dashboard');
  
  const canLoadData = !!userProfile?.uid && !authLoading;

  const { projects: allProjects, addProject, updateProject, deleteProject, refetch: refetchProjects, loading: projectsLoading } = useProjects(canLoadData);
  const { clients: allClients, addClient, updateClient, deleteClient, bulkAddClients, refetch: refetchClients, loading: clientsLoading } = useClients(canLoadData, allProjects);
  const { tasks: allTasks, addTask, updateTask, deleteTask, refetch: refetchTasks, loading: tasksLoading } = useTasks(canLoadData);
  const { team, refetch: refetchTeam, loading: teamLoading } = useTeam();
  const { timesheetData, loading: loadingTimesheet } = useTimesheet(userProfile, team);
  const { masterData, loading: loadingMasterData } = useMasterData();
  const { permissions, loading: loadingPermissions } = usePermissions();
  
  const isLoading = authLoading || projectsLoading || tasksLoading || clientsLoading || teamLoading || loadingTimesheet || loadingMasterData || loadingPermissions;

  const providerValue = useMemo(() => ({
    activeView, setActiveView, isLoading,
    allProjects, allTasks, allClients, team, timesheetData, masterData, permissions,
    addProject, updateProject, deleteProject, refetchProjects,
    addTask, updateTask, deleteTask, refetchTasks,
    addClient, updateClient, deleteClient, bulkAddClients, refetchClients,
    refetchTeam
  }), [
    activeView, isLoading,
    allProjects, allTasks, allClients, team, timesheetData, masterData, permissions,
    addProject, updateProject, deleteProject, refetchProjects,
    addTask, updateTask, deleteTask, refetchTasks,
    addClient, updateClient, deleteClient, bulkAddClients, refetchClients,
    refetchTeam
  ]);

  return (
    <DashboardContext.Provider value={providerValue}>
      {children}
    </DashboardContext.Provider>
  );
};

export const useDashboard = () => {
    const context = useContext(DashboardContext);
    if (context === undefined) {
      throw new Error('useDashboard must be used within a DashboardProvider');
    }
    return context;
  };
