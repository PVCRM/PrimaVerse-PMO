

"use client";

import { useState, useEffect, useCallback, createContext, useContext, ReactNode } from 'react';
import { collection, getDocs, doc, setDoc, addDoc, updateDoc, deleteDoc, writeBatch, query, orderBy, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import type { Department, Designation, ProjectType, TaskType, UserRole } from '@/lib/types';
import { initialMasterData, allRoles } from '@/data/master-data';

export interface MasterDataItem {
    id: string;
    name: string;
    [key: string]: any;
}

interface MasterData {
    departments: Department[];
    designations: Designation[];
    projectTypes: ProjectType[];
    taskTypes: TaskType[];
    roles: UserRole[];
}

interface MasterDataContextType {
    masterData: MasterData;
    loading: boolean;
    addMasterDataItem: (collectionName: string, data: Omit<MasterDataItem, 'id'> | Omit<MasterDataItem, 'id'>[]) => Promise<void>;
    updateMasterDataItem: (collectionName: string, id: string, data: Partial<MasterDataItem>) => Promise<void>;
    deleteMasterDataItem: (collectionName: string, id: string) => Promise<void>;
    bulkAddProjectTypes: (data: { Name: string, DepartmentName: string }[]) => Promise<{ successes: number; failures: { item: any; error: string }[] }>;
    bulkAddTaskTypes: (data: { Name: string, ProjectTypeName: string, DepartmentName: string }[]) => Promise<{ successes: number; failures: { item: any; error: string }[] }>;
    refetchMasterData: () => void;
}

const MasterDataContext = createContext<MasterDataContextType | undefined>(undefined);

export function MasterDataProvider({ children }: { children: ReactNode }) {
    const { userProfile } = useAuth();
    const { toast } = useToast();
    const [masterData, setMasterData] = useState<MasterData>({
        departments: [],
        designations: [],
        projectTypes: [],
        taskTypes: [],
        roles: allRoles,
    });
    const [loading, setLoading] = useState(true);

    const seedDatabase = useCallback(async () => {
        const departmentsSnap = await getDocs(collection(db, "departments"));
        if (!departmentsSnap.empty) {
            return; // Already seeded
        }

        toast({
            title: "Setting up Master Data",
            description: "Please wait while we initialize the database...",
        });

        const batch = writeBatch(db);

        initialMasterData.departments.forEach(dept => {
            const docRef = doc(db, "departments", dept.id);
            batch.set(docRef, { name: dept.name });
        });
        initialMasterData.designations.forEach(item => {
            const docRef = doc(collection(db, "designations"));
            batch.set(docRef, item);
        });
        initialMasterData.projectTypes.forEach(item => {
            const { id, ...data } = item;
            const docRef = doc(db, "projectTypes", id);
            batch.set(docRef, data);
        });
        initialMasterData.taskTypes.forEach(item => {
            const docRef = doc(collection(db, "taskTypes"));
            batch.set(docRef, item);
        });


        await batch.commit();
        toast({
            title: "Setup Complete",
            description: "Master data has been successfully initialized.",
        });
    }, [toast]);

    const fetchMasterData = useCallback(async () => {
        setLoading(true);
        try {
            if (userProfile?.role === 'Super Admin') {
                await seedDatabase();
            }

            const [departmentsSnap, designationsSnap, projectTypesSnap, taskTypesSnap] = await Promise.all([
                getDocs(query(collection(db, "departments"), orderBy('name'))),
                getDocs(query(collection(db, "designations"), orderBy('name'))),
                getDocs(query(collection(db, "projectTypes"), orderBy('name'))),
                getDocs(query(collection(db, "taskTypes"), orderBy('name'))),
            ]);
            
            const rawDepartments = departmentsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department));
            const uniqueDepartments = Array.from(new Map(rawDepartments.map(d => [d.name, d])).values());

            const rawDesignations = designationsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Designation));
            const uniqueDesignations = Array.from(new Map(rawDesignations.map(d => [`${d.name}-${d.departmentId}`, d])).values());
            
            const rawProjectTypes = projectTypesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as ProjectType));
            const uniqueProjectTypes = Array.from(new Map(rawProjectTypes.map(pt => [`${pt.name}-${pt.departmentId}`, pt])).values());

            const rawTaskTypes = taskTypesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as TaskType));
            const uniqueTaskTypes = Array.from(new Map(rawTaskTypes.map(tt => [`${tt.name}-${tt.projectTypeId}`, tt])).values());


            setMasterData({
                departments: uniqueDepartments,
                designations: uniqueDesignations,
                projectTypes: uniqueProjectTypes,
                taskTypes: uniqueTaskTypes,
                roles: allRoles,
            });
        } catch (error) {
            console.error("Error fetching master data:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to load master data.' });
        } finally {
            setLoading(false);
        }
    }, [toast, userProfile, seedDatabase]);

    useEffect(() => {
        if (userProfile) {
            fetchMasterData();
        }
    }, [userProfile, fetchMasterData]);

    const addMasterDataItem = async (collectionName: string, data: Omit<MasterDataItem, 'id'> | Omit<MasterDataItem, 'id'>[]) => {
        try {
            if (Array.isArray(data)) {
                if (data.length === 0) return;
                const batch = writeBatch(db);
                const collectionRef = collection(db, collectionName);
                data.forEach(item => {
                    const docRef = doc(collectionRef);
                    batch.set(docRef, item);
                });
                await batch.commit();
                toast({ title: 'Success', description: `${data.length} items added successfully.` });
            } else {
                await addDoc(collection(db, collectionName), data);
                toast({ title: 'Success', description: 'Item added successfully.' });
            }
            fetchMasterData();
        } catch (error) {
            console.error("Error adding item(s):", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not add item(s).' });
        }
    };

    const updateMasterDataItem = async (collectionName: string, id: string, data: Partial<MasterDataItem>) => {
        try {
            await updateDoc(doc(db, collectionName, id), data);
            toast({ title: 'Success', description: 'Item updated successfully.' });
            fetchMasterData();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not update item.' });
        }
    };

    const deleteMasterDataItem = async (collectionName: string, id: string) => {
        try {
            await deleteDoc(doc(db, collectionName, id));
            toast({ title: 'Success', description: 'Item deleted successfully.' });
            fetchMasterData();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not delete item.' });
        }
    };

    const bulkAddProjectTypes = async (data: { Name: string, DepartmentName: string }[]) => {
        let successes = 0;
        const failures: { item: any; error: string }[] = [];
        const batch = writeBatch(db);
        const projectTypesCollection = collection(db, "projectTypes");
    
        const processedInBatch = new Set<string>();
    
        for (const item of data) {
            const department = masterData.departments.find(d => d.name.toLowerCase() === item.DepartmentName.toLowerCase());
            if (!department) {
                failures.push({ item, error: `Department '${item.DepartmentName}' not found.` });
                continue;
            }
    
            const uniqueKey = `${item.Name.toLowerCase()}|${department.id}`;
            const existing = masterData.projectTypes.some(pt => pt.name.toLowerCase() === item.Name.toLowerCase() && pt.departmentId === department.id);
            
            if (existing || processedInBatch.has(uniqueKey)) {
                failures.push({ item, error: `Project Type '${item.Name}' already exists in this department.` });
                continue;
            }
            
            const docRef = doc(projectTypesCollection);
            batch.set(docRef, { name: item.Name, departmentId: department.id });
            processedInBatch.add(uniqueKey);
            successes++;
        }
    
        await batch.commit();
        if (successes > 0) await fetchMasterData();
        return { successes, failures };
    };
    
    const bulkAddTaskTypes = async (data: { Name: string, ProjectTypeName: string, DepartmentName: string }[]) => {
        let successes = 0;
        const failures: { item: any; error: string }[] = [];
        const batch = writeBatch(db);
        const taskTypesCollection = collection(db, "taskTypes");

        const processedInBatch = new Set<string>();

        for (const item of data) {
            const department = masterData.departments.find(d => d.name.toLowerCase() === item.DepartmentName.toLowerCase());
            if (!department) {
                failures.push({ item, error: `Department '${item.DepartmentName}' not found.` });
                continue;
            }

            const projectType = masterData.projectTypes.find(pt => pt.name.toLowerCase() === item.ProjectTypeName.toLowerCase() && pt.departmentId === department.id);
            if (!projectType) {
                failures.push({ item, error: `Project Type '${item.ProjectTypeName}' not found in department '${item.DepartmentName}'.` });
                continue;
            }

            const uniqueKey = `${item.Name.toLowerCase()}|${projectType.id}`;
            const existing = masterData.taskTypes.some(tt => tt.name.toLowerCase() === item.Name.toLowerCase() && tt.projectTypeId === projectType.id);

            if (existing || processedInBatch.has(uniqueKey)) {
                failures.push({ item, error: `Task Type '${item.Name}' already exists for this project type.` });
                continue;
            }

            const docRef = doc(taskTypesCollection);
            batch.set(docRef, { name: item.Name, projectTypeId: projectType.id });
            processedInBatch.add(uniqueKey);
            successes++;
        }

        await batch.commit();
        if (successes > 0) await fetchMasterData();
        return { successes, failures };
    };

    const value = {
        masterData,
        loading,
        addMasterDataItem,
        updateMasterDataItem,
        deleteMasterDataItem,
        bulkAddProjectTypes,
        bulkAddTaskTypes,
        refetchMasterData: fetchMasterData,
    };

    return (
        <MasterDataContext.Provider value={value}>
            {children}
        </MasterDataContext.Provider>
    );
}

export function useMasterData() {
    const context = useContext(MasterDataContext);
    if (context === undefined) {
        throw new Error('useMasterData must be used within a MasterDataProvider');
    }
    return context;
}

    
