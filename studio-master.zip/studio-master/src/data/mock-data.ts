
import type { Client, Project, Task, TeamMember, Department, Designation, ProjectType } from '@/lib/types'
import { subDays, addDays } from 'date-fns'

const now = new Date();

export const majorPhoneCountryCodes = [
    { value: '91', label: 'IN (+91)' },
    { value: '1', label: 'US (+1)' },
    { value: '44', label: 'UK (+44)' },
    { value: '61', label: 'AU (+61)' },
    { value: '49', label: 'DE (+49)' },
    { value: '33', label: 'FR (+33)' },
    { value: '971', label: 'AE (+971)' },
    { value: '86', label: 'CN (+86)' },
    { value: '81', label: 'JP (+81)' },
    { value: '55', label: 'BR (+55)' },
].filter((v,i,a)=>a.findIndex(t=>(t.value === v.value))===i);


// This mock data is now only used for initializing the client list
// or for components that haven't been fully migrated to Firestore.
// The main dashboard now pulls live data from useClients, useProjects, useTasks hooks.

export const allClients: Client[] = [
    { 
        id: 'client-1', 
        name: 'Innovate Corp', 
        code: 'INC', 
        department: 'Mechanical', 
        startDate: subDays(now, 150), 
        logo: 'https://placehold.co/40x40.png',
        coordinators: [{
            id: 'coord-1',
            firstName: 'Alice',
            lastName: 'Smith',
            email: 'alice@innovate.com',
            officePhoneCountryCode: '1',
            officePhoneNumber: '555-1111',
            officePhoneExt: '123',
            mobilePhoneCountryCode: '1',
            mobilePhoneNumber: '555-2222',
            streetAddress: '123 Innovation Dr',
            country: 'US',
            state: 'CA',
            city: 'San Francisco',
            zipcode: '94107',
        }],
        projectManagers: ['user-3'],
        notes: 'Long-term client, focus on MEP projects.',
        tags: ['MEP', 'HVAC']
    },
    { 
        id: 'client-2', 
        name: 'Synergy Solutions', 
        code: 'SYS', 
        department: 'Marketing', 
        startDate: subDays(now, 300), 
        logo: 'https://placehold.co/40x40.png',
        coordinators: [{
            id: 'coord-2',
            firstName: 'Bob',
            lastName: 'Johnson',
            email: 'bob@synergy.com',
            officePhoneCountryCode: '44',
            officePhoneNumber: '20-7946-0102',
            officePhoneExt: '',
            mobilePhoneCountryCode: '44',
            mobilePhoneNumber: '7700-900123',
            streetAddress: '456 Synergy Ave',
            country: 'GB',
            state: 'ENG',
            city: 'London',
            zipcode: 'SW1A 0AA',
        }],
        projectManagers: ['user-5', 'user-6'],
        notes: 'Consulting services for their marketing department. High-value account.',
        tags: ['consulting', 'marketing']
    },
]

export const allTeamMembers: TeamMember[] = [
  { id: 'user-1', name: 'Alex Doe', role: 'Mechanical Engineer' },
  { id: 'user-2', name: 'Beth Ray', role: 'Civil Engineer' },
  { id: 'user-3', name: 'Chris Garcia', role: 'Asst. Manager' },
  { id: 'user-4', name: 'Dana Smith', role: 'Sr. Mech Engineer' },
  { id: 'user-5', name: 'Evan Frost', role: 'Team Lead (Mechanical, Civil, MEP)' },
  { id: 'user-6', name: 'Fiona Green', role: 'Operations Manager' },
]

// Mock projects and tasks for components that still use them.
// Will be replaced by Firestore data hooks.
export const allProjects: Project[] = [
  { id: 'proj-1', name: 'Downtown Tower HVAC', clientId: 'client-1', projectType: 'HVAC Design' },
  { id: 'proj-2', name: 'Brand Awareness Campaign', clientId: 'client-2', projectType: 'Brand Strategy' },
  { id: 'proj-3', name: 'Bridge Structural Integrity', clientId: 'client-1', projectType: 'Structural Analysis' },
]

export const allTasks: Task[] = [
    { id: 'task-1', title: 'Initial CAD drawings', status: 'completed', projectId: 'proj-1', dueDate: subDays(now, 10), completedAt: subDays(now, 8) },
    { id: 'task-2', title: 'Load calculation', status: 'completed', projectId: 'proj-1', dueDate: subDays(now, 5), completedAt: subDays(now, 3) },
    { id: 'task-3', title: 'Ductwork layout', status: 'in-progress', projectId: 'proj-1', dueDate: addDays(now, 2) },
    { id: 'task-4', title: 'Finalize equipment selection', status: 'todo', projectId: 'proj-1', dueDate: addDays(now, 5) },
    { id: 'task-5', title: 'Create ad copy', status: 'completed', projectId: 'proj-2', dueDate: subDays(now, 12), completedAt: subDays(now, 10) },
    { id: 'task-6', title: 'Competitor analysis report', status: 'overdue', projectId: 'proj-2', dueDate: subDays(now, 2) },
    { id: 'task-7', title: 'Social media asset design', status: 'in-progress', projectId: 'proj-2', dueDate: addDays(now, 3) },
    { id: 'task-8', title: 'Material stress tests', status: 'todo', projectId: 'proj-3', dueDate: addDays(now, 10) },
    { id: 'task-9', title: 'Foundation inspection', status: 'todo', projectId: 'proj-3', dueDate: addDays(now, 15) },
];
