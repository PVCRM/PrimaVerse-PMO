
import type { UserRole } from '@/lib/types';

export const allRoles: UserRole[] = ['Employee', 'Team Lead', 'Project Manager', 'Director/VP/CXO'];

export const roleHierarchy: Record<UserRole, number> = {
  'Employee': 0,
  'Team Lead': 1,
  'Project Manager': 2,
  'Director/VP/CXO': 3,
  'Super Admin': 4, // Keep Super Admin for hierarchy checks even though it's not assignable
};

// This data is used ONLY to seed the database the first time.
// After that, master data is managed dynamically from the UI.
export const initialMasterData = {
    departments: [
        { id: 'civil', name: 'Civil' },
        { id: 'mep-bim', name: 'MEP (BIM)' },
        { id: 'mechanical', name: 'Mechanical' },
        { id: 'digital-marketing', name: 'Digital Marketing' },
        { id: 'sales', name: 'Sales' },
    ],
    designations: [
        // Mechanical
        { name: 'Jr. Engineer', departmentId: 'mechanical' },
        { name: 'Mechanical Engineer', departmentId: 'mechanical' },
        { name: 'Sr. Mechanical Engineer', departmentId: 'mechanical' },
        { name: 'Team Lead', departmentId: 'mechanical' },
        { name: 'Assistant Manager', departmentId: 'mechanical' },
        { name: 'Operations Manager', departmentId: 'mechanical' },
        
        // Civil
        { name: 'Jr. Engineer', departmentId: 'civil' },
        { name: 'Civil Engineer', departmentId: 'civil' },
        { name: 'Sr. Civil Engineer', departmentId: 'civil' },
        { name: 'Team Lead', departmentId: 'civil' },
        { name: 'Assistant Manager', departmentId: 'civil' },
        { name: 'Operations Manager', departmentId: 'civil' },

        // MEP (BIM)
        { name: 'Jr. Engineer', departmentId: 'mep-bim' },
        { name: 'Team Lead', departmentId: 'mep-bim' },
        { name: 'Assistant Manager', departmentId: 'mep-bim' },
        { name: 'Operations Manager', departmentId: 'mep-bim' },

        // Digital Marketing
        { name: 'Website Designer', departmentId: 'digital-marketing' },
        { name: 'Graphic Designer', departmentId: 'digital-marketing' },
        { name: 'Senior Designer', departmentId: 'digital-marketing' },
        { name: 'Developer', departmentId: 'digital-marketing' },
        { name: 'Operations Manager', departmentId: 'digital-marketing' },
        { name: 'Digital Marketing Executive', departmentId: 'digital-marketing' },
        { name: 'Digital Marketing Lead', departmentId: 'digital-marketing' },
        { name: 'Digital Marketing Manager', departmentId: 'digital-marketing' },
    ],
    projectTypes: [
        // Civil
        { id: 'civil-survey', name: 'Survey', departmentId: 'civil' },
        { id: 'civil-land-dev', name: 'Land Development', departmentId: 'civil' },
        
        // MEP (BIM)
        { id: 'mep-bim-services', name: 'BIM services', departmentId: 'mep-bim' },
        
        // Mechanical
        { id: 'mech-general', name: 'Mechanical', departmentId: 'mechanical' },
        
        // Digital Marketing
        { id: 'dm-digital-services', name: 'Digital', departmentId: 'digital-marketing' },
    ],
    taskTypes: [
        // Civil - Survey
        { projectTypeId: 'civil-survey', name: 'Boundary' },
        { projectTypeId: 'civil-survey', name: 'Topo' },
        { projectTypeId: 'civil-survey', name: 'Inverts' },
        { projectTypeId: 'civil-survey', name: 'Linework and annotation' },
        { projectTypeId: 'civil-survey', name: 'Redlines' },

        // Civil - Land Development
        { projectTypeId: 'civil-land-dev', name: 'Cover sheet' },
        { projectTypeId: 'civil-land-dev', name: 'Demolition plans' },
        { projectTypeId: 'civil-land-dev', name: 'Pre plat' },
        { projectTypeId: 'civil-land-dev', name: 'Pre Grading plan' },
        { projectTypeId: 'civil-land-dev', name: 'Pre Utility plan' },
        { projectTypeId: 'civil-land-dev', name: 'Mass grading' },
        { projectTypeId: 'civil-land-dev', name: 'Paving Plan' },
        { projectTypeId: 'civil-land-dev', name: 'Grading and Drainage plan' },
        { projectTypeId: 'civil-land-dev', name: 'Utility Plan' },
        { projectTypeId: 'civil-land-dev', name: 'Details' },
        { projectTypeId: 'civil-land-dev', name: 'Erosion control plans' },
        { projectTypeId: 'civil-land-dev', name: 'ADA plans' },
        { projectTypeId: 'civil-land-dev', name: 'Fire Truck plans' },
        { projectTypeId: 'civil-land-dev', name: 'Site plan' },
        { projectTypeId: 'civil-land-dev', name: 'Geometry plan' },

        // MEP - BIM services
        { projectTypeId: 'mep-bim-services', name: '3D modelling for plumbing' },
        { projectTypeId: 'mep-bim-services', name: '3D modelling for HVAC' },
        { projectTypeId: 'mep-bim-services', name: '3D modelling for Fire fighting' },
        { projectTypeId: 'mep-bim-services', name: 'Pool creation' },
        { projectTypeId: 'mep-bim-services', name: 'Sheet preparation' },
        { projectTypeId: 'mep-bim-services', name: 'shop drawings' },
        { projectTypeId: 'mep-bim-services', name: 'Electrical layout plan' },

        // Mechanical - Mechanical
        { projectTypeId: 'mech-general', name: '3D Views Preparations' },
        { projectTypeId: 'mech-general', name: 'Checking' },
        { projectTypeId: 'mech-general', name: 'Assembly Drawing' },
        { projectTypeId: 'mech-general', name: 'Ladder Drawing' },
        { projectTypeId: 'mech-general', name: 'Stairs Drawing' },
        { projectTypeId: 'mech-general', name: 'Frame Drawing' },
        { projectTypeId: 'mech-general', name: 'Handrail Drawing' },
        { projectTypeId: 'mech-general', name: 'Support Drawing' },
        { projectTypeId: 'mech-general', name: 'Grating Drawing' },
        { projectTypeId: 'mech-general', name: 'Body Drawing' },
        { projectTypeId: 'mech-general', name: 'Rainshield/PP Assembly Drawing' },
        { projectTypeId: 'mech-general', name: 'Rainshield/PP Shop Drawing' },
        { projectTypeId: 'mech-general', name: 'Isometric Preparation' },
        { projectTypeId: 'mech-general', name: 'Piping Drawing' },
        { projectTypeId: 'mech-general', name: 'Fabrication Drawing' },
        { projectTypeId: 'mech-general', name: 'Nozzle Drawing' },
        { projectTypeId: 'mech-general', name: 'Manway Drawing' },
        { projectTypeId: 'mech-general', name: 'Strake Drawing' },
        { projectTypeId: 'mech-general', name: 'Saddle Drawing' },
        { projectTypeId: 'mech-general', name: 'Attachment Drawing' },
        { projectTypeId: 'mech-general', name: 'Skid Drawing' },
        { projectTypeId: 'mech-general', name: 'Combustion Air Duct Drawing' },
        { projectTypeId: 'mech-general', name: 'Ventury Drawing' },
        { projectTypeId: 'mech-general', name: '3D Modeling' },
        { projectTypeId: 'mech-general', name: 'Engineering Drawing' },
        { projectTypeId: 'mech-general', name: 'All Drawings' },
        { projectTypeId: 'mech-general', name: '3D Model & All Drawings' },
        { projectTypeId: 'mech-general', name: 'Shop Drawing' },
        { projectTypeId: 'mech-general', name: 'Modification As Per Comments' },
        
        // Digital Marketing - Digital
        { projectTypeId: 'dm-digital-services', name: 'Branding' },
        { projectTypeId: 'dm-digital-services', name: 'Websites' },
        { projectTypeId: 'dm-digital-services', name: 'SMM' },
        { projectTypeId: 'dm-digital-services', name: 'SEM' },
        { projectTypeId: 'dm-digital-services', name: 'SEO' },
        { projectTypeId: 'dm-digital-services', name: 'Content writing' },
        { projectTypeId: 'dm-digital-services', name: 'Video Production' },
        { projectTypeId: 'dm-digital-services', name: 'Video Post Production' },
    ]
};
