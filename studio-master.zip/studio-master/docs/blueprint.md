# **App Name**: PerspectivePM

## Core Features:

- Role-Based Access: Role-Based Dashboard: Displays project analytics based on user role (Employee, Team Leader, Manager, Director, Super Admin).
- Analytics Visualization: Interactive Charts: Visualize project data through charts, like completed vs. incomplete tasks (donut), tasks by section (bar), and task completion over time (area).
- Task Summary Blocks: Task Summaries: Display aggregated task counts (Completed, Incomplete, Overdue, Total) for quick insights.
- Project Context Menu: Top-Level Project Selection: Easy project switching using a top-level dropdown menu.
- Navigation Menu: Sidebar Navigation: Streamlined access to different sections (Home, My Tasks, Inbox, Reporting, Favorites).
- AI-Powered View Optimizer: Smart Recommendations: LLM tool analyzes user activity and suggests optimal views for better performance based on past data.

## Style Guidelines:

- Primary color: Soft purple (#A093E2) for a calming and professional aesthetic.
- Background color: Light gray (#F5F7FA), offering a clean backdrop for the content.
- Accent color: Light pink (#E9A8C1) to highlight interactive elements and call-to-actions.
- Body and headline font: 'Montserrat' sans-serif, specified by the user for the overall aesthetic.
- Note: currently only Google Fonts are supported.
- Dashboard: Multi-section layout in the style of Turbo, with top rows of analytics, lower grids for detailed data, left sidebar, tabbed views.
- Simple Line Icons: Use a consistent style of outline icons for key menu items, actions, and information displays, in keeping with the requested minimalist design.