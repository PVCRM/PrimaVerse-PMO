
"use client"

import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Filter, Download } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { DateRange } from "react-day-picker";
import { format, subDays } from "date-fns";
import type { Client, Project } from '@/lib/types';

interface ReportsPageProps {
    clients: Client[];
    projects: Project[];
    masterData: any;
}

export function ReportsPage({ clients, projects, masterData }: ReportsPageProps) {
    const [date, setDate] = useState<DateRange | undefined>({ from: subDays(new Date(), 29), to: new Date() });
    const [department, setDepartment] = useState('all');
    const [client, setClient] = useState('all');
    const [project, setProject] = useState('all');
    
    useEffect(() => {
        setClient('all');
        setProject('all');
    }, [department]);

    useEffect(() => {
        setProject('all');
    }, [client]);

    const clientOptions = useMemo(() => {
      if (department === 'all' || !masterData.departments) return clients;
      const dept = masterData.departments.find((d: any) => d.id === department);
      if (!dept) return [];
      return clients.filter(c => c.department === dept.name);
    }, [clients, department, masterData.departments]);

    const projectOptions = useMemo(() => {
        if (client === 'all') {
             const clientIds = clientOptions.map(c => c.id);
             return projects.filter(p => clientIds.includes(p.clientId));
        }
        return projects.filter(p => p.clientId === client);
    }, [projects, client, clientOptions]);


    return (
        <Card>
            <CardHeader>
                <CardTitle>Reports Center</CardTitle>
                <CardDescription>Generate and download consolidated reports based on your filters.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="p-4 border rounded-lg space-y-4">
                    <div className="flex flex-wrap items-center gap-4">
                        <h4 className="font-semibold flex items-center gap-2"><Filter className="h-4 w-4" /> Filters</h4>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="w-full sm:w-auto justify-start text-left font-normal">
                                    {date?.from ? (
                                        date.to ? `${format(date.from, "LLL dd, y")} - ${format(date.to, "LLL dd, y")}` : format(date.from, "LLL dd, y")
                                    ) : "Select Date Range"}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                                <Calendar initialFocus mode="range" defaultMonth={date?.from} selected={date} onSelect={setDate} numberOfMonths={2} />
                            </PopoverContent>
                        </Popover>
                         <Select value={department} onValueChange={setDepartment}>
                            <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="All Departments"/></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Departments</SelectItem>
                                {masterData.departments?.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                         <Select value={client} onValueChange={setClient} disabled={clientOptions.length === 0}>
                            <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="All Clients"/></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Clients</SelectItem>
                                {clientOptions.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                         <Select value={project} onValueChange={setProject} disabled={projectOptions.length === 0}>
                            <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="All Projects"/></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Projects</SelectItem>
                                {projectOptions.map((p: any) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <div className="text-center pt-8">
                    <p className="text-muted-foreground mb-4">Select your filters and click download to generate a report.</p>
                    <Button>
                        <Download className="mr-2 h-4 w-4" />
                        Download Report
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}
