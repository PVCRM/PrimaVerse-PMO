import * as admin from 'firebase-admin';
import { config } from 'dotenv';

config();

if (!admin.apps.length) {
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  // This is the crucial fix: correctly format the private key by replacing the
  // escaped newline characters with actual newline characters.
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');

  // Add diagnostic logging to ensure environment variables are loaded.
  if (!projectId || !clientEmail || !privateKey) {
    console.error("Firebase Admin initialization failed. One or more environment variables (FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY) are missing.");
    throw new Error('Firebase Admin initialization failed. Please check your environment variables.');
  }

  try {
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId,
        clientEmail,
        privateKey,
      }),
    });
    console.log("Firebase Admin SDK initialized successfully.");
  } catch (error: any) {
    console.error("CRITICAL: Failed to initialize Firebase Admin.", {
      message: error.message,
      projectIdLoaded: !!projectId,
      clientEmailLoaded: !!clientEmail,
      privateKeyLoaded: !!privateKey,
    });
    throw new Error(`Firebase Admin initialization failed. Original Error: ${error.message}`);
  }
}

const auth = admin.auth();
const firestore = admin.firestore();

export { auth, firestore };
