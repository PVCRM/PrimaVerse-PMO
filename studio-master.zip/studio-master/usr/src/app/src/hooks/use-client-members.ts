

"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, query, where, getDocs, documentId } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { UserProfile, Project } from '@/lib/types';
import { useProjects } from './use-projects';

/**
 * A hook to fetch all unique team members associated with a given client.
 * It first checks the client document for an explicit list of members.
 * If not found, it aggregates team members from all projects under that client.
 * @param clientId The ID of the client.
 */
export function useClientMembers(clientId: string | null) {
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const { projects, loading: loadingProjects } = useProjects(true);

  const fetchMembers = useCallback(async () => {
    if (!clientId || loadingProjects) {
      setMembers([]);
      return;
    }

    setLoading(true);

    const clientProjects = projects.filter(p => p.clientId === clientId);
    if (clientProjects.length === 0) {
        setMembers([]);
        setLoading(false);
        return;
    }

    const memberIds = new Set<string>();
    clientProjects.forEach(project => {
        if (project.teamIds) {
            project.teamIds.forEach(id => memberIds.add(id));
        }
    });

    const uniqueMemberIds = Array.from(memberIds);

    if (uniqueMemberIds.length > 0) {
      // Firestore 'in' query is limited to 30 items per query.
      // For more than 30 members, this would need to be batched.
      const memberBatches: string[][] = [];
      for (let i = 0; i < uniqueMemberIds.length; i += 30) {
          memberBatches.push(uniqueMemberIds.slice(i, i + 30));
      }

      const memberPromises = memberBatches.map(batch => 
        getDocs(query(collection(db, 'users'), where(documentId(), 'in', batch)))
      );
      
      const memberSnapshots = await Promise.all(memberPromises);
      const fetchedMembers = memberSnapshots.flatMap(snapshot => 
        snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile))
      );
      
      setMembers(fetchedMembers);
    } else {
      setMembers([]);
    }

    setLoading(false);
  }, [clientId, projects, loadingProjects]);

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  return { members, loading, refetch: fetchMembers };
}
