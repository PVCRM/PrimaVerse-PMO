
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, Timestamp, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Client, Project } from '@/lib/types';
import { useAuth } from './use-auth';
import { usePermissions } from './use-permissions';
import { roleHierarchy } from '@/data/master-data';

export function useClients(allProjects: Project[]) {
  const { userProfile } = useAuth();
  const { permissions, loading: loadingPermissions } = usePermissions();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchClients = useCallback(async () => {
    if (!userProfile || loadingPermissions) {
      if (!loadingPermissions) setLoading(false);
      return;
    }
    
    const userPermissions = permissions[userProfile.role];
    if (!userPermissions || userPermissions.clients === 'Hide') {
      setClients([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const clientsCollection = collection(db, 'clients');
      let q;
      
      const userLevel = roleHierarchy[userProfile.role];
      
      // Ensure userDepartments is always an array for the 'in' query.
      const userDepartments = Array.isArray(userProfile.department) 
        ? userProfile.department 
        : [userProfile.department];

      if (userLevel >= 3) { // Director & Super Admin see all clients.
          q = query(clientsCollection, orderBy('name', 'asc'));
      } else if (userLevel >= 1 && userDepartments.length > 0) { // PMs and Team Leads
          // This is the key fix: using 'in' to match the client's department string
          // against the array of the user's assigned departments.
          q = query(clientsCollection, where('department', 'in', userDepartments), orderBy('name', 'asc'));
      } else { // Employee sees clients related to their assigned projects.
          const clientIdsFromProjects = [...new Set(allProjects.map(p => p.clientId))];
          if (clientIdsFromProjects.length === 0) {
              setClients([]);
              setLoading(false);
              return;
          }
          // Firestore 'in' query limit is 30
          q = query(clientsCollection, where('__name__', 'in', clientIdsFromProjects.slice(0, 30)));
      }
      
      const querySnapshot = await getDocs(q);
      const fetchedClients = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          status: doc.data().status || 'Active', 
          startDate: (doc.data().startDate as any as Timestamp).toDate(),
      }) as Client);
      
      setClients(fetchedClients);
    } catch (err: any) {
      console.error("Error fetching clients:", err);
      if (err.code === 'failed-precondition' || err.code === 'invalid-argument') {
          setError(new Error("A database index is required for this query. Please check the Firebase console."));
      } else {
          setError(err);
      }
    } finally {
      setLoading(false);
    }
  }, [userProfile, permissions, loadingPermissions, allProjects]);

  useEffect(() => {
    fetchClients();
  }, [fetchClients]);

  // Actions like add, update, delete remain unchanged.
  // ...
}
