
"use client";

import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, Timestamp, where, addDoc, doc, updateDoc, deleteDoc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Task, Project } from '@/lib/types';
import { useAuth } from './use-auth';
import { usePermissions } from './use-permissions';
import { useProjects } from './use-projects';
import { roleHierarchy } from '@/data/master-data';


export function useTasks() {
  const { userProfile } = useAuth();
  const { permissions, loading: loadingPermissions } = usePermissions();
  const { projects, loading: loadingProjects } = useProjects();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchTasks = useCallback(async () => {
    if (!userProfile || loadingPermissions || loadingProjects) {
        if (!loadingPermissions && !loadingProjects) setLoading(false);
        return;
    }
    
    const userPermissions = permissions[userProfile.role];
    if (!userPermissions || userPermissions.tasks === 'Hide') {
        setTasks([]);
        setLoading(false);
        return;
    }

    setLoading(true);
    setError(null);
    try {
        const tasksRef = collection(db, 'tasks');
        let q;

        const userLevel = roleHierarchy[userProfile.role];

        if (userLevel === 0) { // Employee
            q = query(tasksRef, where('assigneeId', '==', userProfile.uid), orderBy('dueDate', 'desc'));
        } else { // Team Lead, PM, Director, Super Admin
            const accessibleProjectIds = projects.map(p => p.id);
            if (accessibleProjectIds.length === 0) {
                setTasks([]);
                setLoading(false);
                return;
            }
            q = query(tasksRef, where('projectId', 'in', accessibleProjectIds.slice(0, 30)));
        }
      
      const querySnapshot = await getDocs(q);
      let fetchedTasks = querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          startDate: (data.startDate as Timestamp)?.toDate(),
          dueDate: (data.dueDate as Timestamp).toDate(),
          startedAt: data.startedAt ? (data.startedAt as Timestamp).toDate() : undefined,
          completedAt: data.completedAt ? (data.completedAt as Timestamp).toDate() : undefined,
        } as Task;
      });
      
      // Always sort client-side to avoid index dependency issues if not ordered in query
      if (userLevel > 0) {
        fetchedTasks.sort((a,b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());
      }
      
      setTasks(fetchedTasks);
    } catch (err: any) {
      console.error("Error fetching tasks:", err);
       if (err.code === 'failed-precondition' || err.code === 'invalid-argument') {
          setError(new Error("A database index is required or query is too complex. Please check the Firebase console."));
      } else {
          setError(err);
      }
    } finally {
      setLoading(false);
    }
  }, [userProfile, permissions, loadingPermissions, projects, loadingProjects]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);
  
  const canPerformAction = (action: 'CRUD') => {
      if (!userProfile || loadingPermissions) return false;
      const userPermissions = permissions[userProfile.role];
      if (!userPermissions) return false;
      const taskPermission = userPermissions.tasks;
      if (taskPermission === 'Mark Complete') return true; 
      return taskPermission === action || taskPermission === 'CRUD + Billing';
  }

  const addTask = async (newTaskData: Omit<Task, 'id'>) => {
     if (!canPerformAction('CRUD')) {
      throw new Error("You don't have permission to add tasks.");
    }
    const tasksRef = collection(db, 'tasks');
    const taskToSave = {
      ...newTaskData,
      assigneeId: newTaskData.assigneeId, 
      startDate: Timestamp.fromDate(newTaskData.startDate),
      dueDate: Timestamp.fromDate(newTaskData.dueDate),
      completedAt: newTaskData.completedAt ? Timestamp.fromDate(newTaskData.completedAt) : null,
      startedAt: newTaskData.startedAt ? Timestamp.fromDate(newTaskData.startedAt) : null,
    };
    await addDoc(tasksRef, taskToSave);
    
    const projectRef = doc(db, 'projects', newTaskData.projectId);
    const projectSnap = await getDoc(projectRef);
    if (projectSnap.exists()) {
        const projectData = projectSnap.data();
        const teamIds = projectData.teamIds || [];
        if (!teamIds.includes(newTaskData.assigneeId)) {
            await updateDoc(projectRef, {
                teamIds: [...teamIds, newTaskData.assigneeId]
            });
        }
    }

    await fetchTasks();
  };

  const updateTask = async (taskId: string, taskData: Partial<Omit<Task, 'id'>>) => {
     if (!userProfile) throw new Error("Not authenticated.");
    
    if (loadingPermissions) throw new Error("Permissions are not loaded yet.");
    
    const userPermissions = permissions[userProfile.role];
    const canEditAll = userPermissions?.tasks === 'CRUD' || userPermissions?.tasks === 'CRUD + Billing';
    const taskToUpdate = tasks.find(t => t.id === taskId);
    
    if (!taskToUpdate) { // Find from server if not in local state
        const taskDoc = await getDoc(doc(db, 'tasks', taskId));
        if (!taskDoc.exists()) throw new Error("Task not found.");
    }

    const isAssignee = taskToUpdate?.assigneeId === userProfile.uid;
    const isReviewer = taskToUpdate?.reviewerId === userProfile.uid;

    if (!canEditAll && !isAssignee && !isReviewer) {
        throw new Error("You don't have permission to update this task.");
    }
    
    const taskRef = doc(db, 'tasks', taskId);
    const dataToUpdate: any = { ...taskData };
    
    if (dataToUpdate.startDate) dataToUpdate.startDate = Timestamp.fromDate(new Date(dataToUpdate.startDate));
    if (dataToUpdate.dueDate) dataToUpdate.dueDate = Timestamp.fromDate(new Date(dataToUpdate.dueDate));
    if (dataToUpdate.startedAt) dataToUpdate.startedAt = Timestamp.fromDate(new Date(dataToUpdate.startedAt));
    if (dataToUpdate.completedAt) dataToUpdate.completedAt = Timestamp.fromDate(new Date(dataToUpdate.completedAt));
    
    if ('startedAt' in dataToUpdate && dataToUpdate.startedAt === null) dataToUpdate.startedAt = null;
    if ('completedAt' in dataToUpdate && dataToUpdate.completedAt === null) dataToUpdate.completedAt = null;
    if ('actualHours' in dataToUpdate && dataToUpdate.actualHours === null) dataToUpdate.actualHours = null;
    if ('efficiency' in dataToUpdate && dataToUpdate.efficiency === null) dataToUpdate.efficiency = null;

    if (dataToUpdate.status === 'in-progress' && !taskToUpdate?.startedAt) {
        dataToUpdate.startedAt = Timestamp.now();
    }

    // Also update timesheet if actualHours are logged
    if (dataToUpdate.actualHours && dataToUpdate.actualHours > 0) {
        const completedDate = taskToUpdate?.completedAt || new Date(); // Use existing or current date
        const timesheetRef = collection(db, 'timesheet');
        // Check if an entry already exists for this task on this date
        const q = query(timesheetRef, 
            where('userId', '==', taskToUpdate!.assigneeId), 
            where('taskId', '==', taskId)
        );
        const snapshot = await getDocs(q);
        const timesheetEntry = {
            userId: taskToUpdate!.assigneeId,
            date: Timestamp.fromDate(completedDate),
            type: 'task',
            taskId: taskId,
            projectId: taskToUpdate!.projectId,
            projectName: taskToUpdate!.projectName,
            taskName: taskToUpdate!.title,
            description: taskToUpdate!.title,
            hours: dataToUpdate.actualHours,
            isApproved: false,
            needsRevision: false,
        };

        if (snapshot.empty) {
            await addDoc(timesheetRef, timesheetEntry);
        } else {
            const docId = snapshot.docs[0].id;
            await updateDoc(doc(db, 'timesheet', docId), timesheetEntry);
        }
    }
    
    await updateDoc(taskRef, dataToUpdate);

    if (taskData.assigneeId) {
        const projectId = taskData.projectId || taskToUpdate?.projectId;
        const projectRef = doc(db, 'projects', projectId!);
        const projectSnap = await getDoc(projectRef);
        if (projectSnap.exists()) {
            const projectData = projectSnap.data();
            const teamIds = projectData.teamIds || [];
            if (!teamIds.includes(taskData.assigneeId)) {
                await updateDoc(projectRef, {
                    teamIds: [...teamIds, taskData.assigneeId]
                });
            }
        }
    }

    await fetchTasks();
  };
  
  const deleteTask = async (taskId: string) => {
     if (!canPerformAction('CRUD')) {
      throw new Error("You don't have permission to delete tasks.");
    }
    const taskRef = doc(db, 'tasks', taskId);
    await deleteDoc(taskRef);
    await fetchTasks();
  };

  return { tasks, addTask, updateTask, deleteTask, loading, error, refetch: fetchTasks };
}

