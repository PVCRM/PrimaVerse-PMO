
"use client";

import { useState, useMemo, useCallback, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useDashboard } from '@/context/dashboard-context';

// UI Components
import { KpiCard } from '@/components/analytics-card';
import { ProjectHealthCard } from '@/components/smart-recommendations';
import { TaskHealthCard } from '@/components/task-health-card';
import { EmptyState } from '@/components/role-switcher';
import { SettingsPage } from '@/components/settings-page';
import { AddClientDialog } from '@/components/add-client-dialog';
import { ClientsTable } from '@/components/clients-table';
import { ProjectsTable } from '@/components/projects-table';
import { TasksTable } from '@/components/tasks-table';
import { TeamTable } from '@/components/team-table';
import { ViewClientDialog } from '@/components/view-client-dialog';
import { ViewProjectDialog } from '@/components/view-project-dialog';
import { ViewTaskDialog } from '@/components/view-task-dialog';
import { ViewEmployeeDialog } from '@/components/view-employee-dialog';
import { DeleteConfirmationDialog } from '@/components/delete-confirmation-dialog';
import { Button } from '@/components/ui/button';
import { Briefcase, Download, PlusCircle, Upload } from 'lucide-react';
import { ProjectsOverviewCard } from '@/components/dashboard/projects-overview-card';
import { AddProjectDialog } from '@/components/add-project-dialog';
import { AddTaskDialog } from '@/components/add-task-dialog';
import { AddEmployeeDialog, EmployeeFormOnSaveValues } from '@/components/add-employee-dialog';
import { EditEmployeeDialog, EditEmployeeOnSaveValues } from '@/components/edit-employee-dialog';
import { ImportEmployeesDialog } from '@/components/import-employees-dialog';
import { ApprovalsPage } from '@/components/approvals-page';
import { MasterDataPage } from '@/components/master-data-page';
import { PermissionsPage } from '@/components/permissions-page';
import { TimesheetPage } from '@/components/timesheet-page';
import { ReviewsAndApprovalsPage } from '@/components/reviews-and-approvals-page';
import { MistakeReport } from '@/components/mistake-report';
import { ResourceUtilityDialog } from '@/components/resource-utility-dialog';
import { DailyLogPage } from '@/components/daily-log-page';
import { ReportsPage } from '@/components/reports-page';
import { PageHeader } from '@/components/page-header';

// Hooks
import { useMasterData } from '@/hooks/use-master-data';
import { useToast } from "@/hooks/use-toast";
import { usePermissions } from '@/hooks/use-permissions';

// Types
import type { Client, Project, Task, UserProfile, UserRole } from "@/lib/types";
import { roleHierarchy } from '@/data/master-data';

export default function DashboardPage() {
  const { 
    activeView, setActiveView, allProjects, allTasks, clients, team, timesheetData,
    addProject, updateProject, deleteProject, refetchProjects,
    addTask, updateTask, deleteTask, refetchTasks,
    addClient, updateClient, deleteClient, refetchClients,
    refetchTeam,
  } = useDashboard();

  const { userProfile, addEmployeeByHr, updateUserProfile, deactivateEmployee, deleteEmployee, bulkAddEmployees } = useAuth();
  const { toast } = useToast();
  
  // Dialog states
  const [isClientFormOpen, setIsClientFormOpen] = useState(false);
  const [isProjectFormOpen, setIsProjectFormOpen] = useState(false);
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
  const [isEmployeeFormOpen, setIsEmployeeFormOpen] = useState(false);
  const [isImportEmployeesOpen, setIsImportEmployeesOpen] = useState(false);
  const [isResourceUtilityOpen, setIsResourceUtilityOpen] = useState(false);
  
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<UserProfile | null>(null);
  
  const [viewingClient, setViewingClient] = useState<Client | null>(null);
  const [viewingProject, setViewingProject] = useState<Project | null>(null);
  const [viewingEmployee, setViewingEmployee] = useState<UserProfile | null>(null);
  
  const [deletingClient, setDeletingClient] = useState<Client | null>(null);
  const [deletingProject, setDeletingProject] = useState<Project | null>(null);
  const [deletingTask, setDeletingTask] = useState<Task | null>(null);
  const [deactivatingEmployee, setDeactivatingEmployee] = useState<UserProfile | null>(null);
  const [deletingEmployee, setDeletingEmployee] = useState<UserProfile | null>(null);

  // Data Hooks
  const { masterData } = useMasterData();
  const { permissions } = usePermissions();

  const projects = useMemo(() => {
    return allProjects.map(p => ({
        ...p,
        projectTypeName: masterData.projectTypes.find(pt => pt.id === p.projectTypeId)?.name || 'N/A'
    }));
  }, [allProjects, masterData.projectTypes]);


  const scopedTasks = useMemo(() => {
    if (!userProfile || !allTasks) return [];
    
    switch(userProfile.role) {
      case 'Employee':
        return allTasks.filter(t => t.assigneeId === userProfile.uid);
      case 'Team Lead':
        const leadTeamMemberIds = team.filter(m => m.reviewerId === userProfile.uid).map(m => m.uid);
        leadTeamMemberIds.push(userProfile.uid); // Include lead's own tasks
        return allTasks.filter(t => leadTeamMemberIds.includes(t.assigneeId));
      case 'Project Manager':
        const managedProjectIds = new Set(projects.map(p => p.id));
        return allTasks.filter(t => managedProjectIds.has(t.projectId));
      case 'Director/VP/CXO':
      case 'Super Admin':
        return allTasks;
      default:
        return [];
    }
  }, [userProfile, allTasks, projects, team]);
  
  const refetchAllData = useCallback(() => {
    refetchClients();
    refetchProjects();
    refetchTasks();
    refetchTeam();
  }, [refetchClients, refetchProjects, refetchTasks, refetchTeam]);

  // Actions
  const handleSaveClient = async (clientData: Omit<Client, 'id'>, clientId?: string) => {
    if (clientId) { await updateClient(clientId, clientData); } else { await addClient(clientData); }
    setIsClientFormOpen(false); setEditingClient(null);
  };
  const handleSaveProject = async (projectData: Omit<Project, 'id'>, projectId?: string) => {
    if (projectId) { await updateProject(projectId, projectData); } else { await addProject(projectData); }
    setIsProjectFormOpen(false); setEditingProject(null);
  };
  const handleSaveTask = async (taskData: Omit<Task, 'id' | 'assigneeId'>[], taskId?: string) => {
    if (taskId) { await updateTask(taskId, taskData[0]); } else { for (const task of taskData) { await addTask(task as Omit<Task, 'id'>); } }
    setIsTaskFormOpen(false); setEditingTask(null);
  };
  const handleSaveEmployee = async (formData: EmployeeFormOnSaveValues) => {
    await addEmployeeByHr(formData);
    refetchTeam();
    setIsEmployeeFormOpen(false);
  };
  const handleSaveEditedEmployee = async (formData: EditEmployeeOnSaveValues) => {
    if (!editingEmployee) return;
    try {
      await updateUserProfile(editingEmployee.uid, { ...formData, name: `${formData.firstName} ${formData.lastName}`.trim() });
      toast({ title: "Success", description: "Employee profile updated." });
      refetchTeam();
    } catch (error: any) { toast({ variant: 'destructive', title: 'Error', description: error.message || 'Could not update employee.' }); }
    setEditingEmployee(null);
  };
  const handleDeactivateEmployee = async () => {
    if (deactivatingEmployee) {
      try { await deactivateEmployee(deactivatingEmployee.uid); toast({ title: "Success", description: `${deactivatingEmployee.name} has been deactivated.` }); refetchTeam(); } 
      catch (error: any) { toast({ variant: 'destructive', title: 'Error', description: error.message || 'Could not deactivate employee.' }); }
      setDeactivatingEmployee(null);
    }
  };
  const handleDeleteEmployee = async () => {
    if (deletingEmployee) {
      try { await deleteEmployee(deletingEmployee.uid); toast({ title: "Success", description: `${deletingEmployee.name} has been marked for deletion.` }); refetchTeam(); } 
      catch (error: any) { toast({ variant: 'destructive', title: 'Error', description: error.message || 'Could not delete employee.' }); }
      setDeletingEmployee(null);
    }
  };
  const handleBulkImport = async (data: EmployeeFormOnSaveValues[]) => {
    const results = await bulkAddEmployees(data);
    if (results.successes > 0) refetchTeam();
    return results;
  };

  // Dialog Open/Close handlers
  const handleOpenEditClientForm = (client: Client) => { setViewingClient(null); setEditingClient(client); setIsClientFormOpen(true); };
  const handleOpenEditProjectForm = (project: Project) => { setViewingProject(null); setEditingProject(project); setIsProjectFormOpen(true); };
  const handleDeleteFromView = (setter: any, onComplete?: () => void) => (item: any) => {
    setViewingClient(null); setViewingProject(null); setViewingEmployee(null); setSelectedTask(null);
    setter(item);
    if (onComplete) onComplete();
  };
  
  const getDeletionState = () => {
    if (deactivatingEmployee) return { title: `Deactivate ${deactivatingEmployee.name}`, description: "Are you sure? This will put the account in sleep mode.", onConfirm: handleDeactivateEmployee };
    if (deletingEmployee) return { title: `Delete ${deletingEmployee.name}`, description: "Are you sure? This will soft-delete the user.", onConfirm: handleDeleteEmployee };
    if (deletingClient) return { title: `Delete ${deletingClient.name}`, description: "Are you sure you want to delete this client?", onConfirm: async () => { await deleteClient(deletingClient.id); setDeletingClient(null); } };
    if (deletingProject) return { title: `Delete ${deletingProject.name}`, description: "Are you sure you want to delete this project?", onConfirm: async () => { await deleteProject(deletingProject.id); setDeletingProject(null); } };
    if (deletingTask) return { title: `Delete Task`, description: "Are you sure you want to delete this task?", onConfirm: async () => { await deleteTask(deletingTask.id); setDeletingTask(null); } };
    return null;
  };
  
  const metrics = useMemo(() => {
    if (!userProfile) return { efficiency: 0, billingHours: 0, utilization: 0, errors: 0 };
    
    let relevantTasks = scopedTasks;
    if (userProfile.role === 'Team Lead') {
      const memberIds = team.filter(m => m.reviewerId === userProfile.uid).map(m => m.uid);
      relevantTasks = allTasks.filter(t => memberIds.includes(t.assigneeId));
    }
    
    const completedTasks = relevantTasks.filter(t => t.status === 'completed' && t.efficiency != null);
    const totalEfficiency = completedTasks.reduce((acc, task) => acc + (task.efficiency || 0), 0);
    const efficiency = completedTasks.length > 0 ? Math.round(totalEfficiency / completedTasks.length) : 0;
    const totalErrors = relevantTasks.reduce((acc, task) => acc + (task.mistakeCount || 0), 0);
    
    let relevantTimesheetEntries = timesheetData || [];
    let teamMemberCount = 1;

    switch (userProfile.role) {
      case 'Employee': relevantTimesheetEntries = timesheetData.filter(e => e.userId === userProfile.uid); break;
      case 'Team Lead': const memberIds = team.filter(m => m.reviewerId === userProfile.uid).map(m => m.uid); relevantTimesheetEntries = timesheetData.filter(e => memberIds.includes(e.userId)); teamMemberCount = memberIds.length; break;
      case 'Project Manager': case 'Director/VP/CXO': case 'Super Admin': teamMemberCount = team.length > 0 ? team.length : 1; break;
    }
    
    const billableHours = relevantTimesheetEntries.filter(e => e.type === 'task').reduce((acc, entry) => acc + entry.hours, 0);
    const totalAvailableHours = teamMemberCount * 9;
    const utilization = totalAvailableHours > 0 ? Math.round((billableHours / totalAvailableHours) * 100) : 0;

    return { efficiency, billingHours: Math.round(billableHours), utilization, errors: totalErrors };
  }, [userProfile, scopedTasks, allTasks, team, timesheetData]);
  
  useEffect(() => {
    if (activeView === 'resource-utility' && userProfile && roleHierarchy[userProfile.role] > 0) {
      setIsResourceUtilityOpen(true);
      setActiveView('dashboard');
    }
  }, [activeView, userProfile, setActiveView]);

  const pageContentMap: Record<string, React.ReactNode> = {
    dashboard: <DashboardView metrics={metrics} projects={projects} scopedTasks={scopedTasks} allTasks={allTasks} clients={clients} setViewingProject={setViewingProject} setIsResourceUtilityOpen={setIsResourceUtilityOpen} userProfile={userProfile} team={team} />,
    settings: <SettingsPage onDataChange={refetchAllData} />,
    approvals: <ApprovalsPage onDataChange={refetchTeam} />,
    'master-data': <MasterDataPage />,
    permissions: <PermissionsPage />,
    reports: <ReportsPage clients={clients} projects={projects} masterData={masterData} />,
    timesheet: <TimesheetPage userProfile={userProfile!} team={team} clients={clients} projects={projects} />,
    clients: <ClientsTable clients={clients} userProfile={userProfile!} onRowClick={setViewingClient} onAddClick={() => setIsClientFormOpen(true)} />,
    projects: <ProjectsTable projects={projects} userProfile={userProfile!} onRowClick={setViewingProject} onAddClick={() => setIsProjectFormOpen(true)} />,
    tasks: <TasksTable tasks={scopedTasks} team={team} userProfile={userProfile!} onRowClick={setSelectedTask} onAddClick={() => setIsTaskFormOpen(true)} />,
    'critical-tasks': <TasksTable tasks={scopedTasks} team={team} userProfile={userProfile!} onRowClick={setSelectedTask} onAddClick={() => setIsTaskFormOpen(true)} initialTab="critical" />,
    'reviews-approvals': <ReviewsAndApprovalsPage />,
    'daily-log': <DailyLogPage userProfile={userProfile!} team={team} />,
    'resource-utility': <EmptyState title="Resource Utility" description="This view is now accessed via the dialog." />,
    team: <TeamTable team={team} userProfile={userProfile!} onAddClick={() => setIsEmployeeFormOpen(true)} onRowClick={setViewingEmployee} onImportClick={() => setIsImportEmployeesOpen(true)} onDownloadClick={() => handleDownloadTemplate()} />
  };

  const pageTitleMap: Record<string, string> = {
    dashboard: 'Dashboard', settings: 'Settings', approvals: 'Approvals & Requests', 'master-data': 'Master Data Management',
    permissions: 'Role Permissions', reports: 'Reports Center', timesheet: 'Timesheet', clients: 'Clients',
    projects: 'Projects', tasks: 'Tasks', 'critical-tasks': 'Critical Tasks', 'reviews-approvals': 'Reviews & Approvals',
    'daily-log': 'Daily Log', 'resource-utility': 'Resource Utility', team: 'Team'
  };

  const renderPageActions = () => {
    const canManage = (p: keyof Permission) => permissions[userProfile!.role]?.[p] === 'CRUD' || permissions[userProfile!.role]?.[p] === 'CRUD + Billing';
    if (!userProfile) return null;
    switch (activeView) {
      case 'clients': return canManage('clients') && <Button onClick={() => setIsClientFormOpen(true)}><PlusCircle className="mr-2 h-4 w-4" /> Add Client</Button>;
      case 'projects': return canManage('projects') && <Button onClick={() => setIsProjectFormOpen(true)}><PlusCircle className="mr-2 h-4 w-4" /> Add Project</Button>;
      case 'tasks': return canManage('tasks') && <Button onClick={() => setIsTaskFormOpen(true)}><PlusCircle className="mr-2 h-4 w-4" /> Add Task</Button>;
      case 'team': return canManage('team') && (
        <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setIsImportEmployeesOpen(true)}><Upload className="h-4 w-4" /></Button>
            <Button variant="outline" size="icon" onClick={() => {}}><Download className="h-4 w-4" /></Button>
            <Button onClick={() => setIsEmployeeFormOpen(true)}><PlusCircle className="mr-2 h-4 w-4" /> Add Employee</Button>
        </div>
      );
      default: return null;
    }
  };

  return (
    <div className="flex flex-col flex-1 h-full">
      <div className="flex-grow animate-fade-in-up p-6 sm:p-8">
        <PageHeader title={pageTitleMap[activeView] || 'Dashboard'}>{renderPageActions()}</PageHeader>
        <div id="page-container">
          {pageContentMap[activeView] || <EmptyState title="Not Implemented" description="This view has not been implemented yet." />}
        </div>
      </div>
      
      <footer className="text-center py-4 text-xs text-muted-foreground">© 2025 Perspective PMO by PVD • Crafted with lot of ♥ by AM.</footer>
      
      {/* DIALOGS */}
      <AddClientDialog open={isClientFormOpen} onOpenChange={() => { setIsClientFormOpen(false); setEditingClient(null); }} onSave={handleSaveClient} clientToEdit={editingClient} team={team} />
      <AddProjectDialog open={isProjectFormOpen} onOpenChange={() => { setIsProjectFormOpen(false); setEditingProject(null); }} onSave={handleSaveProject} clients={clients} team={team} projectToEdit={editingProject} onDataChange={refetchProjects} />
      <AddTaskDialog open={isTaskFormOpen} onOpenChange={() => { setIsTaskFormOpen(false); setEditingTask(null); }} onSave={handleSaveTask} taskToEdit={editingTask} clients={clients} projects={projects} team={team} userProfile={userProfile} />
      <AddEmployeeDialog open={isEmployeeFormOpen} onOpenChange={setIsEmployeeFormOpen} onSave={handleSaveEmployee} />
      <EditEmployeeDialog open={!!editingEmployee} onOpenChange={() => setEditingEmployee(null)} onSave={handleSaveEditedEmployee} employeeToEdit={editingEmployee} currentUserProfile={userProfile} />
      <ImportEmployeesDialog open={isImportEmployeesOpen} onOpenChange={setIsImportEmployeesOpen} onImport={handleBulkImport} onDownloadTemplate={handleDownloadTemplate} />
      
      <ViewClientDialog client={viewingClient} onOpenChange={() => setViewingClient(null)} onEdit={handleOpenEditClientForm} onDelete={handleDeleteFromView(setDeletingClient)} onComplete={handleDeleteFromView((c: Client) => updateClient(c.id, { status: 'Inactive' }))} onReactivate={handleDeleteFromView((c: Client) => updateClient(c.id, { status: 'Active' }))} userProfile={userProfile} projects={allProjects.filter(p => p.clientId === viewingClient?.id)} team={team} />
      <ViewProjectDialog project={viewingProject} client={clients.find(c => c.id === viewingProject?.clientId) || null} tasks={allTasks.filter(t => t.projectId === viewingProject?.id)} team={team} onOpenChange={() => setViewingProject(null)} onEdit={handleOpenEditProjectForm} onDelete={handleDeleteFromView(setDeletingProject)} onComplete={handleDeleteFromView((p: Project) => updateProject(p.id, { status: 'Inactive' }))} onReactivate={handleDeleteFromView((p: Project) => updateProject(p.id, { status: 'Active' }))} userProfile={userProfile} canManage={canManage('projects')} />
      <ViewTaskDialog key={selectedTask?.id || 'view-task-dialog'} open={!!selectedTask} onOpenChange={() => setSelectedTask(null)} task={selectedTask} projects={projects} clients={clients} team={team} onUpdateTask={updateTask} onLogHoursAndSubmit={async (taskId, hours) => { await updateTask(taskId, { actualHours: hours, status: 'pending_review' }); toast({ title: "Task Submitted", description: "Your task is pending review." }); }} onDeleteTask={handleDeleteFromView(setDeletingTask)} refetchTasks={refetchTasks} />
      <ViewEmployeeDialog employee={viewingEmployee} onOpenChange={() => setViewingEmployee(null)} onEdit={handleDeleteFromView(setEditingEmployee)} onDeactivate={handleDeleteFromView(setDeactivatingEmployee)} onDelete={handleDeleteFromView(setDeletingEmployee)} userProfile={userProfile} />
      <ResourceUtilityDialog open={isResourceUtilityOpen} onOpenChange={setIsResourceUtilityOpen} tasks={allTasks} team={team} userProfile={userProfile} />
      <DeleteConfirmationDialog open={!!getDeletionState()} onOpenChange={() => { setDeletingClient(null); setDeletingProject(null); setDeletingTask(null); setDeactivatingEmployee(null); setDeletingEmployee(null); }} {...getDeletionState()} />
    </div>
  );
}

function DashboardView({ metrics, projects, scopedTasks, allTasks, clients, setViewingProject, setIsResourceUtilityOpen, userProfile, team }: any) {
  if (!userProfile) return null;
  const isManager = roleHierarchy[userProfile.role] >= 1;
  const teamMemberIds = team.filter((t:any) => t.reviewerId === userProfile.uid).map((t:any) => t.uid);
  const teamActiveTasks = allTasks.filter((t:any) => teamMemberIds.includes(t.assigneeId) && t.status !== 'completed').length;
            
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KpiCard title="Efficiency" value={`${metrics.efficiency}%`} description="Avg. on completed tasks." />
          <KpiCard title="Billing Hours" value={metrics.billingHours.toLocaleString()} description="Total billable hours logged." />
          <KpiCard title="Utilization" value={`${metrics.utilization}%`} description="Based on 9-hour workday." />
          {isManager && userProfile.role !== 'Super Admin' ? (
              <KpiCard title="Team Workload" value={`${teamActiveTasks}`} description="Active tasks in your team." icon={Briefcase} onClick={() => setIsResourceUtilityOpen(true)} />
          ) : (
              <KpiCard title="Errors" value={metrics.errors.toString()} description="Total mistakes on tasks." isWarning={metrics.errors > 0}/>
          )}
      </div>
      {userProfile.role === 'Employee' && <TaskHealthCard tasks={scopedTasks} />}
      {userProfile.role === 'Super Admin' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ProjectHealthCard projects={projects} tasks={allTasks} title="Organization Health" description="AI-powered summary of overall operational health."/>
            <ProjectsOverviewCard projects={projects} tasks={allTasks} onProjectClick={setViewingProject}/>
          </div>
      )}
      {['Team Lead', 'Project Manager', 'Director/VP/CXO'].includes(userProfile.role) && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ProjectHealthCard projects={projects} tasks={scopedTasks} />
            <ProjectsOverviewCard projects={projects} tasks={scopedTasks} onProjectClick={setViewingProject}/>
          </div>
      )}
      {userProfile.role === 'Super Admin' && <MistakeReport clients={clients} projects={projects} tasks={allTasks} />}
    </div>
  );
}
